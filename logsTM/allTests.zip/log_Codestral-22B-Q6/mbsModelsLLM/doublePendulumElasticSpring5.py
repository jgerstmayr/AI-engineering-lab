# ** given model description: **
# Double pendulum consisting of two mass points which are connected with
# elastic springs with the following properties: mass m1 = 4 kg, mass m2 = 5 kg,
# length of the strings L1 = 1.5 m, L2 = 2 m, stiffnesses k1 = 5000 and k2 = 1000,
# and gravity g = 9.81 m/s^2 which acts in negative y-direction. The first arm
# of the pendulum points in negative x-direction and the second arm in negative
# x-direction.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

m1 = 4
m2 = 5
L1 = 1.5
L2 = 2
k1 = 5000
k2 = 1000
g = 9.81

oMass1 = mbs.CreateMassPoint(physicsMass=m1, referencePosition=[-L1,0,0], gravity=[0,-g,0])
oMass2 = mbs.CreateMassPoint(physicsMass=m2, referencePosition=[-L1-L2,0,0], gravity=[0,-g,0])

oSpringDamper1 = mbs.CreateSpringDamper(bodyNumbers=[oGround, oMass1], localPosition0=[0,0,0], localPosition1=[0,0,0], stiffness=k1)
oSpringDamper2 = mbs.CreateSpringDamper(bodyNumbers=[oMass1, oMass2], localPosition0=[L1,0,0], localPosition1=[-L2,0,0], stiffness=k2)

mbs.Assemble()

tEnd = 1
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 1e-1
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.1
SC.visualizationSettings.nodes.tiling = 32
SC.visualizationSettings.connectors.defaultSize = 0.05 #spring


#start solver:
mbs.SolveDynamic(simulationSettings)


