# ** given model description: **
# A serial chain of 2 masses connected with springs-dampers. Each mass has
# m = 12 kg, the stiffnesses are k = 3000 N/m, and the damping coefficients
# are d = 50 Ns/m. A force f = 75 N is applied to the last mass (with highest
# index). The first mass is connected to ground via the first spring-damper. The
# relaxed length of each spring is 0.3 m, and the first mass is located at x = 0.3
# m. The serial chain is oriented along the global x-axis. Gravity acts in positive
# x-direction, with g = 9.81 m/s^2.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

m = 12
k = 3000
d = 50
f = 75
g = 9.81

oMass1 = mbs.CreateMassPoint(physicsMass=m, referencePosition=[0.3,0,0], gravity=[g,0,0])
oMass2 = mbs.CreateMassPoint(physicsMass=m, referencePosition=[0.6,0,0], gravity=[g,0,0])

oSpringDamper1 = mbs.CreateSpringDamper(bodyNumbers=[oGround, oMass1], stiffness=k, damping=d, referenceLength=0.3)
oSpringDamper2 = mbs.CreateSpringDamper(bodyNumbers=[oMass1, oMass2], stiffness=k, damping=d, referenceLength=0.3)

loadMassPoint = mbs.CreateForce(bodyNumber=oMass2, loadVector=[f,0,0])

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 1e-1
simulationSettings.solutionSettings.sensorsWritePeriod = 5e-3
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.1


#start solver:
mbs.SolveDynamic(simulationSettings)


