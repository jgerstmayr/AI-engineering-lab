# ** given model description: **
# Two mass points connected by springs. The mass points both have mass m1
# = m2 = 0.5 kg, are initially located at p1 = [-0.25,0,0] and p2 = [0.25,0,0],
# positions given in m. Mass m1 has initial velocity vz = 1.5 m/s and m2 has initial
# velocity vz = -1.5 m/s while all other initial velocity components are zero. The
# spring between the two mass points is initially relaxed and has stiffness k =
# 600 N/m. No gravity nor forces are present.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

oMass1 = mbs.CreateMassPoint(physicsMass=0.5, referencePosition=[-0.25,0,0],
                             initialDisplacement=[0,0,0],
                             initialVelocity=[0,0,1.5],
                             gravity=[0,0,0])

oMass2 = mbs.CreateMassPoint(physicsMass=0.5, referencePosition=[0.25,0,0],
                             initialDisplacement=[0,0,0],
                             initialVelocity=[0,0,-1.5],
                             gravity=[0,0,0])

oSpring = mbs.CreateSpringDamper(bodyNumbers=[oMass1, oMass2],
                                 localPosition0=[0,0,0],
                                 localPosition1=[0,0,0],
                                 referenceLength=None,
                                 stiffness=600, damping=0)

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 1e-1
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.05
SC.visualizationSettings.nodes.tiling = 32

#start solver:
mbs.SolveDynamic(simulationSettings)

