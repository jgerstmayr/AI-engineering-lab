# ** given model description: **
# A serial chain of 3 masses connected with springs-dampers. Each mass has
# m = 12 kg, the stiffnesses are k = 6000 N/m, and the damping coefficients
# are d = 30 Ns/m. A force f = 80 N is applied to the last mass (with highest
# index). The first mass is connected to ground via the first spring-damper. The
# relaxed length of each spring is 0.5 m, and the first mass is located at z = 0.5
# m. The serial chain is oriented along the global z-axis. Gravity acts in positive
# z-direction, with g = 9.81 m/s^2.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

masses = []
spring_dampers = []

for i in range(3):
    mass = mbs.CreateMassPoint(physicsMass=12, referencePosition=[0,0,0.5+i*0.5], gravity=[0,0,9.81])
    masses.append(mass)

    if i > 0:
        spring_damper = mbs.CreateSpringDamper(bodyNumbers=[masses[i-1], mass], localPosition0=[0,0,0.25], localPosition1=[0,0,-0.25], referenceLength=0.5, stiffness=6000, damping=30)
        spring_dampers.append(spring_damper)

loadMassPoint = mbs.CreateForce(bodyNumber=masses[-1], loadVector=[0,0,80])

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 1e-1
simulationSettings.solutionSettings.sensorsWritePeriod = 5e-3
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.1


#start solver:
mbs.SolveDynamic(simulationSettings)


