# ** given model description: **
# Simple mathematical pendulum with the following properties: point mass
# m = 3 kg, inelastic string length = 1.5 m (fixed distance between ground
# and mass point), and gravity g = 11.15 m/s^2 which acts in negative y-direction,
# while the pendulum moves in the x-y plane. The reference configuration of the
# pendulum is such that the string has an angle (positive rotation sense) of 25 degrees
# relative to the negative y-axis. Air resistance is neglected.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

oMass = mbs.CreateMassPoint(physicsMass=3, referencePosition=[0,0,0],
                            initialDisplacement=[1.5*np.sin(25*np.pi/180), -1.5*np.cos(25*np.pi/180), 0],
                            gravity=[0,-11.15,0])

oDistance = mbs.CreateDistanceConstraint(bodyNumbers=[oGround, oMass],
                                         localPosition0=[0,0,0],
                                         localPosition1=[0,0,0],
                                         distance=1.5)

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 1e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.05
SC.visualizationSettings.nodes.tiling = 32


#start solver:
mbs.SolveDynamic(simulationSettings)


