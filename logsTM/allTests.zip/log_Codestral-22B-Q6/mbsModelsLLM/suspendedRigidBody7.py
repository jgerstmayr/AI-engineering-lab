# ** given model description: **
# A rigid body is suspended by 4 Cartesian spring-dampers. The rigid body
# has a brick-shape with density = 400 kg/m^3, and xyz-dimensions lx=5m, ly=1m,
# lz=1.2m. The reference point of the body, which is equal to the COM, is located
# initially at [0,1/2,0]. The Cartesian spring-dampers are located at the x/z positions
# of the vertices of the body. The y-local-position of the spring-dampers at
# the body is -1/2 and the local position for ground is y=0. All spring-dampers
# have equal parameters: stiffness = [15000,125000,20000] N/m and damping = [400,2500,250]
# Ns/m. Gravity g = 9.81 m/s^2 acts in negative y-direction, and no further forces
# or damping are applied and contact with ground is ignored.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

lx = 5
ly = 1
lz = 1.2
density = 400
mass = density * lx * ly * lz
inertiaCube = InertiaCuboid(density=density, sideLengths=[lx, ly, lz])

oBody = mbs.CreateRigidBody(inertia=inertiaCube, referencePosition=[0, 1/2, 0], gravity=[0, -9.81, 0])

spring_dampers_positions = [
    [lx/2, -ly/2, lz/2],
    [-lx/2, -ly/2, lz/2],
    [lx/2, -ly/2, -lz/2],
    [-lx/2, -ly/2, -lz/2]
]

for pos in spring_dampers_positions:
    mbs.CreateCartesianSpringDamper(
        bodyNumbers=[oGround, oBody],
        localPosition0=[pos[0], 0, pos[2]],
        localPosition1=pos,
        stiffness=[15000, 125000, 20000],
        damping=[400, 2500, 250]
    )

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 5e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 5e-3
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=1
SC.visualizationSettings.openGL.lineWidth = 3

#start solver:
mbs.SolveDynamic(simulationSettings)

