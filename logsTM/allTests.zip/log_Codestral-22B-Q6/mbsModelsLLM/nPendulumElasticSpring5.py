# ** given model description: **
# Multibody n-pendulum system consisting of 6 point masses connected with
# spring-dampers with the following properties: masses m = 0.8 kg, lengths of single elastic
# strings l_single = 1 m, stiffness k = 10000 and damping d = 150 of strings, and
# gravity g = 11.15 m/s^2 which acts in negative y-direction. The pendulum starts
# from horizontal configuration, where all masses are aligned with the x-axis,
# the first mass located at x=1, with a spring-damper connected to ground.
import exudyn as exu
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

mass = 0.8
gravity = 11.15
l_single = 1
k = 10000
d = 150

oMasses = []
oSpringDampers = []

for i in range(6):
    oMass = mbs.CreateMassPoint(physicsMass=mass, referencePosition=[(i+1)*l_single,0,0], gravity=[0,-gravity,0])
    oMasses.append(oMass)

    if i > 0:
        oSpringDamper = mbs.CreateSpringDamper(bodyNumbers=[oMasses[i-1], oMass], stiffness=k, damping=d)
        oSpringDampers.append(oSpringDamper)

mbs.Assemble()

tEnd = 0.5
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 5e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.06
SC.visualizationSettings.nodes.tiling = 16
SC.visualizationSettings.connectors.defaultSize = 0.02 #spring


#start solver:
mbs.SolveDynamic(simulationSettings)


