# ** given model description: **
# Rotational motion of a spinning disc (around z-axis) with the following
# properties: mass m = 10 kg, disc radius r = 0.2 m, disc width w = 0.12, and initial
# angular velocity omega_z = 25 rad/s. The disc is mounted on a frictionless revolute
# joint and experiences a constant torque T_z = 0.8. No gravity acts on the disc.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

mass = 10
radius = 0.2
width = 0.12
volume = np.pi * radius**2 * width
inertiaDisc = InertiaCylinder(density=mass/volume, length=width, outerRadius=radius, axis=2)

oDisc = mbs.CreateRigidBody(inertia=inertiaDisc,
                            referencePosition=[0,0,0],
                            initialAngularVelocity=[0,0,25])

mbs.CreateTorque(bodyNumber=oDisc, loadVector=[0,0,0.8])

mbs.CreateRevoluteJoint(bodyNumbers=[oGround, oDisc],
                        position=[0,0,0],
                        axis=[0,0,1],
                        useGlobalFrame=True)

mbs.Assemble()

tEnd = 1
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 5e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 5e-3
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=1
SC.visualizationSettings.openGL.lineWidth = 3


#start solver:
mbs.SolveDynamic(simulationSettings)


