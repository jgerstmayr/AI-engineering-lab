# ** given model description: **
# Multibody n-pendulum system consisting of 3 point masses with the following
# properties: masses m = 3 kg, length of inextensible strings l_single = 1.25 m, and
# gravity g = 9.81 m/s^2. The pendulum starts from horizontal configuration, where
# all masses are aligned along the x-axis (the first mass starting at x=1.25)
# and all masses have an initial velocity of 0.02 m/s in negative y-direction.
# Gravity acts in negative y-direction and air resistance is neglected. The strings
# between the consecutive masses (and the string between first mass and ground) shall
# be modelled as constrained distances.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

mass = 3
length = 1.25
gravity = 9.81
initial_velocity = 0.02

oMass1 = mbs.CreateMassPoint(physicsMass=mass, referencePosition=[length,0,0], initialVelocity=[0,-initial_velocity,0], gravity=[0,-gravity,0])
oMass2 = mbs.CreateMassPoint(physicsMass=mass, referencePosition=[2*length,0,0], initialVelocity=[0,-initial_velocity,0], gravity=[0,-gravity,0])
oMass3 = mbs.CreateMassPoint(physicsMass=mass, referencePosition=[3*length,0,0], initialVelocity=[0,-initial_velocity,0], gravity=[0,-gravity,0])

oDistance1 = mbs.CreateDistanceConstraint(bodyNumbers=[oGround, oMass1], localPosition0=[0,0,0], localPosition1=[0,0,0], distance=None)
oDistance2 = mbs.CreateDistanceConstraint(bodyNumbers=[oMass1, oMass2], localPosition0=[0,0,0], localPosition1=[0,0,0], distance=None)
oDistance3 = mbs.CreateDistanceConstraint(bodyNumbers=[oMass2, oMass3], localPosition0=[0,0,0], localPosition1=[0,0,0], distance=None)

mbs.Assemble()

tEnd = 1
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 1e-1
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.05
SC.visualizationSettings.nodes.tiling = 16


#start solver:
mbs.SolveDynamic(simulationSettings)


