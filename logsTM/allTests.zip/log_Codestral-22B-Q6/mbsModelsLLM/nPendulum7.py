# ** given model description: **
# Multibody n-pendulum system consisting of 6 point masses with the following
# properties: masses m = 5 kg, length of inextensible strings l_single = 0.3 m, and gravity
# g = 9.81 m/s^2. The pendulum starts from horizontal configuration, where
# all masses are aligned along the x-axis (the first mass starting at x=0.3)
# and all masses have an initial velocity of 0.4 m/s in negative y-direction.
# Gravity acts in negative y-direction and air resistance is neglected. The strings
# between the consecutive masses (and the string between first mass and ground) shall
# be modelled as constrained distances.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

mass = 5
length = 0.3
gravity = 9.81
initial_velocity = [0, -0.4, 0]

oMasses = []
oDistances = []

for i in range(6):
    oMass = mbs.CreateMassPoint(physicsMass=mass, referencePosition=[(i+1)*length, 0, 0],
                                initialDisplacement=[0, 0, 0],
                                initialVelocity=initial_velocity,
                                gravity=[0, -gravity, 0])
    oMasses.append(oMass)

    if i == 0:
        oDistance = mbs.CreateDistanceConstraint(bodyNumbers=[oGround, oMass],
                                                 localPosition0=[0, 0, 0],
                                                 localPosition1=[0, 0, 0],
                                                 distance=None)
    else:
        oDistance = mbs.CreateDistanceConstraint(bodyNumbers=[oMasses[i-1], oMass],
                                                 localPosition0=[0, 0, 0],
                                                 localPosition1=[0, 0, 0],
                                                 distance=None)
    oDistances.append(oDistance)

mbs.Assemble()

tEnd = 1
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 1e-1
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.05
SC.visualizationSettings.nodes.tiling = 16


#start solver:
mbs.SolveDynamic(simulationSettings)


