# ** given model description: **
# A rigid body is suspended by 4 Cartesian spring-dampers. The rigid body
# has a brick-shape with density = 400 kg/m^3, and xyz-dimensions lx=3m, ly=1.2m,
# lz=2m. The reference point of the body, which is equal to the COM, is located
# initially at [0,1.2/2,0]. The Cartesian spring-dampers are located at the x/z positions
# of the vertices of the body. The y-local-position of the spring-dampers at
# the body is -1.2/2 and the local position for ground is y=0. All spring-dampers
# have equal parameters: stiffness = [20000,100000,12000] N/m and damping = [400,2000,400]
# Ns/m. Gravity g = 9.81 m/s^2 acts in negative y-direction, and no further forces
# or damping are applied and contact with ground is ignored.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

rbX = 3
rbY = 1.2
rbZ = 2

mass = 400 * rbX * rbY * rbZ
inertiaCube = InertiaCuboid(density=mass/(rbX*rbY*rbZ), sideLengths=[rbX,rbY,rbZ])

oBody = mbs.CreateRigidBody(inertia = inertiaCube,
                            referencePosition = [0,rbY/2,0],
                            gravity = [0,-9.81,0])

stiffness = [20000,100000,12000]
damping = [400,2000,400]

mbs.CreateCartesianSpringDamper(bodyNumbers=[oGround, oBody], localPosition0=[rbX/2,0,rbZ/2], localPosition1=[rbX/2,-rbY/2,rbZ/2], stiffness=stiffness, damping=damping)
mbs.CreateCartesianSpringDamper(bodyNumbers=[oGround, oBody], localPosition0=[-rbX/2,0,rbZ/2], localPosition1=[-rbX/2,-rbY/2,rbZ/2], stiffness=stiffness, damping=damping)
mbs.CreateCartesianSpringDamper(bodyNumbers=[oGround, oBody], localPosition0=[rbX/2,0,-rbZ/2], localPosition1=[rbX/2,-rbY/2,-rbZ/2], stiffness=stiffness, damping=damping)
mbs.CreateCartesianSpringDamper(bodyNumbers=[oGround, oBody], localPosition0=[-rbX/2,0,-rbZ/2], localPosition1=[-rbX/2,-rbY/2,-rbZ/2], stiffness=stiffness, damping=damping)

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 5e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 5e-3
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=1
SC.visualizationSettings.openGL.lineWidth = 3

#start solver:
mbs.SolveDynamic(simulationSettings)

