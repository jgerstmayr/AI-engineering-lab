# ** given model description: **
# A free flying rigid body with brick-shape, density = 120 kg/m^3, and xyz-dimensions
# of the cuboid lx=3m, wy=1m, hz=1.2m is investigated. The COM of the body is
# initially located at [0,0,0]. The initial velocity shall be [3,1,3] and the initial
# angular velocity is [1.25,0.6,0.75]. Gravity g = 9.81 m/s^2 acts in negative z-direction.
# Contact with ground is not considered and no further forces act on the point mass.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

lx = 3
wy = 1
hz = 1.2

mass = 120 * lx * wy * hz
inertiaCube = InertiaCuboid(density=120, sideLengths=[lx, wy, hz])

oBody = mbs.CreateRigidBody(inertia=inertiaCube,
                            referencePosition=[0,0,0],
                            initialVelocity=[3,1,3],
                            initialAngularVelocity=[1.25,0.6,0.75],
                            gravity=[0,-9.81,0])

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 5e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 5e-3
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=1
SC.visualizationSettings.openGL.lineWidth = 3

#start solver:
mbs.SolveDynamic(simulationSettings)

