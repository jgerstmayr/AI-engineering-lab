# ** given model description: **
# A rigid body is suspended by 4 Cartesian spring-dampers. The rigid body
# has a brick-shape with density = 400 kg/m^3, and xyz-dimensions lx=5m, ly=0.8m,
# lz=1.25m. The reference point of the body, which is equal to the COM, is located
# initially at [0,0.8/2,0]. The Cartesian spring-dampers are located at the x/z positions
# of the vertices of the body. The y-local-position of the spring-dampers at
# the body is -0.8/2 and the local position for ground is y=0. All spring-dampers
# have equal parameters: stiffness = [12000,125000,20000] N/m and damping = [200,2000,250]
# Ns/m. Gravity g = 11.15 m/s^2 acts in negative y-direction, and no further forces
# or damping are applied and contact with ground is ignored.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

lx = 5
ly = 0.8
lz = 1.25

mass = 400 * lx * ly * lz
inertiaCube = InertiaCuboid(density=mass/(lx*ly*lz), sideLengths=[lx,ly,lz])

oBody = mbs.CreateRigidBody(inertia = inertiaCube,
                            referencePosition = [0,ly/2,0],
                            gravity = [0,-11.15,0])

spring_dampers = [
    [0, lx/2, lz/2],
    [-lx/2, lz/2, 0],
    [lx/2, lz/2, 0],
    [0, lz/2, -lz/2]
]

for pos in spring_dampers:
    mbs.CreateCartesianSpringDamper(
        bodyNumbers=[oGround, oBody],
        localPosition0=[pos[0], 0, pos[2]],
        localPosition1=[pos[0], -ly/2, pos[2]],
        stiffness = [12000,125000,20000],
        damping = [200,2000,250]
    )

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 5e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 5e-3
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=1
SC.visualizationSettings.openGL.lineWidth = 3

#start solver:
mbs.SolveDynamic(simulationSettings)

