# ** given model description: **
# A system consisting of a brick-shaped rigid body freely moving on a prismatic
# joint in z-direction. The COM of the rigid body is placed at [0,0,0]. The rigid
# body has a mass of m = 6 kg and the side lengths of the body are all equal with
# s = 0.75 m. A force f = 8 N acts on the rigid body's COM in z-direction.
# Gravity is neglected.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

s = 0.75
mass = 6
volume = s**3
inertiaCube = InertiaCuboid(density=mass/volume, sideLengths=[s,s,s])

oBody = mbs.CreateRigidBody(inertia = inertiaCube,
                            referencePosition = [0,0,0],
                            gravity = [0,0,0])

loadRigidBody = mbs.CreateForce(bodyNumber=oBody, localPosition=[0,0,0], loadVector=[0,0,8])

mbs.CreatePrismaticJoint(bodyNumbers=[oGround, oBody],
                         position=[0,0,0],
                         axis=[0,0,1],
                         useGlobalFrame=True)

mbs.Assemble()

tEnd = 1
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 5e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 5e-3
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=1
SC.visualizationSettings.openGL.lineWidth = 3


#start solver:
mbs.SolveDynamic(simulationSettings)


