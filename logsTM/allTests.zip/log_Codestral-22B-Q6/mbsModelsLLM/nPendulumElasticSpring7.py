# ** given model description: **
# Multibody n-pendulum system consisting of 8 point masses connected with
# spring-dampers with the following properties: masses m = 0.75 kg, lengths of single elastic
# strings l_single = 0.4 m, stiffness k = 7500 and damping d = 300 of strings, and
# gravity g = 9.81 m/s^2 which acts in negative y-direction. The pendulum starts
# from horizontal configuration, where all masses are aligned with the x-axis,
# the first mass located at x=0.4, with a spring-damper connected to ground.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

mass = 0.75
gravity = [0, -9.81, 0]
length = 0.4
stiffness = 7500
damping = 300

oMasses = []
oSpringDampers = []

for i in range(8):
    oMass = mbs.CreateMassPoint(physicsMass=mass, referencePosition=[(i+1)*length, 0, 0], gravity=gravity)
    oMasses.append(oMass)

    if i == 0:
        oSpringDamper = mbs.CreateSpringDamper(bodyNumbers=[oGround, oMass], stiffness=stiffness, damping=damping)
    else:
        oSpringDamper = mbs.CreateSpringDamper(bodyNumbers=[oMasses[i-1], oMass], stiffness=stiffness, damping=damping)

    oSpringDampers.append(oSpringDamper)

mbs.Assemble()

tEnd = 0.5
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 5e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.06
SC.visualizationSettings.nodes.tiling = 16
SC.visualizationSettings.connectors.defaultSize = 0.02 #spring


#start solver:
mbs.SolveDynamic(simulationSettings)


