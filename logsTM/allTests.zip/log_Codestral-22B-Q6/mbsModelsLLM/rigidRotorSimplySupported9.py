# ** given model description: **
# A rotor is modelled with a rigid body mounted on ground with Cartesian
# spring-dampers. The rotor is modelled as cylinder with mass m = 2 kg, disc radius r = 0.15
# m, and length = 0.5 m. The axis of the rotor is initially oriented along the
# x-axis and the reference point of the rotor lies at [0,0,0] (which is also the
# COM). The rotor is connected to ground with two Cartesian spring-dampers at global
# position [-0.5/2,0,0] resp. [0.5/2,0,0], the positions being identical with the
# local positions of the spring-dampers on the rotor. The Cartesian spring-dampers
# have stiffness values [1200,2000,2000] N/m and damping values [7.5,12,12] Ns/m.
# The initial angular velocity of the rotor is [500,0,0]. Gravity g = 3.73 m/s^2
# acts in negative z-direction, and no further forces or damping are applied.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

mass = 2
outerRadius = 0.15
length = 0.5
volume = np.pi * outerRadius**2 * length
inertiaCylinder = InertiaCylinder(density=mass/volume, length=length, outerRadius=outerRadius, axis=0)

oBody = mbs.CreateRigidBody(inertia=inertiaCylinder,
                            referencePosition=[0,0,0],
                            initialAngularVelocity=[500,0,0],
                            gravity=[0,0,-3.73])

springStiffness = [1200,2000,2000]
dampingCoefficients = [7.5,12,12]
springPositions = [[-0.5/2,0,0], [0.5/2,0,0]]

for i in range(2):
    mbs.CreateCartesianSpringDamper(bodyOrGroundNodeID=oGround,
                                    connectedBodyID=oBody,
                                    stiffness=springStiffness,
                                    damping=dampingCoefficients,
                                    springForce=[0,0,0],
                                    referencePosition=springPositions[i],
                                    connectionPoint=springPositions[i])

mbs.Assemble()

tEnd = 2
stepSize = 0.0002 #for large rotation speeds

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 2e-1
simulationSettings.solutionSettings.sensorsWritePeriod = 5e-3
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd
# simulationSettings.timeIntegration.verboseMode = 1

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=1
SC.visualizationSettings.openGL.lineWidth = 3
SC.visualizationSettings.general.drawCoordinateSystem = False
SC.visualizationSettings.general.drawWorldBasis = True

#start solver:
mbs.SolveDynamic(simulationSettings)

