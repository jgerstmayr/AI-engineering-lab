# ** given model description: **
# A 3D mass point with mass m = 1.2 kg is attached to a string with length
# 0.3 m, with a predominant rotation around the z-axis due to centrifugal forces.
#  Gravity g = 3.73 m/s^2 acts in negative z-direction. The mass point is
# placed initially at [0.3,0,0] and the initial velocity is [0,7.5,0], given in
# m/s. The string shall be modelled as rigid distance between the mass point and
# the ground position at [0,0,0].
import exudyn as exu
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

oMassPoint = mbs.CreateMassPoint(physicsMass=1.2, referencePosition=[0.3,0,0], initialVelocity=[0,7.5,0], gravity=[0,0,-3.73])

oDistance = mbs.CreateDistanceConstraint(bodyNumbers=[oGround, oMassPoint], localPosition0=[0,0,0], localPosition1=[0,0,0], distance=0.3)

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 5e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.05
SC.visualizationSettings.nodes.tiling = 32


#start solver:
mbs.SolveDynamic(simulationSettings)


