# ** given model description: **
# A serial chain of 3 masses connected with springs-dampers. Each mass has
# m = 5 kg, the stiffnesses are k = 3000 N/m, and the damping coefficients
# are d = 40 Ns/m. A force f = 80 N is applied to the last mass (with highest
# index). The first mass is connected to ground via the first spring-damper. The
# relaxed length of each spring is 0.2 m, and the first mass is located at y = 0.2
# m. The serial chain is oriented along the global y-axis. Gravity acts in positive
# y-direction, with g = 3.73 m/s^2.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

masses = []
spring_dampers = []

for i in range(3):
    mass = mbs.CreateMassPoint(physicsMass=5, referencePosition=[0, 0.2 + i*0.2, 0], gravity=[0, 3.73, 0])
    masses.append(mass)

    if i > 0:
        spring_damper = mbs.CreateSpringDamper(bodyNumbers=[masses[i-1], mass], localPosition0=[0, 0, 0], localPosition1=[0, 0, 0], referenceLength=0.2, stiffness=3000, damping=40)
        spring_dampers.append(spring_damper)

loadMassPoint = mbs.CreateForce(bodyNumber=masses[-1], loadVector=[0, 80, 0])

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 1e-1
simulationSettings.solutionSettings.sensorsWritePeriod = 5e-3
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.1


#start solver:
mbs.SolveDynamic(simulationSettings)


