# ** given model description: **
# Multibody n-pendulum system consisting of 4 point masses connected with
# spring-dampers with the following properties: masses m = 1.25 kg, lengths of single elastic
# strings l_single = 0.4 m, stiffness k = 1500 and damping d = 500 of strings, and
# gravity g = 9.81 m/s^2 which acts in negative y-direction. The pendulum starts
# from horizontal configuration, where all masses are aligned with the x-axis,
# the first mass located at x=0.4, with a spring-damper connected to ground.
import exudyn as exu
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

mass = 1.25
length = 0.4
stiffness = 1500
damping = 500
gravity = [0, -9.81, 0]

oMass1 = mbs.CreateMassPoint(physicsMass=mass, referencePosition=[length, 0, 0], gravity=gravity)
mbs.CreateSpringDamper(bodyNumbers=[oGround, oMass1], stiffness=stiffness, damping=damping)

oMass2 = mbs.CreateMassPoint(physicsMass=mass, referencePosition=[2*length, 0, 0], gravity=gravity)
mbs.CreateSpringDamper(bodyNumbers=[oMass1, oMass2], stiffness=stiffness, damping=damping)

oMass3 = mbs.CreateMassPoint(physicsMass=mass, referencePosition=[3*length, 0, 0], gravity=gravity)
mbs.CreateSpringDamper(bodyNumbers=[oMass2, oMass3], stiffness=stiffness, damping=damping)

oMass4 = mbs.CreateMassPoint(physicsMass=mass, referencePosition=[4*length, 0, 0], gravity=gravity)
mbs.CreateSpringDamper(bodyNumbers=[oMass3, oMass4], stiffness=stiffness, damping=damping)

mbs.Assemble()

tEnd = 0.5
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 5e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.06
SC.visualizationSettings.nodes.tiling = 16
SC.visualizationSettings.connectors.defaultSize = 0.02 #spring


#start solver:
mbs.SolveDynamic(simulationSettings)


