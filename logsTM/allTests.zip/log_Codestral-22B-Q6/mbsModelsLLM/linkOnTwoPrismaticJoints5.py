# ** given model description: **
# A system consisting of two mass points connected by a distance constraint.
# The first mass m1 = 15 kg is initially located at x0 = 1.2 m (other coordinates
# are 0) and can freely move only along the x-axis, while y-axis and z-axis are
# constrained by a spherical joint. The second mass m2 = 1.2 kg is initially located
# at y0 = 0.5 m (other coordinates are 0) and can move only freely along the
# y-axis, while the other two axes are constrained by a spherical joint. Furthermore,
# a distance constraint is added between the two mass points and the length
# shall be computed automatically. A spring with stiffness = 500 N/m is used to
# connect mass m1 and ground at [0,0,0]. Gravity g = 9.81 m/s^2 acts in positive
# z-direction, and no further forces or damping are applied.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

m1 = 15
x0 = 1.2
oMass1 = mbs.CreateMassPoint(physicsMass=m1, referencePosition=[x0,0,0], gravity=[0,0,-9.81])
mbs.CreateSphericalJoint(bodyNumbers=[oGround, oMass1], position=[x0,0,0], constrainedAxes=[0,1,1])

m2 = 1.2
y0 = 0.5
oMass2 = mbs.CreateMassPoint(physicsMass=m2, referencePosition=[0,y0,0], gravity=[0,0,-9.81])
mbs.CreateSphericalJoint(bodyNumbers=[oGround, oMass2], position=[0,y0,0], constrainedAxes=[1,0,1])

oDistance = mbs.CreateDistanceConstraint(bodyNumbers=[oMass1, oMass2], localPosition0=[0,0,0], localPosition1=[0,0,0], distance=None)

stiffness = 500
oSpring = mbs.CreateSpringDamper(bodyNumbers=[oGround, oMass1], localPosition0=[0,0,0], localPosition1=[0,0,0], stiffness=stiffness, damping=0)

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 1e-1
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.05
SC.visualizationSettings.nodes.tiling = 32

#start solver:
mbs.SolveDynamic(simulationSettings)

