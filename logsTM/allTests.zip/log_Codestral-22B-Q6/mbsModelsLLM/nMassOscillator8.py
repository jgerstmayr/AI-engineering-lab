# ** given model description: **
# A serial chain of 2 masses connected with springs-dampers. Each mass has
# m = 10 kg, the stiffnesses are k = 5000 N/m, and the damping coefficients
# are d = 50 Ns/m. A force f = 100 N is applied to the last mass (with highest
# index). The first mass is connected to ground via the first spring-damper. The
# relaxed length of each spring is 0.2 m, and the first mass is located at x = 0.2
# m. The serial chain is oriented along the global x-axis. Gravity acts in positive
# x-direction, with g = 11.15 m/s^2.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

m = 10
k = 5000
d = 50
f = 100
g = 11.15

oMass1 = mbs.CreateMassPoint(physicsMass=m, referencePosition=[0.2,0,0], gravity=[g,0,0])
oMass2 = mbs.CreateMassPoint(physicsMass=m, referencePosition=[0.4,0,0], gravity=[g,0,0])

oSpringDamper1 = mbs.CreateSpringDamper(bodyNumbers=[oGround, oMass1], localPosition0=[0,0,0], localPosition1=[0,0,0], referenceLength=0.2, stiffness=k, damping=d)
oSpringDamper2 = mbs.CreateSpringDamper(bodyNumbers=[oMass1, oMass2], localPosition0=[0,0,0], localPosition1=[0,0,0], referenceLength=0.2, stiffness=k, damping=d)

loadMassPoint = mbs.CreateForce(bodyNumber=oMass2, loadVector=[f,0,0])

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 1e-1
simulationSettings.solutionSettings.sensorsWritePeriod = 5e-3
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.1


#start solver:
mbs.SolveDynamic(simulationSettings)


