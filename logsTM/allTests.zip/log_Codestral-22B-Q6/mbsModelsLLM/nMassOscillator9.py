# ** given model description: **
# A serial chain of 5 masses connected with springs-dampers. Each mass has
# m = 6 kg, the stiffnesses are k = 5000 N/m, and the damping coefficients
# are d = 60 Ns/m. A force f = 100 N is applied to the last mass (with highest
# index). The first mass is connected to ground via the first spring-damper. The
# relaxed length of each spring is 0.25 m, and the first mass is located at x = 0.25
# m. The serial chain is oriented along the global x-axis. Gravity acts in positive
# x-direction, with g = 3.73 m/s^2.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

masses = []
spring_dampers = []

for i in range(5):
    oMass = mbs.CreateMassPoint(physicsMass=6, referencePosition=[0.25 + i*0.25, 0, 0], gravity=[3.73, 0, 0])
    masses.append(oMass)

    if i > 0:
        oSpringDamper = mbs.CreateSpringDamper(bodyNumbers=[masses[i-1], oMass], stiffness=5000, damping=60, referenceLength=0.25)
        spring_dampers.append(oSpringDamper)

loadMassPoint = mbs.CreateForce(bodyNumber=masses[-1], loadVector=[100, 0, 0])

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 1e-1
simulationSettings.solutionSettings.sensorsWritePeriod = 5e-3
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.1


#start solver:
mbs.SolveDynamic(simulationSettings)


