# ** given model description: **
# Multibody n-pendulum system consisting of 7 point masses connected with
# spring-dampers with the following properties: masses m = 1.2 kg, lengths of single elastic
# strings l_single = 1 m, stiffness k = 6000 and damping d = 300 of strings, and
# gravity g = 11.15 m/s^2 which acts in negative y-direction. The pendulum starts
# from horizontal configuration, where all masses are aligned with the x-axis,
# the first mass located at x=1, with a spring-damper connected to ground.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

mass = 1.2
gravity = [0, -11.15, 0]
num_masses = 7
length_single = 1
stiffness = 6000
damping = 300

oMasses = []
oSpringDampers = []

for i in range(num_masses):
    oMass = mbs.CreateMassPoint(physicsMass=mass, referencePosition=[i*length_single, 0, 0], gravity=gravity)
    oMasses.append(oMass)

    if i > 0:
        oSpringDamper = mbs.CreateSpringDamper(bodyNumbers=[oMasses[i-1], oMass], localPosition0=[length_single, 0, 0], localPosition1=[-length_single, 0, 0], stiffness=stiffness, damping=damping)
        oSpringDampers.append(oSpringDamper)

oSpringDamperGround = mbs.CreateSpringDamper(bodyNumbers=[oGround, oMasses[0]], localPosition0=[0, 0, 0], localPosition1=[length_single, 0, 0], stiffness=stiffness, damping=damping)

mbs.Assemble()

tEnd = 0.5
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 5e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.06
SC.visualizationSettings.nodes.tiling = 16
SC.visualizationSettings.connectors.defaultSize = 0.02 #spring


#start solver:
mbs.SolveDynamic(simulationSettings)


