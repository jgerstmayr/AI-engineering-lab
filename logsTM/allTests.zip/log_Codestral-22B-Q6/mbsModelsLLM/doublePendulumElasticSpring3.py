# ** given model description: **
# Double pendulum consisting of two mass points which are connected with
# elastic springs with the following properties: mass m1 = 3 kg, mass m2 = 1.5 kg,
# length of the strings L1 = 1.2 m, L2 = 1 m, stiffnesses k1 = 1250 and k2 = 500,
# and gravity g = 3.73 m/s^2 which acts in negative y-direction. The first arm
# of the pendulum points in negative x-direction and the second arm in positive
# x-direction.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

oMass1 = mbs.CreateMassPoint(physicsMass=3, referencePosition=[-1.2,0,0], gravity=[0,-3.73,0])
oMass2 = mbs.CreateMassPoint(physicsMass=1.5, referencePosition=[1,0,0], gravity=[0,-3.73,0])

oSpringDamper1 = mbs.CreateSpringDamper(bodyNumbers=[oGround, oMass1], stiffness=1250)
oSpringDamper2 = mbs.CreateSpringDamper(bodyNumbers=[oMass1, oMass2], stiffness=500)

mbs.Assemble()

tEnd = 1
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 1e-1
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.1
SC.visualizationSettings.nodes.tiling = 32
SC.visualizationSettings.connectors.defaultSize = 0.05 #spring


#start solver:
mbs.SolveDynamic(simulationSettings)


