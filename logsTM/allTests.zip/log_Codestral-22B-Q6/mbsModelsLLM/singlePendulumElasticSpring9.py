# ** given model description: **
# Simple mathematical pendulum with the following properties: point mass
# m = 1.5 kg, elastic string length = 0.5 m, string stiffness k = 800 N/m,
# and gravity g = 9.81 m/s^2 which is applied in negative y-direction. The pendulum's
# reference configuration is such that the string has an angle 20 degrees from the
# vertical (negative y-axis), thus the mass being on a positive x-coordinate for positive
# angles. The initial velocities of the mass point are v_x = -0.25 m/s and v_y =
# -0.3 m/s, applied in x resp. y direction.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

oMass = mbs.CreateMassPoint(physicsMass=1.5, referencePosition=[0.5*np.cos(np.deg2rad(20)), -0.5*np.sin(np.deg2rad(20)), 0],
                            initialDisplacement=[0,0,0],
                            initialVelocity=[-0.25, -0.3, 0],
                            gravity=[0, -9.81, 0])

oSpringDamper = mbs.CreateSpringDamper(bodyNumbers=[oGround, oMass],
                                      localPosition0=[0,0,0],
                                      localPosition1=[0,0,0],
                                      referenceLength=0.5,
                                      stiffness=800, damping=0)

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 5e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.2
SC.visualizationSettings.nodes.tiling = 32
SC.visualizationSettings.connectors.defaultSize = 0.05 #spring


#start solver:
mbs.SolveDynamic(simulationSettings)


