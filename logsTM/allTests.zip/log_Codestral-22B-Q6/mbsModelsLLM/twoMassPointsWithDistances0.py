# ** given model description: **
# Two mass points connected by distance constraint. The mass points both
# have mass m1 = m2 = 2 kg, are initially located at p1 = [-0.75,0,0] and p2 =
# [0.75,0,0], positions given in m. Mass m1 has initial velocity vy = 1.25 m/s and m2
# has initial velocity vy = -1.25 m/s while all other initial velocity components
# are zero. No gravity nor forces are present.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

m1 = 2
m2 = 2
p1 = [-0.75,0,0]
p2 = [0.75,0,0]
vy1 = 1.25
vy2 = -1.25

oMass1 = mbs.CreateMassPoint(physicsMass=m1, referencePosition=p1, initialVelocity=[0,vy1,0])
oMass2 = mbs.CreateMassPoint(physicsMass=m2, referencePosition=p2, initialVelocity=[0,vy2,0])

oDistance = mbs.CreateDistanceConstraint(bodyNumbers=[oMass1, oMass2], localPosition0=[0,0,0], localPosition1=[0,0,0], distance=None)

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 1e-1
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.05
SC.visualizationSettings.nodes.tiling = 32

#start solver:
mbs.SolveDynamic(simulationSettings)

