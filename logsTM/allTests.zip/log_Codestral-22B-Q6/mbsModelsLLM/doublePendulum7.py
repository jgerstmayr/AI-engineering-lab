# ** given model description: **
# Double pendulum system consisting of two mass points which are connected
# with inextensible strings with the following properties: mass m1 = 2.5 kg, mass
# m2 = 1.25 kg, length of the strings L1 = 1 m, L2 = 0.75 m, and gravity g =
# 11.15 m/s^2 which acts in negative y-direction. The first arm of the pendulum
# points in positive x direction and the second arm in positive y-direction. The
# strings are massless, inelastic and the length shall be constrained. Air resistance
# is neglected.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

m1 = 2.5
m2 = 1.25
L1 = 1
L2 = 0.75
g = 11.15

oMass1 = mbs.CreateMassPoint(physicsMass=m1, referencePosition=[L1,0,0], gravity=[0,-g,0])
oMass2 = mbs.CreateMassPoint(physicsMass=m2, referencePosition=[L1+L2,0,0], gravity=[0,-g,0])

oSpringDamper1 = mbs.CreateSpringDamper(bodyNumbers=[oGround, oMass1], localPosition0=[0,0,0], localPosition1=[0,0,0], referenceLength=L1, stiffness=1e5, damping=0)
oSpringDamper2 = mbs.CreateSpringDamper(bodyNumbers=[oMass1, oMass2], localPosition0=[0,0,0], localPosition1=[0,0,0], referenceLength=L2, stiffness=1e5, damping=0)

oDistance1 = mbs.CreateDistanceConstraint(bodyNumbers=[oGround, oMass1], localPosition0=[0,0,0], localPosition1=[0,0,0], distance=L1)
oDistance2 = mbs.CreateDistanceConstraint(bodyNumbers=[oMass1, oMass2], localPosition0=[0,0,0], localPosition1=[0,0,0], distance=L2)

mbs.Assemble()

tEnd = 1
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 1e-1
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.05
SC.visualizationSettings.nodes.tiling = 32


#start solver:
mbs.SolveDynamic(simulationSettings)


