# ** given model description: **
# A free flying rigid body with brick-shape, density = 125 kg/m^3, and xyz-dimensions
# of the cuboid lx=4m, wy=0.6m, hz=1.25m is investigated. The COM of the body
# is initially located at [0,0,0]. The initial velocity shall be [3,1.2,1.25]
# and the initial angular velocity is [1.5,0.8,0.5]. Gravity g = 3.73 m/s^2 acts
# in negative y-direction. Contact with ground is not considered and no further
# forces act on the point mass.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

lx = 4
wy = 0.6
hz = 1.25
density = 125
mass = density * lx * wy * hz
inertiaCube = InertiaCuboid(density=density, sideLengths=[lx, wy, hz])

oBody = mbs.CreateRigidBody(inertia=inertiaCube,
                            referencePosition=[0,0,0],
                            initialVelocity=[3,1.2,1.25],
                            initialAngularVelocity=[1.5,0.8,0.5],
                            gravity=[0,-3.73,0])

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 5e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 5e-3
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=1
SC.visualizationSettings.openGL.lineWidth = 3

#start solver:
mbs.SolveDynamic(simulationSettings)

