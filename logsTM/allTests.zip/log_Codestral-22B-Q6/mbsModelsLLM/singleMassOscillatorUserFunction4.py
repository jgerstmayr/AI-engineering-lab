# ** given model description: **
# Mass-spring-damper with the following properties: mass m = 8 kg, stiffness
# k = 1250 N/m, and damping d = 15 Ns/m. The force applied to the mass only
# in x-direction is given by the time-dependent function f(t) = 80.*t**2. The
# spring-damper is aligned with the x-axis and the spring has a length of 0.3 m and is
# relaxed in the initial position. Gravity is neglected.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

oMass = mbs.CreateMassPoint(physicsMass=8, referencePosition=[0.3,0,0], gravity=[0,0,0])

oSpringDamper = mbs.CreateSpringDamper(bodyNumbers=[oGround, oMass],
                                      localPosition0=[0,0,0],
                                      localPosition1=[0,0,0],
                                      referenceLength=0.3,
                                      stiffness=1250, damping=15)

def UFforce(mbs, t, loadVector):
    return np.array([80.*t**2, 0, 0])

mbs.CreateForce(bodyNumber=oMass,
                localPosition=[0,0,0],
                loadVectorUserFunction=UFforce)

mbs.Assemble()

tEnd = 1.2
stepSize = 0.002

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 1e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 5e-3
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.openGL.lineWidth = 3
SC.visualizationSettings.nodes.defaultSize=0.05
SC.visualizationSettings.nodes.tiling = 16
SC.visualizationSettings.connectors.defaultSize = 0.005 #spring


#start solver:
mbs.SolveDynamic(simulationSettings)


