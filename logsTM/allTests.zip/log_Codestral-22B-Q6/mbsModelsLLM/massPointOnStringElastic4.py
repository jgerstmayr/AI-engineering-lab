# ** given model description: **
# A 3D mass point with mass m = 1 kg is attached to a string with length
# 0.4 m, with a predominant rotation around the z-axis due to centrifugal forces.
# Gravity g = 9.81 m/s^2 acts in negative z-direction. The mass point is placed initially
# at [0.4,0,0] and the initial velocity is [0,6,0], given in m/s. The elastic
# string shall be modelled as spring-damper with stiffness k = 2500 N/m and damping
# d = 30 Ns/m, which connects the mass point and the ground position at [0,0,0].
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

oMass = mbs.CreateMassPoint(physicsMass=1, referencePosition=[0.4,0,0],
                            initialDisplacement=[0,0,0],
                            initialVelocity=[0,6,0],
                            gravity=[0,-9.81,0])

oSpringDamper = mbs.CreateSpringDamper(bodyNumbers=[oGround, oMass],
                                      localPosition0=[0,0,0],
                                      localPosition1=[0,0,0],
                                      referenceLength=0.4,
                                      stiffness=2500, damping=30)

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 5e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.05
SC.visualizationSettings.nodes.tiling = 32


#start solver:
mbs.SolveDynamic(simulationSettings)


