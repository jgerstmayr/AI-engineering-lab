# ** given model description: **
# Straight elastic chain modelled with 9 mass points connected with spring-dampers
# with the following properties: masses m = 1.5 kg, lengths of each chain element
# l_single = 2 m, stiffness k = 2000 and damping d = 500 of chain elements, and gravity
# g = 11.15 m/s^2 which acts in negative y-direction. The chain starts from
# horizontal configuration, where all masses are aligned with the x-axis, the first
# mass located at x=0. The left-most and right-most spring-dampers are fixed to
# ground using spherical joints.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

masses = []
for i in range(9):
    oMass = mbs.CreateMassPoint(physicsMass=1.5, referencePosition=[i*2,0,0], gravity=[0,-11.15,0])
    masses.append(oMass)

for i in range(8):
    oSpringDamper = mbs.CreateSpringDamper(bodyNumbers=[masses[i], masses[i+1]], stiffness=2000, damping=500)

mbs.CreateSphericalJoint(bodyNumbers=[oGround, masses[0]], position=[0,0,0], constrainedAxes=[1,1,1])
mbs.CreateSphericalJoint(bodyNumbers=[oGround, masses[8]], position=[16,0,0], constrainedAxes=[1,1,1])

mbs.Assemble()

tEnd = 2
stepSize = 0.005

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 0.5
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.5
SC.visualizationSettings.nodes.tiling = 16
SC.visualizationSettings.connectors.defaultSize = 0.05 #spring


#start solver:
mbs.SolveDynamic(simulationSettings)


