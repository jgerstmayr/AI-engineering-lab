# ** given model description: **
# A gyro is modelled with a rigid body and a spherical joint. The gyro is
# modelled as cylindrical disc with mass m = 20 kg, disc radius r = 0.2 m, and disc
# width w = 0.025. The axis of the disc is initially oriented along positive x-axis
# and the disc is positioned at [0.25,0,0] (which is also the COM). The disc
# is connected to ground with a spherical joint at position [0,0,0]. The initial
# angular velocity of the disc is [120,0,0]. Gravity g = 3.73 m/s^2 acts in negative
# z-direction, and no further forces or damping are applied.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

mass = 20
radius = 0.2
width = 0.025
volume = np.pi * radius**2 * width
inertiaCylinder = InertiaCylinder(density=mass/volume, length=width, outerRadius=radius, axis=0)

oBody = mbs.CreateRigidBody(inertia=inertiaCylinder,
                            referencePosition=[0.25,0,0],
                            initialAngularVelocity=[120,0,0],
                            gravity=[0,0,-3.73])

mbs.CreateSphericalJoint(bodyNumbers=[oGround, oBody],
                         position=[0,0,0],
                         constrainedAxes=[1,1,1])

mbs.Assemble()

tEnd = 10
stepSize = 0.0005 #for large rotation speeds

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 5e-1
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=1
SC.visualizationSettings.openGL.lineWidth = 3
SC.visualizationSettings.general.drawCoordinateSystem = False
SC.visualizationSettings.general.drawWorldBasis = True

#start solver:
mbs.SolveDynamic(simulationSettings)

