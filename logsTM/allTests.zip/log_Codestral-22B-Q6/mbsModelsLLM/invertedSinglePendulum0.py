# ** given model description: **
# An inverted pendulum on a cart modelled with two mass points, where the
# cart is attached to ground with a spherical joint where the x-coordinate is
# not constrained, such that it can move along the x-direction. The pendulum
# is modelled with a distance constraint between cart and pendulum mass: cart
# mass m1 = 1.2 kg, pendulum mass m2 = 1.5 kg, pendulum length = 2 m, and gravity
# g = 11.15 m/s^2 which acts in negative y-direction. The pendulum starts from
# the upright position, where m2 is located at the positive y-axis. A disturbance
# force f = 0.075 N acts in x-direction at the pendulum and no control is applied
# on the cart.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

m1 = 1.2
m2 = 1.5
l = 2
g = 11.15

oCart = mbs.CreateMassPoint(physicsMass=m1, referencePosition=[0,0,0])
oPendulum = mbs.CreateMassPoint(physicsMass=m2, referencePosition=[0,l,0])

oDistance = mbs.CreateDistanceConstraint(bodyNumbers=[oCart, oPendulum],
                                         localPosition0=[0,0,0],
                                         localPosition1=[0,0,0],
                                         distance=l)

mbs.CreateSphericalJoint(bodyNumbers=[oGround, oCart],
                         position=[0,0,0],
                         constrainedAxes=[0,1,1])

def UFforce(mbs, t, loadVector):
    return np.array([0.075, 0, 0])

mbs.CreateForce(bodyNumber=oPendulum,
                localPosition=[0,0,0],
                loadVectorUserFunction=UFforce)

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 1e-1
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.05
SC.visualizationSettings.nodes.tiling = 32
SC.visualizationSettings.openGL.lineWidth = 3


#start solver:
mbs.SolveDynamic(simulationSettings)


