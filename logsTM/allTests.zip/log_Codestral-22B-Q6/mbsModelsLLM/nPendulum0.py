# ** given model description: **
# Multibody n-pendulum system consisting of 7 point masses with the following
# properties: masses m = 5 kg, length of inextensible strings l_single = 1 m, and gravity
# g = 9.81 m/s^2. The pendulum starts from horizontal configuration, where
# all masses are aligned along the x-axis (the first mass starting at x=1) and
# all masses have an initial velocity of 0.05 m/s in negative y-direction. Gravity
# acts in negative y-direction and air resistance is neglected. The strings between
# the consecutive masses (and the string between first mass and ground) shall
# be modelled as constrained distances.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

masses = []
for i in range(7):
    oMass = mbs.CreateMassPoint(physicsMass=5, referencePosition=[1+i,0,0],
                                initialDisplacement=[0,0,0],
                                initialVelocity=[0,-0.05,0],
                                gravity=[0,-9.81,0])
    masses.append(oMass)

for i in range(6):
    oDistance = mbs.CreateDistanceConstraint(bodyNumbers=[masses[i], masses[i+1]],
                                             localPosition0 = [0,0,0],
                                             localPosition1 = [0,0,0],
                                             distance=1)

oDistance = mbs.CreateDistanceConstraint(bodyNumbers=[oGround, masses[0]],
                                         localPosition0 = [0,0,0],
                                         localPosition1 = [0,0,0],
                                         distance=1)

mbs.Assemble()

tEnd = 1
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 1e-1
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.05
SC.visualizationSettings.nodes.tiling = 16


#start solver:
mbs.SolveDynamic(simulationSettings)


