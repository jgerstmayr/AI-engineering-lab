# ** given model description: **
# Straight elastic chain modelled with 16 mass points connected with spring-dampers
# with the following properties: masses m = 2.5 kg, lengths of each chain element
# l_single = 2 m, stiffness k = 2500 and damping d = 500 of chain elements, and gravity
# g = 9.81 m/s^2 which acts in negative y-direction. The chain starts from
# horizontal configuration, where all masses are aligned with the x-axis, the first
# mass located at x=0. The left-most and right-most spring-dampers are fixed to
# ground using spherical joints.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

mass = 2.5
length = 2
stiffness = 2500
damping = 500
gravity = [0, -9.81, 0]

oMassPoints = []
for i in range(16):
    oMass = mbs.CreateMassPoint(physicsMass=mass, referencePosition=[i*length, 0, 0], gravity=gravity)
    oMassPoints.append(oMass)

for i in range(15):
    oSpringDamper = mbs.CreateSpringDamper(bodyNumbers=[oMassPoints[i], oMassPoints[i+1]],
                                           stiffness=stiffness, damping=damping)

mbs.CreateSphericalJoint(bodyNumbers=[oGround, oMassPoints[0]], position=[0, 0, 0], constrainedAxes=[1, 1, 1])
mbs.CreateSphericalJoint(bodyNumbers=[oGround, oMassPoints[-1]], position=[15*length, 0, 0], constrainedAxes=[1, 1, 1])

mbs.Assemble()

tEnd = 2
stepSize = 0.005

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 0.5
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.5
SC.visualizationSettings.nodes.tiling = 16
SC.visualizationSettings.connectors.defaultSize = 0.05 #spring


#start solver:
mbs.SolveDynamic(simulationSettings)


