# ** given model description: **
# Multibody n-pendulum system consisting of 6 point masses connected with
# spring-dampers with the following properties: masses m = 3 kg, lengths of single elastic
# strings l_single = 1.25 m, stiffness k = 2500 and damping d = 120 of strings, and
# gravity g = 3.73 m/s^2 which acts in negative y-direction. The pendulum starts
# from horizontal configuration, where all masses are aligned with the x-axis,
# the first mass located at x=1.25, with a spring-damper connected to ground.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

mass = 3
length = 1.25
stiffness = 2500
damping = 120
gravity = 3.73

oMasses = []
oSpringDampers = []

for i in range(6):
    oMass = mbs.CreateMassPoint(physicsMass=mass, referencePosition=[(i+1)*length,0,0], gravity=[0,-gravity,0])
    oMasses.append(oMass)

    if i > 0:
        oSpringDamper = mbs.CreateSpringDamper(bodyNumbers=[oMasses[i-1], oMass], localPosition0=[length,0,0], localPosition1=[-length,0,0], stiffness=stiffness, damping=damping)
        oSpringDampers.append(oSpringDamper)

mbs.Assemble()

tEnd = 0.5
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 5e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.06
SC.visualizationSettings.nodes.tiling = 16
SC.visualizationSettings.connectors.defaultSize = 0.02 #spring


#start solver:
mbs.SolveDynamic(simulationSettings)


