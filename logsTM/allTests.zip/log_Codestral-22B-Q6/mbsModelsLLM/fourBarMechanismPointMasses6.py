# ** given model description: **
# A planar four-bar mechanism modelled with 2 points masses and the 3 moving
# bars modeled as massless distance constraints. The origin point of the mechanism
# on ground is located at [0,0,0], mass 1 with m1 = 4 kg is located at [0,0.2,0],
# mass 2 with m2 = 1.5 kg is located at [0.8,0.2,0] and the final additional ground
# point is at [0.8,-0.15,0]. Gravity g = 9.81 m/s^2 acts in negative y-direction
# and mass 1 has an initial velocity of [0.75,0,0]. There is no friction or other
# resistance.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

oMass1 = mbs.CreateMassPoint(physicsMass=4, referencePosition=[0,0.2,0], initialVelocity=[0.75,0,0], gravity=[0,-9.81,0])
oMass2 = mbs.CreateMassPoint(physicsMass=1.5, referencePosition=[0.8,0.2,0], gravity=[0,-9.81,0])

oDistance1 = mbs.CreateDistanceConstraint(bodyNumbers=[oGround, oMass1], localPosition0=[0,0,0], localPosition1=[0,0,0], distance=None)
oDistance2 = mbs.CreateDistanceConstraint(bodyNumbers=[oMass1, oMass2], localPosition0=[0,0,0], localPosition1=[0,0,0], distance=None)
oDistance3 = mbs.CreateDistanceConstraint(bodyNumbers=[oMass2, oGround], localPosition0=[0,0,0], localPosition1=[0.8,-0.15,0], distance=None)

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 5e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.05
SC.visualizationSettings.nodes.tiling = 32


#start solver:
mbs.SolveDynamic(simulationSettings)


