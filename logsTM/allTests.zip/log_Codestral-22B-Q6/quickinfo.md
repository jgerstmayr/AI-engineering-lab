
***

RunMBSmodelTests: using LLM model: Codestral-22B-v0.1-Q6_K.gguf

***

Creating simulation code for mbs models: ['flyingMassPoint', 'freeFallMassPoint', 'singleMassOscillator', 'singleMassOscillatorGravity', 'sliderCrankSimple', 'singlePendulumElasticSpring', 'singleMassOscillatorUserFunction', 'spinningDisc', 'doubleMassOscillator', 'nMassOscillator', 'singlePendulum', 'doublePendulum', 'nPendulum', 'fourBarMechanismPointMasses', 'springCoupledFlyingRigidBodies', 'torsionalOscillator', 'invertedSinglePendulum', 'discRollingOnGround', 'doublePendulumElasticSpring', 'nPendulumElasticSpring', 'elasticChain', 'singlePendulumRigidBody', 'massPointOnStringRigid', 'massPointOnStringElastic', 'linkOnTwoPrismaticJoints', 'flyingRigidBody', 'suspendedRigidBody', 'gyroscopeOnSphericalJoint', 'prismaticJointSystem', 'twoMassPointsWithSprings', 'twoMassPointsWithDistances', 'rigidRotorSimplySupported', 'rigidRotorUnbalanced', 'doublePendulumRigidBodies', 'sliderCrankRigidBodies']

***

RunMBSmodelTests: using Exudyn version: 1.9.83.dev1

***

Creating simulation code for flyingMassPoint; random ID0 / 10; model ID0 / 35

***

 - executable=True, diff=0

***

Creating simulation code for flyingMassPoint; random ID1 / 10; model ID0 / 35

***

 - executable=True, diff=0

***

Creating simulation code for flyingMassPoint; random ID2 / 10; model ID0 / 35; time to go=2408.85s

***

 - executable=True, diff=0

***

Creating simulation code for flyingMassPoint; random ID3 / 10; model ID0 / 35; time to go=2315.43s

***

 - executable=True, diff=0

***

Creating simulation code for flyingMassPoint; random ID4 / 10; model ID0 / 35; time to go=2244.29s

***

 - executable=True, diff=0

***

Creating simulation code for flyingMassPoint; random ID5 / 10; model ID0 / 35; time to go=2313.19s

***

 - executable=True, diff=0

***

Creating simulation code for flyingMassPoint; random ID6 / 10; model ID0 / 35; time to go=2361.41s

***

 - executable=True, diff=0

***

Creating simulation code for flyingMassPoint; random ID7 / 10; model ID0 / 35; time to go=2310.01s

***

 - executable=True, diff=0

***

Creating simulation code for flyingMassPoint; random ID8 / 10; model ID0 / 35; time to go=2266.28s

***

 - executable=True, diff=0

***

Creating simulation code for flyingMassPoint; random ID9 / 10; model ID0 / 35; time to go=2297.77s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; random ID0 / 10; model ID1 / 35; time to go=2269.76s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; random ID1 / 10; model ID1 / 35; time to go=2274.55s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; random ID2 / 10; model ID1 / 35; time to go=2291.97s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; random ID3 / 10; model ID1 / 35; time to go=2290.2s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; random ID4 / 10; model ID1 / 35; time to go=2287.87s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; random ID5 / 10; model ID1 / 35; time to go=2285.54s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; random ID6 / 10; model ID1 / 35; time to go=2281.95s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; random ID7 / 10; model ID1 / 35; time to go=2277.43s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; random ID8 / 10; model ID1 / 35; time to go=2273.15s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; random ID9 / 10; model ID1 / 35; time to go=2268.59s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillator; random ID0 / 10; model ID2 / 35; time to go=2263.95s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillator; random ID1 / 10; model ID2 / 35; time to go=2277.7s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillator; random ID2 / 10; model ID2 / 35; time to go=2302.08s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillator; random ID3 / 10; model ID2 / 35; time to go=2306.44s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillator; random ID4 / 10; model ID2 / 35; time to go=2325.67s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillator; random ID5 / 10; model ID2 / 35; time to go=2339.71s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillator; random ID6 / 10; model ID2 / 35; time to go=2353.11s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillator; random ID7 / 10; model ID2 / 35; time to go=2378.88s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillator; random ID8 / 10; model ID2 / 35; time to go=2390.79s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillator; random ID9 / 10; model ID2 / 35; time to go=2411.75s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorGravity; random ID0 / 10; model ID3 / 35; time to go=2428.55s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorGravity; random ID1 / 10; model ID3 / 35; time to go=2456.32s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorGravity; random ID2 / 10; model ID3 / 35; time to go=2479.18s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorGravity; random ID3 / 10; model ID3 / 35; time to go=2497.99s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorGravity; random ID4 / 10; model ID3 / 35; time to go=2515.16s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorGravity; random ID5 / 10; model ID3 / 35; time to go=2533.9s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorGravity; random ID6 / 10; model ID3 / 35; time to go=2552.13s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorGravity; random ID7 / 10; model ID3 / 35; time to go=2563.49s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorGravity; random ID8 / 10; model ID3 / 35; time to go=2573.95s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorGravity; random ID9 / 10; model ID3 / 35; time to go=2584.62s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankSimple; random ID0 / 10; model ID4 / 35; time to go=2593.61s

***

 - executable=True, diff=14.7889

***

Creating simulation code for sliderCrankSimple; random ID1 / 10; model ID4 / 35; time to go=2620.49s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankSimple; random ID2 / 10; model ID4 / 35; time to go=2644.63s

***

 - executable=True, diff=12.8696

***

Creating simulation code for sliderCrankSimple; random ID3 / 10; model ID4 / 35; time to go=2665.83s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankSimple; random ID4 / 10; model ID4 / 35; time to go=2686.16s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankSimple; random ID5 / 10; model ID4 / 35; time to go=2704.39s

***

 - executable=True, diff=68.0156

***

Creating simulation code for sliderCrankSimple; random ID6 / 10; model ID4 / 35; time to go=2740.78s

***

 - executable=True, diff=126.747

***

Creating simulation code for sliderCrankSimple; random ID7 / 10; model ID4 / 35; time to go=2756.24s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankSimple; random ID8 / 10; model ID4 / 35; time to go=2771.13s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankSimple; random ID9 / 10; model ID4 / 35; time to go=2783.68s

***

 - executable=True, diff=35.822

***

Creating simulation code for singlePendulumElasticSpring; random ID0 / 10; model ID5 / 35; time to go=2795.83s

***

 - executable=True, diff=32.6395

***

Creating simulation code for singlePendulumElasticSpring; random ID1 / 10; model ID5 / 35; time to go=2787.77s

***

 - executable=True, diff=88.8006

***

Creating simulation code for singlePendulumElasticSpring; random ID2 / 10; model ID5 / 35; time to go=2781.38s

***

 - executable=True, diff=105.387

***

Creating simulation code for singlePendulumElasticSpring; random ID3 / 10; model ID5 / 35; time to go=2790.75s

***

 - executable=True, diff=154.61

***

Creating simulation code for singlePendulumElasticSpring; random ID4 / 10; model ID5 / 35; time to go=2800.53s

***

 - executable=True, diff=39.2853

***

Creating simulation code for singlePendulumElasticSpring; random ID5 / 10; model ID5 / 35; time to go=2789.0s

***

 - executable=True, diff=86.0399

***

Creating simulation code for singlePendulumElasticSpring; random ID6 / 10; model ID5 / 35; time to go=2797.87s

***

 - executable=True, diff=24.2537

***

Creating simulation code for singlePendulumElasticSpring; random ID7 / 10; model ID5 / 35; time to go=2805.99s

***

 - executable=True, diff=50.7788

***

Creating simulation code for singlePendulumElasticSpring; random ID8 / 10; model ID5 / 35; time to go=2815.96s

***

 - executable=True, diff=133.171

***

Creating simulation code for singlePendulumElasticSpring; random ID9 / 10; model ID5 / 35; time to go=2805.74s

***

 - executable=True, diff=75.716

***

Creating simulation code for singleMassOscillatorUserFunction; random ID0 / 10; model ID6 / 35; time to go=2811.4s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorUserFunction; random ID1 / 10; model ID6 / 35; time to go=2815.05s

***

 - executable=True, diff=290.506

***

Creating simulation code for singleMassOscillatorUserFunction; random ID2 / 10; model ID6 / 35; time to go=2806.13s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorUserFunction; random ID3 / 10; model ID6 / 35; time to go=2801.22s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorUserFunction; random ID4 / 10; model ID6 / 35; time to go=2798.36s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorUserFunction; random ID5 / 10; model ID6 / 35; time to go=2795.93s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorUserFunction; random ID6 / 10; model ID6 / 35; time to go=2790.26s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorUserFunction; random ID7 / 10; model ID6 / 35; time to go=2785.04s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorUserFunction; random ID8 / 10; model ID6 / 35; time to go=2778.89s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorUserFunction; random ID9 / 10; model ID6 / 35; time to go=2775.07s

***

 - executable=True, diff=518.221

***

Creating simulation code for spinningDisc; random ID0 / 10; model ID7 / 35; time to go=2775.11s

***

 - executable=True, diff=0

***

Creating simulation code for spinningDisc; random ID1 / 10; model ID7 / 35; time to go=2780.45s

***

 - executable=True, diff=0

***

Creating simulation code for spinningDisc; random ID2 / 10; model ID7 / 35; time to go=2784.77s

***

 - executable=True, diff=0

***

Creating simulation code for spinningDisc; random ID3 / 10; model ID7 / 35; time to go=2788.61s

***

 - executable=True, diff=0

***

Creating simulation code for spinningDisc; random ID4 / 10; model ID7 / 35; time to go=2790.66s

***

 - executable=True, diff=0

***

Creating simulation code for spinningDisc; random ID5 / 10; model ID7 / 35; time to go=2793.69s

***

 - executable=True, diff=0

***

Creating simulation code for spinningDisc; random ID6 / 10; model ID7 / 35; time to go=2795.87s

***

 - executable=True, diff=0

***

Creating simulation code for spinningDisc; random ID7 / 10; model ID7 / 35; time to go=2797.53s

***

 - executable=True, diff=0

***

Creating simulation code for spinningDisc; random ID8 / 10; model ID7 / 35; time to go=2799.12s

***

 - executable=True, diff=0

***

Creating simulation code for spinningDisc; random ID9 / 10; model ID7 / 35; time to go=2800.22s

***

 - executable=True, diff=0

***

Creating simulation code for doubleMassOscillator; random ID0 / 10; model ID8 / 35; time to go=2801.07s

***

 - executable=True, diff=0

***

Creating simulation code for doubleMassOscillator; random ID1 / 10; model ID8 / 35; time to go=2803.81s

***

 - executable=True, diff=0

***

Creating simulation code for doubleMassOscillator; random ID2 / 10; model ID8 / 35; time to go=2804.71s

***

 - executable=True, diff=0

***

Creating simulation code for doubleMassOscillator; random ID3 / 10; model ID8 / 35; time to go=2805.17s

***

 - executable=True, diff=0

***

Creating simulation code for doubleMassOscillator; random ID4 / 10; model ID8 / 35; time to go=2804.99s

***

 - executable=True, diff=0

***

Creating simulation code for doubleMassOscillator; random ID5 / 10; model ID8 / 35; time to go=2806.21s

***

 - executable=True, diff=0

***

Creating simulation code for doubleMassOscillator; random ID6 / 10; model ID8 / 35; time to go=2807.67s

***

 - executable=True, diff=0

***

Creating simulation code for doubleMassOscillator; random ID7 / 10; model ID8 / 35; time to go=2809.5s

***

 - executable=True, diff=0

***

Creating simulation code for doubleMassOscillator; random ID8 / 10; model ID8 / 35; time to go=2809.32s

***

 - executable=True, diff=0

***

Creating simulation code for doubleMassOscillator; random ID9 / 10; model ID8 / 35; time to go=2807.13s

***

 - executable=True, diff=0

***

Creating simulation code for nMassOscillator; random ID0 / 10; model ID9 / 35; time to go=2805.08s

***

 - executable=True, diff=142.977

***

Creating simulation code for nMassOscillator; random ID1 / 10; model ID9 / 35; time to go=2802.93s

***

 - executable=True, diff=0

***

Creating simulation code for nMassOscillator; random ID2 / 10; model ID9 / 35; time to go=2799.26s

***

 - executable=True, diff=132.45

***

Creating simulation code for nMassOscillator; random ID3 / 10; model ID9 / 35; time to go=2792.31s

***

 - executable=True, diff=366.928

***

Creating simulation code for nMassOscillator; random ID4 / 10; model ID9 / 35; time to go=2784.0s

***

 - executable=True, diff=291.485

***

Creating simulation code for nMassOscillator; random ID5 / 10; model ID9 / 35; time to go=2770.96s

***

 - executable=True, diff=64.3266

***

Creating simulation code for nMassOscillator; random ID6 / 10; model ID9 / 35; time to go=2773.85s

***

 - executable=True, diff=290.082

***

Creating simulation code for nMassOscillator; random ID7 / 10; model ID9 / 35; time to go=2760.93s

***

 - executable=True, diff=212.767

***

Creating simulation code for nMassOscillator; random ID8 / 10; model ID9 / 35; time to go=2748.96s

***

 - executable=True, diff=0

***

Creating simulation code for nMassOscillator; random ID9 / 10; model ID9 / 35; time to go=2745.7s

***

 - executable=True, diff=136.442

***

Creating simulation code for singlePendulum; random ID0 / 10; model ID10 / 35; time to go=2732.72s

***

 - executable=True, diff=95.7133

***

Creating simulation code for singlePendulum; random ID1 / 10; model ID10 / 35; time to go=2724.04s

***

 - executable=True, diff=10.8161

***

Creating simulation code for singlePendulum; random ID2 / 10; model ID10 / 35; time to go=2720.74s

***

 - executable=True, diff=30.2107

***

Creating simulation code for singlePendulum; random ID3 / 10; model ID10 / 35; time to go=2711.99s

***

*****
ERROR:** 

```
Execute code error message: 'exudyn.exudynCPP.ObjectIndex' object has no attribute 'SetRotationMatrix'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 23, in <module>
AttributeError: 'exudyn.exudynCPP.ObjectIndex' object has no attribute 'SetRotationMatrix'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for singlePendulum; random ID4 / 10; model ID10 / 35; time to go=2705.38s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulum; random ID5 / 10; model ID10 / 35; time to go=2696.59s

***

 - executable=True, diff=126.761

***

Creating simulation code for singlePendulum; random ID6 / 10; model ID10 / 35; time to go=2687.4s

***

 - executable=True, diff=20.8134

***

Creating simulation code for singlePendulum; random ID7 / 10; model ID10 / 35; time to go=2676.71s

***

 - executable=True, diff=7.11612e-07

***

Creating simulation code for singlePendulum; random ID8 / 10; model ID10 / 35; time to go=2665.25s

***

 - executable=True, diff=21.2662

***

Creating simulation code for singlePendulum; random ID9 / 10; model ID10 / 35; time to go=2658.08s

***

 - executable=True, diff=150.043

***

Creating simulation code for doublePendulum; random ID0 / 10; model ID11 / 35; time to go=2648.94s

***

 - executable=True, diff=119.547

***

Creating simulation code for doublePendulum; random ID1 / 10; model ID11 / 35; time to go=2644.47s

***

 - executable=True, diff=106.743

***

Creating simulation code for doublePendulum; random ID2 / 10; model ID11 / 35; time to go=2632.71s

***

 - executable=True, diff=43.1283

***

Creating simulation code for doublePendulum; random ID3 / 10; model ID11 / 35; time to go=2620.91s

***

 - executable=True, diff=109.105

***

Creating simulation code for doublePendulum; random ID4 / 10; model ID11 / 35; time to go=2624.76s

***

 - executable=True, diff=138.249

***

Creating simulation code for doublePendulum; random ID5 / 10; model ID11 / 35; time to go=2612.53s

***

 - executable=True, diff=23.5712

***

Creating simulation code for doublePendulum; random ID6 / 10; model ID11 / 35; time to go=2607.8s

***

 - executable=True, diff=197.667

***

Creating simulation code for doublePendulum; random ID7 / 10; model ID11 / 35; time to go=2602.48s

***

 - executable=True, diff=124.854

***

Creating simulation code for doublePendulum; random ID8 / 10; model ID11 / 35; time to go=2597.82s

***

 - executable=True, diff=113.439

***

Creating simulation code for doublePendulum; random ID9 / 10; model ID11 / 35; time to go=2592.61s

***

 - executable=True, diff=221.7

***

Creating simulation code for nPendulum; random ID0 / 10; model ID12 / 35; time to go=2580.52s

***

 - executable=True, diff=2.06025e-06

***

Creating simulation code for nPendulum; random ID1 / 10; model ID12 / 35; time to go=2567.39s

***

 - executable=True, diff=0

***

Creating simulation code for nPendulum; random ID2 / 10; model ID12 / 35; time to go=2559.1s

***

 - executable=True, diff=9.18604e-07

***

Creating simulation code for nPendulum; random ID3 / 10; model ID12 / 35; time to go=2548.86s

***

 - executable=True, diff=0

***

Creating simulation code for nPendulum; random ID4 / 10; model ID12 / 35; time to go=2539.39s

***

 - executable=True, diff=0

***

Creating simulation code for nPendulum; random ID5 / 10; model ID12 / 35; time to go=2528.04s

***

 - executable=True, diff=0

***

Creating simulation code for nPendulum; random ID6 / 10; model ID12 / 35; time to go=2518.93s

***

 - executable=True, diff=0

***

Creating simulation code for nPendulum; random ID7 / 10; model ID12 / 35; time to go=2510.58s

***

 - executable=True, diff=0

***

Creating simulation code for nPendulum; random ID8 / 10; model ID12 / 35; time to go=2500.8s

***

 - executable=True, diff=0

***

Creating simulation code for nPendulum; random ID9 / 10; model ID12 / 35; time to go=2489.98s

***

 - executable=True, diff=0

***

Creating simulation code for fourBarMechanismPointMasses; random ID0 / 10; model ID13 / 35; time to go=2484.7s

***

 - executable=True, diff=0

***

Creating simulation code for fourBarMechanismPointMasses; random ID1 / 10; model ID13 / 35; time to go=2478.22s

***

 - executable=True, diff=0

***

Creating simulation code for fourBarMechanismPointMasses; random ID2 / 10; model ID13 / 35; time to go=2471.5s

***

 - executable=True, diff=0

***

Creating simulation code for fourBarMechanismPointMasses; random ID3 / 10; model ID13 / 35; time to go=2465.8s

***

 - executable=True, diff=0

***

Creating simulation code for fourBarMechanismPointMasses; random ID4 / 10; model ID13 / 35; time to go=2459.09s

***

 - executable=True, diff=0

***

Creating simulation code for fourBarMechanismPointMasses; random ID5 / 10; model ID13 / 35; time to go=2450.05s

***

 - executable=True, diff=0

***

Creating simulation code for fourBarMechanismPointMasses; random ID6 / 10; model ID13 / 35; time to go=2443.69s

***

 - executable=True, diff=0

***

Creating simulation code for fourBarMechanismPointMasses; random ID7 / 10; model ID13 / 35; time to go=2432.22s

***

 - executable=True, diff=0

***

Creating simulation code for fourBarMechanismPointMasses; random ID8 / 10; model ID13 / 35; time to go=2421.34s

***

 - executable=True, diff=0

***

Creating simulation code for fourBarMechanismPointMasses; random ID9 / 10; model ID13 / 35; time to go=2414.5s

***

 - executable=True, diff=0

***

Creating simulation code for springCoupledFlyingRigidBodies; random ID0 / 10; model ID14 / 35; time to go=2406.76s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'connectionPointList'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 24, in <module>
TypeError: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'connectionPointList'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for springCoupledFlyingRigidBodies; random ID1 / 10; model ID14 / 35; time to go=2398.72s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'body1'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 26, in <module>
TypeError: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'body1'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for springCoupledFlyingRigidBodies; random ID2 / 10; model ID14 / 35; time to go=2392.84s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'connectionPointList'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 30, in <module>
TypeError: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'connectionPointList'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for springCoupledFlyingRigidBodies; random ID3 / 10; model ID14 / 35; time to go=2385.24s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'positionList'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 24, in <module>
TypeError: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'positionList'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for springCoupledFlyingRigidBodies; random ID4 / 10; model ID14 / 35; time to go=2377.32s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'connectionPointList'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 24, in <module>
TypeError: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'connectionPointList'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for springCoupledFlyingRigidBodies; random ID5 / 10; model ID14 / 35; time to go=2369.02s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'connectionPointList'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 24, in <module>
TypeError: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'connectionPointList'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for springCoupledFlyingRigidBodies; random ID6 / 10; model ID14 / 35; time to go=2360.67s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'positionList'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 26, in <module>
TypeError: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'positionList'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for springCoupledFlyingRigidBodies; random ID7 / 10; model ID14 / 35; time to go=2352.37s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'connectionPointList'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 33, in <module>
TypeError: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'connectionPointList'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for springCoupledFlyingRigidBodies; random ID8 / 10; model ID14 / 35; time to go=2345.93s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'connectionPointList'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 30, in <module>
TypeError: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'connectionPointList'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for springCoupledFlyingRigidBodies; random ID9 / 10; model ID14 / 35; time to go=2337.78s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'connectionPointList'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 30, in <module>
TypeError: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'connectionPointList'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for torsionalOscillator; random ID0 / 10; model ID15 / 35; time to go=2329.95s

***

 - executable=True, diff=0

***

Creating simulation code for torsionalOscillator; random ID1 / 10; model ID15 / 35; time to go=2320.82s

***

 - executable=True, diff=0

***

Creating simulation code for torsionalOscillator; random ID2 / 10; model ID15 / 35; time to go=2311.78s

***

 - executable=True, diff=0

***

Creating simulation code for torsionalOscillator; random ID3 / 10; model ID15 / 35; time to go=2303.89s

***

 - executable=True, diff=0

***

Creating simulation code for torsionalOscillator; random ID4 / 10; model ID15 / 35; time to go=2296.07s

***

 - executable=True, diff=0

***

Creating simulation code for torsionalOscillator; random ID5 / 10; model ID15 / 35; time to go=2286.76s

***

 - executable=True, diff=0

***

Creating simulation code for torsionalOscillator; random ID6 / 10; model ID15 / 35; time to go=2277.38s

***

 - executable=True, diff=0

***

Creating simulation code for torsionalOscillator; random ID7 / 10; model ID15 / 35; time to go=2267.9s

***

 - executable=True, diff=0

***

Creating simulation code for torsionalOscillator; random ID8 / 10; model ID15 / 35; time to go=2258.31s

***

 - executable=True, diff=0

***

Creating simulation code for torsionalOscillator; random ID9 / 10; model ID15 / 35; time to go=2248.7s

***

 - executable=True, diff=0

***

Creating simulation code for invertedSinglePendulum; random ID0 / 10; model ID16 / 35; time to go=2239.17s

***

 - executable=True, diff=22.5738

***

Creating simulation code for invertedSinglePendulum; random ID1 / 10; model ID16 / 35; time to go=2229.56s

***

 - executable=True, diff=7.52427e-08

***

Creating simulation code for invertedSinglePendulum; random ID2 / 10; model ID16 / 35; time to go=2219.72s

***

 - executable=True, diff=2.78161e-07

***

Creating simulation code for invertedSinglePendulum; random ID3 / 10; model ID16 / 35; time to go=2209.93s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateSphericalJoint() got an unexpected keyword argument 'localPosition0'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 22, in <module>
TypeError: MainSystemCreateSphericalJoint() got an unexpected keyword argument 'localPosition0'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for invertedSinglePendulum; random ID4 / 10; model ID16 / 35; time to go=2201.05s

***

 - executable=True, diff=3.59659e-07

***

Creating simulation code for invertedSinglePendulum; random ID5 / 10; model ID16 / 35; time to go=2191.2s

***

 - executable=True, diff=0

***

Creating simulation code for invertedSinglePendulum; random ID6 / 10; model ID16 / 35; time to go=2182.48s

***

 - executable=True, diff=2.48495e-07

***

Creating simulation code for invertedSinglePendulum; random ID7 / 10; model ID16 / 35; time to go=2177.38s

***

 - executable=True, diff=2.8761e-07

***

Creating simulation code for invertedSinglePendulum; random ID8 / 10; model ID16 / 35; time to go=2167.46s

***

 - executable=True, diff=2.87625e-07

***

Creating simulation code for invertedSinglePendulum; random ID9 / 10; model ID16 / 35; time to go=2161.25s

***

 - executable=True, diff=2.91003e-07

***

Creating simulation code for discRollingOnGround; random ID0 / 10; model ID17 / 35; time to go=2155.76s

***

 - executable=True, diff=5.37629e-07

***

Creating simulation code for discRollingOnGround; random ID1 / 10; model ID17 / 35; time to go=2145.52s

***

 - executable=True, diff=3.11763e-06

***

Creating simulation code for discRollingOnGround; random ID2 / 10; model ID17 / 35; time to go=2135.56s

***

 - executable=True, diff=9.46564e-07

***

Creating simulation code for discRollingOnGround; random ID3 / 10; model ID17 / 35; time to go=2125.67s

***

 - executable=True, diff=1.90836e-07

***

Creating simulation code for discRollingOnGround; random ID4 / 10; model ID17 / 35; time to go=2115.5s

***

 - executable=True, diff=1.72286e-07

***

Creating simulation code for discRollingOnGround; random ID5 / 10; model ID17 / 35; time to go=2105.4s

***

*****
ERROR:** 

```
Execute code error message: SolveDynamic terminated
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 49, in <module>
  File "C:\Users\c8501009\Anaconda\envs\venvP311gpt4all\Lib\site-packages\exudyn\solver.py", line 267, in SolveDynamic
    raise ValueError("SolveDynamic terminated")
ValueError: SolveDynamic terminated

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: dynamicSolver not successful!
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for discRollingOnGround; random ID6 / 10; model ID17 / 35; time to go=2095.1s

***

 - executable=True, diff=3.40935e-07

***

Creating simulation code for discRollingOnGround; random ID7 / 10; model ID17 / 35; time to go=2085.12s

***

 - executable=True, diff=1.57299e-05

***

Creating simulation code for discRollingOnGround; random ID8 / 10; model ID17 / 35; time to go=2074.41s

***

 - executable=True, diff=1.00103e-06

***

Creating simulation code for discRollingOnGround; random ID9 / 10; model ID17 / 35; time to go=2063.07s

***

 - executable=True, diff=1.98244e-07

***

Creating simulation code for doublePendulumElasticSpring; random ID0 / 10; model ID18 / 35; time to go=2052.96s

***

 - executable=True, diff=32.6011

***

Creating simulation code for doublePendulumElasticSpring; random ID1 / 10; model ID18 / 35; time to go=2041.8s

***

 - executable=True, diff=404.091

***

Creating simulation code for doublePendulumElasticSpring; random ID2 / 10; model ID18 / 35; time to go=2030.25s

***

 - executable=True, diff=53.5928

***

Creating simulation code for doublePendulumElasticSpring; random ID3 / 10; model ID18 / 35; time to go=2017.64s

***

 - executable=True, diff=8.00417

***

Creating simulation code for doublePendulumElasticSpring; random ID4 / 10; model ID18 / 35; time to go=2003.84s

***

 - executable=True, diff=4035.93

***

Creating simulation code for doublePendulumElasticSpring; random ID5 / 10; model ID18 / 35; time to go=1989.04s

***

 - executable=True, diff=61.85

***

Creating simulation code for doublePendulumElasticSpring; random ID6 / 10; model ID18 / 35; time to go=1977.52s

***

 - executable=True, diff=387.15

***

Creating simulation code for doublePendulumElasticSpring; random ID7 / 10; model ID18 / 35; time to go=1964.65s

***

 - executable=True, diff=90.0605

***

Creating simulation code for doublePendulumElasticSpring; random ID8 / 10; model ID18 / 35; time to go=1953.22s

***

 - executable=True, diff=18.6618

***

Creating simulation code for doublePendulumElasticSpring; random ID9 / 10; model ID18 / 35; time to go=1942.05s

***

 - executable=True, diff=663.207

***

Creating simulation code for nPendulumElasticSpring; random ID0 / 10; model ID19 / 35; time to go=1929.11s

***

 - executable=True, diff=0

***

Creating simulation code for nPendulumElasticSpring; random ID1 / 10; model ID19 / 35; time to go=1921.88s

***

 - executable=True, diff=0

***

Creating simulation code for nPendulumElasticSpring; random ID2 / 10; model ID19 / 35; time to go=1911.57s

***

 - executable=True, diff=25.4211

***

Creating simulation code for nPendulumElasticSpring; random ID3 / 10; model ID19 / 35; time to go=1901.96s

***

 - executable=True, diff=0

***

Creating simulation code for nPendulumElasticSpring; random ID4 / 10; model ID19 / 35; time to go=1892.29s

***

 - executable=True, diff=10.777

***

Creating simulation code for nPendulumElasticSpring; random ID5 / 10; model ID19 / 35; time to go=1882.62s

***

 - executable=True, diff=67.6746

***

Creating simulation code for nPendulumElasticSpring; random ID6 / 10; model ID19 / 35; time to go=1872.16s

***

 - executable=True, diff=0

***

Creating simulation code for nPendulumElasticSpring; random ID7 / 10; model ID19 / 35; time to go=1861.99s

***

 - executable=True, diff=0

***

Creating simulation code for nPendulumElasticSpring; random ID8 / 10; model ID19 / 35; time to go=1848.77s

***

 - executable=True, diff=45.4749

***

Creating simulation code for nPendulumElasticSpring; random ID9 / 10; model ID19 / 35; time to go=1838.26s

***

 - executable=True, diff=60.8734

***

Creating simulation code for elasticChain; random ID0 / 10; model ID20 / 35; time to go=1826.39s

***

 - executable=True, diff=0

***

Creating simulation code for elasticChain; random ID1 / 10; model ID20 / 35; time to go=1815.13s

***

 - executable=True, diff=0

***

Creating simulation code for elasticChain; random ID2 / 10; model ID20 / 35; time to go=1802.19s

***

 - executable=True, diff=0

***

Creating simulation code for elasticChain; random ID3 / 10; model ID20 / 35; time to go=1788.83s

***

 - executable=True, diff=0

***

Creating simulation code for elasticChain; random ID4 / 10; model ID20 / 35; time to go=1778.45s

***

 - executable=True, diff=0

***

Creating simulation code for elasticChain; random ID5 / 10; model ID20 / 35; time to go=1765.51s

***

 - executable=True, diff=0

***

Creating simulation code for elasticChain; random ID6 / 10; model ID20 / 35; time to go=1754.57s

***

 - executable=True, diff=0

***

Creating simulation code for elasticChain; random ID7 / 10; model ID20 / 35; time to go=1743.19s

***

 - executable=True, diff=0

***

Creating simulation code for elasticChain; random ID8 / 10; model ID20 / 35; time to go=1732.63s

***

 - executable=True, diff=0

***

Creating simulation code for elasticChain; random ID9 / 10; model ID20 / 35; time to go=1720.74s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumRigidBody; random ID0 / 10; model ID21 / 35; time to go=1710.64s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumRigidBody; random ID1 / 10; model ID21 / 35; time to go=1697.51s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumRigidBody; random ID2 / 10; model ID21 / 35; time to go=1683.61s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumRigidBody; random ID3 / 10; model ID21 / 35; time to go=1669.8s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumRigidBody; random ID4 / 10; model ID21 / 35; time to go=1656.11s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumRigidBody; random ID5 / 10; model ID21 / 35; time to go=1642.31s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumRigidBody; random ID6 / 10; model ID21 / 35; time to go=1628.66s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumRigidBody; random ID7 / 10; model ID21 / 35; time to go=1614.97s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumRigidBody; random ID8 / 10; model ID21 / 35; time to go=1601.36s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumRigidBody; random ID9 / 10; model ID21 / 35; time to go=1588.58s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringRigid; random ID0 / 10; model ID22 / 35; time to go=1575.01s

***

 - executable=True, diff=391.518

***

Creating simulation code for massPointOnStringRigid; random ID1 / 10; model ID22 / 35; time to go=1560.78s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringRigid; random ID2 / 10; model ID22 / 35; time to go=1546.6s

***

 - executable=True, diff=343.215

***

Creating simulation code for massPointOnStringRigid; random ID3 / 10; model ID22 / 35; time to go=1532.99s

***

 - executable=True, diff=253.729

***

Creating simulation code for massPointOnStringRigid; random ID4 / 10; model ID22 / 35; time to go=1519.3s

***

 - executable=True, diff=296.864

***

Creating simulation code for massPointOnStringRigid; random ID5 / 10; model ID22 / 35; time to go=1505.67s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringRigid; random ID6 / 10; model ID22 / 35; time to go=1491.42s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringRigid; random ID7 / 10; model ID22 / 35; time to go=1478.09s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringRigid; random ID8 / 10; model ID22 / 35; time to go=1464.25s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringRigid; random ID9 / 10; model ID22 / 35; time to go=1450.09s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringElastic; random ID0 / 10; model ID23 / 35; time to go=1436.68s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringElastic; random ID1 / 10; model ID23 / 35; time to go=1422.9s

***

 - executable=True, diff=235.872

***

Creating simulation code for massPointOnStringElastic; random ID2 / 10; model ID23 / 35; time to go=1409.11s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringElastic; random ID3 / 10; model ID23 / 35; time to go=1395.35s

***

 - executable=True, diff=231.583

***

Creating simulation code for massPointOnStringElastic; random ID4 / 10; model ID23 / 35; time to go=1381.72s

***

 - executable=True, diff=262.196

***

Creating simulation code for massPointOnStringElastic; random ID5 / 10; model ID23 / 35; time to go=1368.06s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringElastic; random ID6 / 10; model ID23 / 35; time to go=1354.48s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringElastic; random ID7 / 10; model ID23 / 35; time to go=1340.99s

***

 - executable=True, diff=330.76

***

Creating simulation code for massPointOnStringElastic; random ID8 / 10; model ID23 / 35; time to go=1327.47s

***

 - executable=True, diff=351.808

***

Creating simulation code for massPointOnStringElastic; random ID9 / 10; model ID23 / 35; time to go=1314.46s

***

 - executable=True, diff=200.716

***

Creating simulation code for linkOnTwoPrismaticJoints; random ID0 / 10; model ID24 / 35; time to go=1301.02s

***

 - executable=True, diff=23.2142

***

Creating simulation code for linkOnTwoPrismaticJoints; random ID1 / 10; model ID24 / 35; time to go=1291.47s

***

 - executable=True, diff=0

***

Creating simulation code for linkOnTwoPrismaticJoints; random ID2 / 10; model ID24 / 35; time to go=1280.75s

***

 - executable=True, diff=0

***

Creating simulation code for linkOnTwoPrismaticJoints; random ID3 / 10; model ID24 / 35; time to go=1269.91s

***

 - executable=True, diff=0

***

Creating simulation code for linkOnTwoPrismaticJoints; random ID4 / 10; model ID24 / 35; time to go=1259.04s

***

 - executable=True, diff=0

***

Creating simulation code for linkOnTwoPrismaticJoints; random ID5 / 10; model ID24 / 35; time to go=1248.42s

***

 - executable=True, diff=0

***

Creating simulation code for linkOnTwoPrismaticJoints; random ID6 / 10; model ID24 / 35; time to go=1237.38s

***

 - executable=True, diff=0

***

Creating simulation code for linkOnTwoPrismaticJoints; random ID7 / 10; model ID24 / 35; time to go=1226.45s

***

 - executable=True, diff=0

***

Creating simulation code for linkOnTwoPrismaticJoints; random ID8 / 10; model ID24 / 35; time to go=1215.51s

***

 - executable=True, diff=0

***

Creating simulation code for linkOnTwoPrismaticJoints; random ID9 / 10; model ID24 / 35; time to go=1204.65s

***

 - executable=True, diff=0

***

Creating simulation code for flyingRigidBody; random ID0 / 10; model ID25 / 35; time to go=1193.72s

***

 - executable=True, diff=0

***

Creating simulation code for flyingRigidBody; random ID1 / 10; model ID25 / 35; time to go=1180.35s

***

 - executable=True, diff=158.415

***

Creating simulation code for flyingRigidBody; random ID2 / 10; model ID25 / 35; time to go=1167.03s

***

 - executable=True, diff=0

***

Creating simulation code for flyingRigidBody; random ID3 / 10; model ID25 / 35; time to go=1153.8s

***

 - executable=True, diff=158.415

***

Creating simulation code for flyingRigidBody; random ID4 / 10; model ID25 / 35; time to go=1140.57s

***

 - executable=True, diff=0

***

Creating simulation code for flyingRigidBody; random ID5 / 10; model ID25 / 35; time to go=1127.42s

***

 - executable=True, diff=0

***

Creating simulation code for flyingRigidBody; random ID6 / 10; model ID25 / 35; time to go=1114.39s

***

 - executable=True, diff=0

***

Creating simulation code for flyingRigidBody; random ID7 / 10; model ID25 / 35; time to go=1101.32s

***

 - executable=True, diff=0

***

Creating simulation code for flyingRigidBody; random ID8 / 10; model ID25 / 35; time to go=1088.31s

***

 - executable=True, diff=60.2331

***

Creating simulation code for flyingRigidBody; random ID9 / 10; model ID25 / 35; time to go=1075.31s

***

 - executable=True, diff=158.415

***

Creating simulation code for suspendedRigidBody; random ID0 / 10; model ID26 / 35; time to go=1062.66s

***

 - executable=True, diff=0

***

Creating simulation code for suspendedRigidBody; random ID1 / 10; model ID26 / 35; time to go=1053.29s

***

 - executable=True, diff=0

***

Creating simulation code for suspendedRigidBody; random ID2 / 10; model ID26 / 35; time to go=1042.18s

***

 - executable=True, diff=0

***

Creating simulation code for suspendedRigidBody; random ID3 / 10; model ID26 / 35; time to go=1032.7s

***

 - executable=True, diff=0

***

Creating simulation code for suspendedRigidBody; random ID4 / 10; model ID26 / 35; time to go=1023.09s

***

 - executable=True, diff=0

***

Creating simulation code for suspendedRigidBody; random ID5 / 10; model ID26 / 35; time to go=1012.63s

***

 - executable=True, diff=0

***

Creating simulation code for suspendedRigidBody; random ID6 / 10; model ID26 / 35; time to go=1001.68s

***

 - executable=True, diff=0

***

Creating simulation code for suspendedRigidBody; random ID7 / 10; model ID26 / 35; time to go=990.78s

***

 - executable=True, diff=0

***

Creating simulation code for suspendedRigidBody; random ID8 / 10; model ID26 / 35; time to go=979.73s

***

 - executable=True, diff=0

***

Creating simulation code for suspendedRigidBody; random ID9 / 10; model ID26 / 35; time to go=969.89s

***

 - executable=True, diff=0

***

Creating simulation code for gyroscopeOnSphericalJoint; random ID0 / 10; model ID27 / 35; time to go=958.82s

***

 - executable=True, diff=0

***

Creating simulation code for gyroscopeOnSphericalJoint; random ID1 / 10; model ID27 / 35; time to go=946.67s

***

 - executable=True, diff=0

***

Creating simulation code for gyroscopeOnSphericalJoint; random ID2 / 10; model ID27 / 35; time to go=934.52s

***

 - executable=True, diff=0

***

Creating simulation code for gyroscopeOnSphericalJoint; random ID3 / 10; model ID27 / 35; time to go=922.74s

***

 - executable=True, diff=0

***

Creating simulation code for gyroscopeOnSphericalJoint; random ID4 / 10; model ID27 / 35; time to go=910.59s

***

 - executable=True, diff=0

***

Creating simulation code for gyroscopeOnSphericalJoint; random ID5 / 10; model ID27 / 35; time to go=898.8s

***

 - executable=True, diff=0

***

Creating simulation code for gyroscopeOnSphericalJoint; random ID6 / 10; model ID27 / 35; time to go=886.65s

***

 - executable=True, diff=0

***

Creating simulation code for gyroscopeOnSphericalJoint; random ID7 / 10; model ID27 / 35; time to go=874.48s

***

 - executable=True, diff=0

***

Creating simulation code for gyroscopeOnSphericalJoint; random ID8 / 10; model ID27 / 35; time to go=862.35s

***

 - executable=True, diff=0

***

Creating simulation code for gyroscopeOnSphericalJoint; random ID9 / 10; model ID27 / 35; time to go=850.22s

***

 - executable=True, diff=0

***

Creating simulation code for prismaticJointSystem; random ID0 / 10; model ID28 / 35; time to go=838.43s

***

 - executable=True, diff=0

***

Creating simulation code for prismaticJointSystem; random ID1 / 10; model ID28 / 35; time to go=825.83s

***

 - executable=True, diff=0

***

Creating simulation code for prismaticJointSystem; random ID2 / 10; model ID28 / 35; time to go=813.26s

***

 - executable=True, diff=0

***

Creating simulation code for prismaticJointSystem; random ID3 / 10; model ID28 / 35; time to go=800.72s

***

 - executable=True, diff=0

***

Creating simulation code for prismaticJointSystem; random ID4 / 10; model ID28 / 35; time to go=788.34s

***

 - executable=True, diff=0

***

Creating simulation code for prismaticJointSystem; random ID5 / 10; model ID28 / 35; time to go=775.85s

***

 - executable=True, diff=0

***

Creating simulation code for prismaticJointSystem; random ID6 / 10; model ID28 / 35; time to go=763.37s

***

 - executable=True, diff=0

***

Creating simulation code for prismaticJointSystem; random ID7 / 10; model ID28 / 35; time to go=750.92s

***

 - executable=True, diff=0

***

Creating simulation code for prismaticJointSystem; random ID8 / 10; model ID28 / 35; time to go=738.61s

***

 - executable=True, diff=0

***

Creating simulation code for prismaticJointSystem; random ID9 / 10; model ID28 / 35; time to go=726.18s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithSprings; random ID0 / 10; model ID29 / 35; time to go=714.02s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithSprings; random ID1 / 10; model ID29 / 35; time to go=702.0s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithSprings; random ID2 / 10; model ID29 / 35; time to go=690.21s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithSprings; random ID3 / 10; model ID29 / 35; time to go=678.31s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithSprings; random ID4 / 10; model ID29 / 35; time to go=666.36s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithSprings; random ID5 / 10; model ID29 / 35; time to go=654.28s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithSprings; random ID6 / 10; model ID29 / 35; time to go=642.44s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithSprings; random ID7 / 10; model ID29 / 35; time to go=630.63s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithSprings; random ID8 / 10; model ID29 / 35; time to go=618.73s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithSprings; random ID9 / 10; model ID29 / 35; time to go=606.78s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithDistances; random ID0 / 10; model ID30 / 35; time to go=594.98s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithDistances; random ID1 / 10; model ID30 / 35; time to go=582.83s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithDistances; random ID2 / 10; model ID30 / 35; time to go=570.69s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithDistances; random ID3 / 10; model ID30 / 35; time to go=558.29s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithDistances; random ID4 / 10; model ID30 / 35; time to go=546.17s

***

 - executable=True, diff=5.55095

***

Creating simulation code for twoMassPointsWithDistances; random ID5 / 10; model ID30 / 35; time to go=534.07s

***

 - executable=True, diff=7.72104

***

Creating simulation code for twoMassPointsWithDistances; random ID6 / 10; model ID30 / 35; time to go=521.98s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithDistances; random ID7 / 10; model ID30 / 35; time to go=509.73s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithDistances; random ID8 / 10; model ID30 / 35; time to go=497.77s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithDistances; random ID9 / 10; model ID30 / 35; time to go=485.68s

***

 - executable=True, diff=0

***

Creating simulation code for rigidRotorSimplySupported; random ID0 / 10; model ID31 / 35; time to go=473.63s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'bodyOrGroundNodeID'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 27, in <module>
TypeError: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'bodyOrGroundNodeID'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for rigidRotorSimplySupported; random ID1 / 10; model ID31 / 35; time to go=462.24s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'bodyOrGroundNodeID'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 28, in <module>
TypeError: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'bodyOrGroundNodeID'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for rigidRotorSimplySupported; random ID2 / 10; model ID31 / 35; time to go=450.74s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'bodyOrGroundNodeID'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 29, in <module>
TypeError: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'bodyOrGroundNodeID'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for rigidRotorSimplySupported; random ID3 / 10; model ID31 / 35; time to go=439.28s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'springForce'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 26, in <module>
TypeError: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'springForce'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for rigidRotorSimplySupported; random ID4 / 10; model ID31 / 35; time to go=427.68s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'position'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 28, in <module>
TypeError: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'position'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for rigidRotorSimplySupported; random ID5 / 10; model ID31 / 35; time to go=416.03s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'connectionPointList'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 29, in <module>
TypeError: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'connectionPointList'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for rigidRotorSimplySupported; random ID6 / 10; model ID31 / 35; time to go=404.42s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'bodyOrGroundNodeID'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 29, in <module>
TypeError: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'bodyOrGroundNodeID'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for rigidRotorSimplySupported; random ID7 / 10; model ID31 / 35; time to go=392.89s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'bodyOrGroundNodeID'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 29, in <module>
TypeError: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'bodyOrGroundNodeID'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for rigidRotorSimplySupported; random ID8 / 10; model ID31 / 35; time to go=381.34s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'bodyOrGroundNodeID'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 28, in <module>
TypeError: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'bodyOrGroundNodeID'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for rigidRotorSimplySupported; random ID9 / 10; model ID31 / 35; time to go=369.7s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'bodyOrGroundNodeID'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 29, in <module>
TypeError: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'bodyOrGroundNodeID'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for rigidRotorUnbalanced; random ID0 / 10; model ID32 / 35; time to go=358.12s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateSpringDamper() got an unexpected keyword argument 'bodyNumber1'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 26, in <module>
TypeError: MainSystemCreateSpringDamper() got an unexpected keyword argument 'bodyNumber1'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for rigidRotorUnbalanced; random ID1 / 10; model ID32 / 35; time to go=346.8s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'bodyNumber'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 30, in <module>
TypeError: MainSystemCreateCartesianSpringDamper() got an unexpected keyword argument 'bodyNumber'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for rigidRotorUnbalanced; random ID2 / 10; model ID32 / 35; time to go=335.31s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateSpringDamper() got an unexpected keyword argument 'point1'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 30, in <module>
TypeError: MainSystemCreateSpringDamper() got an unexpected keyword argument 'point1'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for rigidRotorUnbalanced; random ID3 / 10; model ID32 / 35; time to go=323.87s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateSpringDamper() got an unexpected keyword argument 'bodyNumber'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 28, in <module>
TypeError: MainSystemCreateSpringDamper() got an unexpected keyword argument 'bodyNumber'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for rigidRotorUnbalanced; random ID4 / 10; model ID32 / 35; time to go=312.38s

***

 - executable=True, diff=8373.38

***

Creating simulation code for rigidRotorUnbalanced; random ID5 / 10; model ID32 / 35; time to go=300.51s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateSpringDamper() got an unexpected keyword argument 'bodyNumber'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 28, in <module>
TypeError: MainSystemCreateSpringDamper() got an unexpected keyword argument 'bodyNumber'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for rigidRotorUnbalanced; random ID6 / 10; model ID32 / 35; time to go=289.01s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateSpringDamper() got an unexpected keyword argument 'bodyNumber1'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 30, in <module>
TypeError: MainSystemCreateSpringDamper() got an unexpected keyword argument 'bodyNumber1'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for rigidRotorUnbalanced; random ID7 / 10; model ID32 / 35; time to go=277.47s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateSpringDamper() got an unexpected keyword argument 'bodyNumber'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 28, in <module>
TypeError: MainSystemCreateSpringDamper() got an unexpected keyword argument 'bodyNumber'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for rigidRotorUnbalanced; random ID8 / 10; model ID32 / 35; time to go=265.91s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateSpringDamper() got an unexpected keyword argument 'bodyNumber'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 26, in <module>
TypeError: MainSystemCreateSpringDamper() got an unexpected keyword argument 'bodyNumber'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for rigidRotorUnbalanced; random ID9 / 10; model ID32 / 35; time to go=254.21s

***

*****
ERROR:** 

```
Execute code error message: MainSystemCreateSpringDamper() got an unexpected keyword argument 'bodyNumber'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 28, in <module>
TypeError: MainSystemCreateSpringDamper() got an unexpected keyword argument 'bodyNumber'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for doublePendulumRigidBodies; random ID0 / 10; model ID33 / 35; time to go=242.43s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumRigidBodies; random ID1 / 10; model ID33 / 35; time to go=230.37s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumRigidBodies; random ID2 / 10; model ID33 / 35; time to go=218.47s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumRigidBodies; random ID3 / 10; model ID33 / 35; time to go=206.41s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumRigidBodies; random ID4 / 10; model ID33 / 35; time to go=194.47s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumRigidBodies; random ID5 / 10; model ID33 / 35; time to go=182.38s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumRigidBodies; random ID6 / 10; model ID33 / 35; time to go=170.28s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumRigidBodies; random ID7 / 10; model ID33 / 35; time to go=158.15s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumRigidBodies; random ID8 / 10; model ID33 / 35; time to go=146.04s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumRigidBodies; random ID9 / 10; model ID33 / 35; time to go=133.9s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankRigidBodies; random ID0 / 10; model ID34 / 35; time to go=121.76s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankRigidBodies; random ID1 / 10; model ID34 / 35; time to go=109.87s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankRigidBodies; random ID2 / 10; model ID34 / 35; time to go=97.89s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankRigidBodies; random ID3 / 10; model ID34 / 35; time to go=85.87s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankRigidBodies; random ID4 / 10; model ID34 / 35; time to go=73.79s

***

 - executable=True, diff=15.0311

***

Creating simulation code for sliderCrankRigidBodies; random ID5 / 10; model ID34 / 35; time to go=61.65s

***

 - executable=True, diff=31.6754

***

Creating simulation code for sliderCrankRigidBodies; random ID6 / 10; model ID34 / 35; time to go=49.43s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankRigidBodies; random ID7 / 10; model ID34 / 35; time to go=37.17s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankRigidBodies; random ID8 / 10; model ID34 / 35; time to go=24.84s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankRigidBodies; random ID9 / 10; model ID34 / 35; time to go=12.45s

***

 - executable=True, diff=18.7287
**FINAL TEST RESULTS** 
 - flyingMassPoint0: 

   + executable: True

   + diff: 0.0

 - flyingMassPoint1: 

   + executable: True

   + diff: 0.0

 - flyingMassPoint2: 

   + executable: True

   + diff: 0.0

 - flyingMassPoint3: 

   + executable: True

   + diff: 0.0

 - flyingMassPoint4: 

   + executable: True

   + diff: 0.0

 - flyingMassPoint5: 

   + executable: True

   + diff: 0.0

 - flyingMassPoint6: 

   + executable: True

   + diff: 0.0

 - flyingMassPoint7: 

   + executable: True

   + diff: 0.0

 - flyingMassPoint8: 

   + executable: True

   + diff: 0.0

 - flyingMassPoint9: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint0: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint1: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint2: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint3: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint4: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint5: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint6: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint7: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint8: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint9: 

   + executable: True

   + diff: 0.0

 - singleMassOscillator0: 

   + executable: True

   + diff: 0.0

 - singleMassOscillator1: 

   + executable: True

   + diff: 0.0

 - singleMassOscillator2: 

   + executable: True

   + diff: 0.0

 - singleMassOscillator3: 

   + executable: True

   + diff: 0.0

 - singleMassOscillator4: 

   + executable: True

   + diff: 0.0

 - singleMassOscillator5: 

   + executable: True

   + diff: 0.0

 - singleMassOscillator6: 

   + executable: True

   + diff: 0.0

 - singleMassOscillator7: 

   + executable: True

   + diff: 0.0

 - singleMassOscillator8: 

   + executable: True

   + diff: 0.0

 - singleMassOscillator9: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorGravity0: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorGravity1: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorGravity2: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorGravity3: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorGravity4: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorGravity5: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorGravity6: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorGravity7: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorGravity8: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorGravity9: 

   + executable: True

   + diff: 0.0

 - sliderCrankSimple0: 

   + executable: True

   + diff: 14.788858650233443

 - sliderCrankSimple1: 

   + executable: True

   + diff: 0.0

 - sliderCrankSimple2: 

   + executable: True

   + diff: 12.869623568173907

 - sliderCrankSimple3: 

   + executable: True

   + diff: 0.0

 - sliderCrankSimple4: 

   + executable: True

   + diff: 0.0

 - sliderCrankSimple5: 

   + executable: True

   + diff: 68.01555558810385

 - sliderCrankSimple6: 

   + executable: True

   + diff: 126.74695432473429

 - sliderCrankSimple7: 

   + executable: True

   + diff: 0.0

 - sliderCrankSimple8: 

   + executable: True

   + diff: 0.0

 - sliderCrankSimple9: 

   + executable: True

   + diff: 35.82203767430225

 - singlePendulumElasticSpring0: 

   + executable: True

   + diff: 32.63953233514209

 - singlePendulumElasticSpring1: 

   + executable: True

   + diff: 88.80060662813582

 - singlePendulumElasticSpring2: 

   + executable: True

   + diff: 105.38660652064607

 - singlePendulumElasticSpring3: 

   + executable: True

   + diff: 154.60958696337852

 - singlePendulumElasticSpring4: 

   + executable: True

   + diff: 39.28527807239193

 - singlePendulumElasticSpring5: 

   + executable: True

   + diff: 86.03987102822174

 - singlePendulumElasticSpring6: 

   + executable: True

   + diff: 24.25374604602082

 - singlePendulumElasticSpring7: 

   + executable: True

   + diff: 50.778816863175386

 - singlePendulumElasticSpring8: 

   + executable: True

   + diff: 133.17099461777116

 - singlePendulumElasticSpring9: 

   + executable: True

   + diff: 75.716000304447

 - singleMassOscillatorUserFunction0: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorUserFunction1: 

   + executable: True

   + diff: 290.5057839510877

 - singleMassOscillatorUserFunction2: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorUserFunction3: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorUserFunction4: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorUserFunction5: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorUserFunction6: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorUserFunction7: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorUserFunction8: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorUserFunction9: 

   + executable: True

   + diff: 518.2214531729139

 - spinningDisc0: 

   + executable: True

   + diff: 0.0

 - spinningDisc1: 

   + executable: True

   + diff: 0.0

 - spinningDisc2: 

   + executable: True

   + diff: 0.0

 - spinningDisc3: 

   + executable: True

   + diff: 0.0

 - spinningDisc4: 

   + executable: True

   + diff: 0.0

 - spinningDisc5: 

   + executable: True

   + diff: 0.0

 - spinningDisc6: 

   + executable: True

   + diff: 0.0

 - spinningDisc7: 

   + executable: True

   + diff: 0.0

 - spinningDisc8: 

   + executable: True

   + diff: 0.0

 - spinningDisc9: 

   + executable: True

   + diff: 0.0

 - doubleMassOscillator0: 

   + executable: True

   + diff: 0.0

 - doubleMassOscillator1: 

   + executable: True

   + diff: 0.0

 - doubleMassOscillator2: 

   + executable: True

   + diff: 0.0

 - doubleMassOscillator3: 

   + executable: True

   + diff: 0.0

 - doubleMassOscillator4: 

   + executable: True

   + diff: 0.0

 - doubleMassOscillator5: 

   + executable: True

   + diff: 0.0

 - doubleMassOscillator6: 

   + executable: True

   + diff: 0.0

 - doubleMassOscillator7: 

   + executable: True

   + diff: 0.0

 - doubleMassOscillator8: 

   + executable: True

   + diff: 0.0

 - doubleMassOscillator9: 

   + executable: True

   + diff: 0.0

 - nMassOscillator0: 

   + executable: True

   + diff: 142.97720796334195

 - nMassOscillator1: 

   + executable: True

   + diff: 0.0

 - nMassOscillator2: 

   + executable: True

   + diff: 132.4499876356956

 - nMassOscillator3: 

   + executable: True

   + diff: 366.92784521569126

 - nMassOscillator4: 

   + executable: True

   + diff: 291.48541203432103

 - nMassOscillator5: 

   + executable: True

   + diff: 64.32655755196721

 - nMassOscillator6: 

   + executable: True

   + diff: 290.0817766036384

 - nMassOscillator7: 

   + executable: True

   + diff: 212.76694423466915

 - nMassOscillator8: 

   + executable: True

   + diff: 0.0

 - nMassOscillator9: 

   + executable: True

   + diff: 136.44169668928805

 - singlePendulum0: 

   + executable: True

   + diff: 95.71325068525573

 - singlePendulum1: 

   + executable: True

   + diff: 10.816091502362879

 - singlePendulum2: 

   + executable: True

   + diff: 30.210672669964115

 - singlePendulum3: 

   + executable: False

   + diff: -3

 - singlePendulum4: 

   + executable: True

   + diff: 0.0

 - singlePendulum5: 

   + executable: True

   + diff: 126.76076393992284

 - singlePendulum6: 

   + executable: True

   + diff: 20.81336327753352

 - singlePendulum7: 

   + executable: True

   + diff: 7.11612056227014e-07

 - singlePendulum8: 

   + executable: True

   + diff: 21.266170318037588

 - singlePendulum9: 

   + executable: True

   + diff: 150.04312526751193

 - doublePendulum0: 

   + executable: True

   + diff: 119.54717037559952

 - doublePendulum1: 

   + executable: True

   + diff: 106.74304856181516

 - doublePendulum2: 

   + executable: True

   + diff: 43.128295817700575

 - doublePendulum3: 

   + executable: True

   + diff: 109.10532805655421

 - doublePendulum4: 

   + executable: True

   + diff: 138.24901450132006

 - doublePendulum5: 

   + executable: True

   + diff: 23.571220244154897

 - doublePendulum6: 

   + executable: True

   + diff: 197.66723451332953

 - doublePendulum7: 

   + executable: True

   + diff: 124.85428301450828

 - doublePendulum8: 

   + executable: True

   + diff: 113.43860132720032

 - doublePendulum9: 

   + executable: True

   + diff: 221.70040920767073

 - nPendulum0: 

   + executable: True

   + diff: 2.060247721054697e-06

 - nPendulum1: 

   + executable: True

   + diff: 0.0

 - nPendulum2: 

   + executable: True

   + diff: 9.186038429149755e-07

 - nPendulum3: 

   + executable: True

   + diff: 0.0

 - nPendulum4: 

   + executable: True

   + diff: 0.0

 - nPendulum5: 

   + executable: True

   + diff: 0.0

 - nPendulum6: 

   + executable: True

   + diff: 0.0

 - nPendulum7: 

   + executable: True

   + diff: 0.0

 - nPendulum8: 

   + executable: True

   + diff: 0.0

 - nPendulum9: 

   + executable: True

   + diff: 0.0

 - fourBarMechanismPointMasses0: 

   + executable: True

   + diff: 0.0

 - fourBarMechanismPointMasses1: 

   + executable: True

   + diff: 0.0

 - fourBarMechanismPointMasses2: 

   + executable: True

   + diff: 0.0

 - fourBarMechanismPointMasses3: 

   + executable: True

   + diff: 0.0

 - fourBarMechanismPointMasses4: 

   + executable: True

   + diff: 0.0

 - fourBarMechanismPointMasses5: 

   + executable: True

   + diff: 0.0

 - fourBarMechanismPointMasses6: 

   + executable: True

   + diff: 0.0

 - fourBarMechanismPointMasses7: 

   + executable: True

   + diff: 0.0

 - fourBarMechanismPointMasses8: 

   + executable: True

   + diff: 0.0

 - fourBarMechanismPointMasses9: 

   + executable: True

   + diff: 0.0

 - springCoupledFlyingRigidBodies0: 

   + executable: False

   + diff: -3

 - springCoupledFlyingRigidBodies1: 

   + executable: False

   + diff: -3

 - springCoupledFlyingRigidBodies2: 

   + executable: False

   + diff: -3

 - springCoupledFlyingRigidBodies3: 

   + executable: False

   + diff: -3

 - springCoupledFlyingRigidBodies4: 

   + executable: False

   + diff: -3

 - springCoupledFlyingRigidBodies5: 

   + executable: False

   + diff: -3

 - springCoupledFlyingRigidBodies6: 

   + executable: False

   + diff: -3

 - springCoupledFlyingRigidBodies7: 

   + executable: False

   + diff: -3

 - springCoupledFlyingRigidBodies8: 

   + executable: False

   + diff: -3

 - springCoupledFlyingRigidBodies9: 

   + executable: False

   + diff: -3

 - torsionalOscillator0: 

   + executable: True

   + diff: 0.0

 - torsionalOscillator1: 

   + executable: True

   + diff: 0.0

 - torsionalOscillator2: 

   + executable: True

   + diff: 0.0

 - torsionalOscillator3: 

   + executable: True

   + diff: 0.0

 - torsionalOscillator4: 

   + executable: True

   + diff: 0.0

 - torsionalOscillator5: 

   + executable: True

   + diff: 0.0

 - torsionalOscillator6: 

   + executable: True

   + diff: 0.0

 - torsionalOscillator7: 

   + executable: True

   + diff: 0.0

 - torsionalOscillator8: 

   + executable: True

   + diff: 0.0

 - torsionalOscillator9: 

   + executable: True

   + diff: 0.0

 - invertedSinglePendulum0: 

   + executable: True

   + diff: 22.57376408611755

 - invertedSinglePendulum1: 

   + executable: True

   + diff: 7.524267406172914e-08

 - invertedSinglePendulum2: 

   + executable: True

   + diff: 2.781610425305931e-07

 - invertedSinglePendulum3: 

   + executable: False

   + diff: -3

 - invertedSinglePendulum4: 

   + executable: True

   + diff: 3.5965890257711475e-07

 - invertedSinglePendulum5: 

   + executable: True

   + diff: 0.0

 - invertedSinglePendulum6: 

   + executable: True

   + diff: 2.484949493203307e-07

 - invertedSinglePendulum7: 

   + executable: True

   + diff: 2.876096313406989e-07

 - invertedSinglePendulum8: 

   + executable: True

   + diff: 2.8762541996369357e-07

 - invertedSinglePendulum9: 

   + executable: True

   + diff: 2.9100265299936953e-07

 - discRollingOnGround0: 

   + executable: True

   + diff: 5.376285454885922e-07

 - discRollingOnGround1: 

   + executable: True

   + diff: 3.1176272772747196e-06

 - discRollingOnGround2: 

   + executable: True

   + diff: 9.465639944935562e-07

 - discRollingOnGround3: 

   + executable: True

   + diff: 1.9083631487974602e-07

 - discRollingOnGround4: 

   + executable: True

   + diff: 1.7228641771703763e-07

 - discRollingOnGround5: 

   + executable: False

   + diff: -3

 - discRollingOnGround6: 

   + executable: True

   + diff: 3.409353986533099e-07

 - discRollingOnGround7: 

   + executable: True

   + diff: 1.57298812770712e-05

 - discRollingOnGround8: 

   + executable: True

   + diff: 1.0010290251586967e-06

 - discRollingOnGround9: 

   + executable: True

   + diff: 1.9824431745451552e-07

 - doublePendulumElasticSpring0: 

   + executable: True

   + diff: 32.60112713433668

 - doublePendulumElasticSpring1: 

   + executable: True

   + diff: 404.0908641127942

 - doublePendulumElasticSpring2: 

   + executable: True

   + diff: 53.592826094006234

 - doublePendulumElasticSpring3: 

   + executable: True

   + diff: 8.004169328011995

 - doublePendulumElasticSpring4: 

   + executable: True

   + diff: 4035.9255521848304

 - doublePendulumElasticSpring5: 

   + executable: True

   + diff: 61.85004566762428

 - doublePendulumElasticSpring6: 

   + executable: True

   + diff: 387.1502976007929

 - doublePendulumElasticSpring7: 

   + executable: True

   + diff: 90.06048686481968

 - doublePendulumElasticSpring8: 

   + executable: True

   + diff: 18.661814271569263

 - doublePendulumElasticSpring9: 

   + executable: True

   + diff: 663.2065372319381

 - nPendulumElasticSpring0: 

   + executable: True

   + diff: 0.0

 - nPendulumElasticSpring1: 

   + executable: True

   + diff: 0.0

 - nPendulumElasticSpring2: 

   + executable: True

   + diff: 25.42108376085161

 - nPendulumElasticSpring3: 

   + executable: True

   + diff: 0.0

 - nPendulumElasticSpring4: 

   + executable: True

   + diff: 10.776983581115626

 - nPendulumElasticSpring5: 

   + executable: True

   + diff: 67.67455362366857

 - nPendulumElasticSpring6: 

   + executable: True

   + diff: 0.0

 - nPendulumElasticSpring7: 

   + executable: True

   + diff: 0.0

 - nPendulumElasticSpring8: 

   + executable: True

   + diff: 45.47491780817318

 - nPendulumElasticSpring9: 

   + executable: True

   + diff: 60.873444061569884

 - elasticChain0: 

   + executable: True

   + diff: 0.0

 - elasticChain1: 

   + executable: True

   + diff: 0.0

 - elasticChain2: 

   + executable: True

   + diff: 0.0

 - elasticChain3: 

   + executable: True

   + diff: 0.0

 - elasticChain4: 

   + executable: True

   + diff: 0.0

 - elasticChain5: 

   + executable: True

   + diff: 0.0

 - elasticChain6: 

   + executable: True

   + diff: 0.0

 - elasticChain7: 

   + executable: True

   + diff: 0.0

 - elasticChain8: 

   + executable: True

   + diff: 0.0

 - elasticChain9: 

   + executable: True

   + diff: 0.0

 - singlePendulumRigidBody0: 

   + executable: True

   + diff: 0.0

 - singlePendulumRigidBody1: 

   + executable: True

   + diff: 0.0

 - singlePendulumRigidBody2: 

   + executable: True

   + diff: 0.0

 - singlePendulumRigidBody3: 

   + executable: True

   + diff: 0.0

 - singlePendulumRigidBody4: 

   + executable: True

   + diff: 0.0

 - singlePendulumRigidBody5: 

   + executable: True

   + diff: 0.0

 - singlePendulumRigidBody6: 

   + executable: True

   + diff: 0.0

 - singlePendulumRigidBody7: 

   + executable: True

   + diff: 0.0

 - singlePendulumRigidBody8: 

   + executable: True

   + diff: 0.0

 - singlePendulumRigidBody9: 

   + executable: True

   + diff: 0.0

 - massPointOnStringRigid0: 

   + executable: True

   + diff: 391.5175272263096

 - massPointOnStringRigid1: 

   + executable: True

   + diff: 0.0

 - massPointOnStringRigid2: 

   + executable: True

   + diff: 343.2148235990628

 - massPointOnStringRigid3: 

   + executable: True

   + diff: 253.72903291292923

 - massPointOnStringRigid4: 

   + executable: True

   + diff: 296.86371968397975

 - massPointOnStringRigid5: 

   + executable: True

   + diff: 0.0

 - massPointOnStringRigid6: 

   + executable: True

   + diff: 0.0

 - massPointOnStringRigid7: 

   + executable: True

   + diff: 0.0

 - massPointOnStringRigid8: 

   + executable: True

   + diff: 0.0

 - massPointOnStringRigid9: 

   + executable: True

   + diff: 0.0

 - massPointOnStringElastic0: 

   + executable: True

   + diff: 0.0

 - massPointOnStringElastic1: 

   + executable: True

   + diff: 235.8719002726565

 - massPointOnStringElastic2: 

   + executable: True

   + diff: 0.0

 - massPointOnStringElastic3: 

   + executable: True

   + diff: 231.58294973869505

 - massPointOnStringElastic4: 

   + executable: True

   + diff: 262.19638516115043

 - massPointOnStringElastic5: 

   + executable: True

   + diff: 0.0

 - massPointOnStringElastic6: 

   + executable: True

   + diff: 0.0

 - massPointOnStringElastic7: 

   + executable: True

   + diff: 330.76033649002693

 - massPointOnStringElastic8: 

   + executable: True

   + diff: 351.8081566622678

 - massPointOnStringElastic9: 

   + executable: True

   + diff: 200.71582179748725

 - linkOnTwoPrismaticJoints0: 

   + executable: True

   + diff: 23.21415646733

 - linkOnTwoPrismaticJoints1: 

   + executable: True

   + diff: 0.0

 - linkOnTwoPrismaticJoints2: 

   + executable: True

   + diff: 0.0

 - linkOnTwoPrismaticJoints3: 

   + executable: True

   + diff: 0.0

 - linkOnTwoPrismaticJoints4: 

   + executable: True

   + diff: 0.0

 - linkOnTwoPrismaticJoints5: 

   + executable: True

   + diff: 0.0

 - linkOnTwoPrismaticJoints6: 

   + executable: True

   + diff: 0.0

 - linkOnTwoPrismaticJoints7: 

   + executable: True

   + diff: 0.0

 - linkOnTwoPrismaticJoints8: 

   + executable: True

   + diff: 0.0

 - linkOnTwoPrismaticJoints9: 

   + executable: True

   + diff: 0.0

 - flyingRigidBody0: 

   + executable: True

   + diff: 0.0

 - flyingRigidBody1: 

   + executable: True

   + diff: 158.41454039644293

 - flyingRigidBody2: 

   + executable: True

   + diff: 0.0

 - flyingRigidBody3: 

   + executable: True

   + diff: 158.41454039644296

 - flyingRigidBody4: 

   + executable: True

   + diff: 0.0

 - flyingRigidBody5: 

   + executable: True

   + diff: 0.0

 - flyingRigidBody6: 

   + executable: True

   + diff: 0.0

 - flyingRigidBody7: 

   + executable: True

   + diff: 0.0

 - flyingRigidBody8: 

   + executable: True

   + diff: 60.23305154727137

 - flyingRigidBody9: 

   + executable: True

   + diff: 158.41454039644293

 - suspendedRigidBody0: 

   + executable: True

   + diff: 0.0

 - suspendedRigidBody1: 

   + executable: True

   + diff: 0.0

 - suspendedRigidBody2: 

   + executable: True

   + diff: 0.0

 - suspendedRigidBody3: 

   + executable: True

   + diff: 0.0

 - suspendedRigidBody4: 

   + executable: True

   + diff: 0.0

 - suspendedRigidBody5: 

   + executable: True

   + diff: 0.0

 - suspendedRigidBody6: 

   + executable: True

   + diff: 0.0

 - suspendedRigidBody7: 

   + executable: True

   + diff: 0.0

 - suspendedRigidBody8: 

   + executable: True

   + diff: 0.0

 - suspendedRigidBody9: 

   + executable: True

   + diff: 0.0

 - gyroscopeOnSphericalJoint0: 

   + executable: True

   + diff: 0.0

 - gyroscopeOnSphericalJoint1: 

   + executable: True

   + diff: 0.0

 - gyroscopeOnSphericalJoint2: 

   + executable: True

   + diff: 0.0

 - gyroscopeOnSphericalJoint3: 

   + executable: True

   + diff: 0.0

 - gyroscopeOnSphericalJoint4: 

   + executable: True

   + diff: 0.0

 - gyroscopeOnSphericalJoint5: 

   + executable: True

   + diff: 0.0

 - gyroscopeOnSphericalJoint6: 

   + executable: True

   + diff: 0.0

 - gyroscopeOnSphericalJoint7: 

   + executable: True

   + diff: 0.0

 - gyroscopeOnSphericalJoint8: 

   + executable: True

   + diff: 0.0

 - gyroscopeOnSphericalJoint9: 

   + executable: True

   + diff: 0.0

 - prismaticJointSystem0: 

   + executable: True

   + diff: 0.0

 - prismaticJointSystem1: 

   + executable: True

   + diff: 0.0

 - prismaticJointSystem2: 

   + executable: True

   + diff: 0.0

 - prismaticJointSystem3: 

   + executable: True

   + diff: 0.0

 - prismaticJointSystem4: 

   + executable: True

   + diff: 0.0

 - prismaticJointSystem5: 

   + executable: True

   + diff: 0.0

 - prismaticJointSystem6: 

   + executable: True

   + diff: 0.0

 - prismaticJointSystem7: 

   + executable: True

   + diff: 0.0

 - prismaticJointSystem8: 

   + executable: True

   + diff: 0.0

 - prismaticJointSystem9: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithSprings0: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithSprings1: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithSprings2: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithSprings3: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithSprings4: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithSprings5: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithSprings6: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithSprings7: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithSprings8: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithSprings9: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithDistances0: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithDistances1: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithDistances2: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithDistances3: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithDistances4: 

   + executable: True

   + diff: 5.5509530775492895

 - twoMassPointsWithDistances5: 

   + executable: True

   + diff: 7.721043680019

 - twoMassPointsWithDistances6: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithDistances7: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithDistances8: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithDistances9: 

   + executable: True

   + diff: 0.0

 - rigidRotorSimplySupported0: 

   + executable: False

   + diff: -3

 - rigidRotorSimplySupported1: 

   + executable: False

   + diff: -3

 - rigidRotorSimplySupported2: 

   + executable: False

   + diff: -3

 - rigidRotorSimplySupported3: 

   + executable: False

   + diff: -3

 - rigidRotorSimplySupported4: 

   + executable: False

   + diff: -3

 - rigidRotorSimplySupported5: 

   + executable: False

   + diff: -3

 - rigidRotorSimplySupported6: 

   + executable: False

   + diff: -3

 - rigidRotorSimplySupported7: 

   + executable: False

   + diff: -3

 - rigidRotorSimplySupported8: 

   + executable: False

   + diff: -3

 - rigidRotorSimplySupported9: 

   + executable: False

   + diff: -3

 - rigidRotorUnbalanced0: 

   + executable: False

   + diff: -3

 - rigidRotorUnbalanced1: 

   + executable: False

   + diff: -3

 - rigidRotorUnbalanced2: 

   + executable: False

   + diff: -3

 - rigidRotorUnbalanced3: 

   + executable: False

   + diff: -3

 - rigidRotorUnbalanced4: 

   + executable: True

   + diff: 8373.376129891845

 - rigidRotorUnbalanced5: 

   + executable: False

   + diff: -3

 - rigidRotorUnbalanced6: 

   + executable: False

   + diff: -3

 - rigidRotorUnbalanced7: 

   + executable: False

   + diff: -3

 - rigidRotorUnbalanced8: 

   + executable: False

   + diff: -3

 - rigidRotorUnbalanced9: 

   + executable: False

   + diff: -3

 - doublePendulumRigidBodies0: 

   + executable: True

   + diff: 0.0

 - doublePendulumRigidBodies1: 

   + executable: True

   + diff: 0.0

 - doublePendulumRigidBodies2: 

   + executable: True

   + diff: 0.0

 - doublePendulumRigidBodies3: 

   + executable: True

   + diff: 0.0

 - doublePendulumRigidBodies4: 

   + executable: True

   + diff: 0.0

 - doublePendulumRigidBodies5: 

   + executable: True

   + diff: 0.0

 - doublePendulumRigidBodies6: 

   + executable: True

   + diff: 0.0

 - doublePendulumRigidBodies7: 

   + executable: True

   + diff: 0.0

 - doublePendulumRigidBodies8: 

   + executable: True

   + diff: 0.0

 - doublePendulumRigidBodies9: 

   + executable: True

   + diff: 0.0

 - sliderCrankRigidBodies0: 

   + executable: True

   + diff: 0.0

 - sliderCrankRigidBodies1: 

   + executable: True

   + diff: 0.0

 - sliderCrankRigidBodies2: 

   + executable: True

   + diff: 0.0

 - sliderCrankRigidBodies3: 

   + executable: True

   + diff: 0.0

 - sliderCrankRigidBodies4: 

   + executable: True

   + diff: 15.031137432903025

 - sliderCrankRigidBodies5: 

   + executable: True

   + diff: 31.675394429505427

 - sliderCrankRigidBodies6: 

   + executable: True

   + diff: 0.0

 - sliderCrankRigidBodies7: 

   + executable: True

   + diff: 0.0

 - sliderCrankRigidBodies8: 

   + executable: True

   + diff: 0.0

 - sliderCrankRigidBodies9: 

   + executable: True

   + diff: 18.728706598495272

 - model flyingMassPoint0: exec=1,diff=0

 - model flyingMassPoint1: exec=1,diff=0

 - model flyingMassPoint2: exec=1,diff=0

 - model flyingMassPoint3: exec=1,diff=0

 - model flyingMassPoint4: exec=1,diff=0

 - model flyingMassPoint5: exec=1,diff=0

 - model flyingMassPoint6: exec=1,diff=0

 - model flyingMassPoint7: exec=1,diff=0

 - model flyingMassPoint8: exec=1,diff=0

 - model flyingMassPoint9: exec=1,diff=0


SUMMARY model flyingMassPoint: exec=100.0%, correct=100.0%

 - model freeFallMassPoint0: exec=1,diff=0

 - model freeFallMassPoint1: exec=1,diff=0

 - model freeFallMassPoint2: exec=1,diff=0

 - model freeFallMassPoint3: exec=1,diff=0

 - model freeFallMassPoint4: exec=1,diff=0

 - model freeFallMassPoint5: exec=1,diff=0

 - model freeFallMassPoint6: exec=1,diff=0

 - model freeFallMassPoint7: exec=1,diff=0

 - model freeFallMassPoint8: exec=1,diff=0

 - model freeFallMassPoint9: exec=1,diff=0


SUMMARY model freeFallMassPoint: exec=100.0%, correct=100.0%

 - model singleMassOscillator0: exec=1,diff=0

 - model singleMassOscillator1: exec=1,diff=0

 - model singleMassOscillator2: exec=1,diff=0

 - model singleMassOscillator3: exec=1,diff=0

 - model singleMassOscillator4: exec=1,diff=0

 - model singleMassOscillator5: exec=1,diff=0

 - model singleMassOscillator6: exec=1,diff=0

 - model singleMassOscillator7: exec=1,diff=0

 - model singleMassOscillator8: exec=1,diff=0

 - model singleMassOscillator9: exec=1,diff=0


SUMMARY model singleMassOscillator: exec=100.0%, correct=100.0%

 - model singleMassOscillatorGravity0: exec=1,diff=0

 - model singleMassOscillatorGravity1: exec=1,diff=0

 - model singleMassOscillatorGravity2: exec=1,diff=0

 - model singleMassOscillatorGravity3: exec=1,diff=0

 - model singleMassOscillatorGravity4: exec=1,diff=0

 - model singleMassOscillatorGravity5: exec=1,diff=0

 - model singleMassOscillatorGravity6: exec=1,diff=0

 - model singleMassOscillatorGravity7: exec=1,diff=0

 - model singleMassOscillatorGravity8: exec=1,diff=0

 - model singleMassOscillatorGravity9: exec=1,diff=0


SUMMARY model singleMassOscillatorGravity: exec=100.0%, correct=100.0%

 - model sliderCrankSimple0: exec=1,diff=14.7889

 - model sliderCrankSimple1: exec=1,diff=0

 - model sliderCrankSimple2: exec=1,diff=12.8696

 - model sliderCrankSimple3: exec=1,diff=0

 - model sliderCrankSimple4: exec=1,diff=0

 - model sliderCrankSimple5: exec=1,diff=68.0156

 - model sliderCrankSimple6: exec=1,diff=126.747

 - model sliderCrankSimple7: exec=1,diff=0

 - model sliderCrankSimple8: exec=1,diff=0

 - model sliderCrankSimple9: exec=1,diff=35.822


SUMMARY model sliderCrankSimple: exec=100.0%, correct=50.0%

 - model singlePendulumElasticSpring0: exec=1,diff=32.6395

 - model singlePendulumElasticSpring1: exec=1,diff=88.8006

 - model singlePendulumElasticSpring2: exec=1,diff=105.387

 - model singlePendulumElasticSpring3: exec=1,diff=154.61

 - model singlePendulumElasticSpring4: exec=1,diff=39.2853

 - model singlePendulumElasticSpring5: exec=1,diff=86.0399

 - model singlePendulumElasticSpring6: exec=1,diff=24.2537

 - model singlePendulumElasticSpring7: exec=1,diff=50.7788

 - model singlePendulumElasticSpring8: exec=1,diff=133.171

 - model singlePendulumElasticSpring9: exec=1,diff=75.716


SUMMARY model singlePendulumElasticSpring: exec=100.0%, correct=0.0%

 - model singleMassOscillatorUserFunction0: exec=1,diff=0

 - model singleMassOscillatorUserFunction1: exec=1,diff=290.506

 - model singleMassOscillatorUserFunction2: exec=1,diff=0

 - model singleMassOscillatorUserFunction3: exec=1,diff=0

 - model singleMassOscillatorUserFunction4: exec=1,diff=0

 - model singleMassOscillatorUserFunction5: exec=1,diff=0

 - model singleMassOscillatorUserFunction6: exec=1,diff=0

 - model singleMassOscillatorUserFunction7: exec=1,diff=0

 - model singleMassOscillatorUserFunction8: exec=1,diff=0

 - model singleMassOscillatorUserFunction9: exec=1,diff=518.221


SUMMARY model singleMassOscillatorUserFunction: exec=100.0%, correct=80.0%

 - model spinningDisc0: exec=1,diff=0

 - model spinningDisc1: exec=1,diff=0

 - model spinningDisc2: exec=1,diff=0

 - model spinningDisc3: exec=1,diff=0

 - model spinningDisc4: exec=1,diff=0

 - model spinningDisc5: exec=1,diff=0

 - model spinningDisc6: exec=1,diff=0

 - model spinningDisc7: exec=1,diff=0

 - model spinningDisc8: exec=1,diff=0

 - model spinningDisc9: exec=1,diff=0


SUMMARY model spinningDisc: exec=100.0%, correct=100.0%

 - model doubleMassOscillator0: exec=1,diff=0

 - model doubleMassOscillator1: exec=1,diff=0

 - model doubleMassOscillator2: exec=1,diff=0

 - model doubleMassOscillator3: exec=1,diff=0

 - model doubleMassOscillator4: exec=1,diff=0

 - model doubleMassOscillator5: exec=1,diff=0

 - model doubleMassOscillator6: exec=1,diff=0

 - model doubleMassOscillator7: exec=1,diff=0

 - model doubleMassOscillator8: exec=1,diff=0

 - model doubleMassOscillator9: exec=1,diff=0


SUMMARY model doubleMassOscillator: exec=100.0%, correct=100.0%

 - model nMassOscillator0: exec=1,diff=142.977

 - model nMassOscillator1: exec=1,diff=0

 - model nMassOscillator2: exec=1,diff=132.45

 - model nMassOscillator3: exec=1,diff=366.928

 - model nMassOscillator4: exec=1,diff=291.485

 - model nMassOscillator5: exec=1,diff=64.3266

 - model nMassOscillator6: exec=1,diff=290.082

 - model nMassOscillator7: exec=1,diff=212.767

 - model nMassOscillator8: exec=1,diff=0

 - model nMassOscillator9: exec=1,diff=136.442


SUMMARY model nMassOscillator: exec=100.0%, correct=20.0%

 - model singlePendulum0: exec=1,diff=95.7133

 - model singlePendulum1: exec=1,diff=10.8161

 - model singlePendulum2: exec=1,diff=30.2107

 - model singlePendulum3: exec=0,diff=-3.0

 - model singlePendulum4: exec=1,diff=0

 - model singlePendulum5: exec=1,diff=126.761

 - model singlePendulum6: exec=1,diff=20.8134

 - model singlePendulum7: exec=1,diff=7.11612e-07

 - model singlePendulum8: exec=1,diff=21.2662

 - model singlePendulum9: exec=1,diff=150.043


SUMMARY model singlePendulum: exec=90.0%, correct=20.0%

 - model doublePendulum0: exec=1,diff=119.547

 - model doublePendulum1: exec=1,diff=106.743

 - model doublePendulum2: exec=1,diff=43.1283

 - model doublePendulum3: exec=1,diff=109.105

 - model doublePendulum4: exec=1,diff=138.249

 - model doublePendulum5: exec=1,diff=23.5712

 - model doublePendulum6: exec=1,diff=197.667

 - model doublePendulum7: exec=1,diff=124.854

 - model doublePendulum8: exec=1,diff=113.439

 - model doublePendulum9: exec=1,diff=221.7


SUMMARY model doublePendulum: exec=100.0%, correct=0.0%

 - model nPendulum0: exec=1,diff=2.06025e-06

 - model nPendulum1: exec=1,diff=0

 - model nPendulum2: exec=1,diff=9.18604e-07

 - model nPendulum3: exec=1,diff=0

 - model nPendulum4: exec=1,diff=0

 - model nPendulum5: exec=1,diff=0

 - model nPendulum6: exec=1,diff=0

 - model nPendulum7: exec=1,diff=0

 - model nPendulum8: exec=1,diff=0

 - model nPendulum9: exec=1,diff=0


SUMMARY model nPendulum: exec=100.0%, correct=100.0%

 - model fourBarMechanismPointMasses0: exec=1,diff=0

 - model fourBarMechanismPointMasses1: exec=1,diff=0

 - model fourBarMechanismPointMasses2: exec=1,diff=0

 - model fourBarMechanismPointMasses3: exec=1,diff=0

 - model fourBarMechanismPointMasses4: exec=1,diff=0

 - model fourBarMechanismPointMasses5: exec=1,diff=0

 - model fourBarMechanismPointMasses6: exec=1,diff=0

 - model fourBarMechanismPointMasses7: exec=1,diff=0

 - model fourBarMechanismPointMasses8: exec=1,diff=0

 - model fourBarMechanismPointMasses9: exec=1,diff=0


SUMMARY model fourBarMechanismPointMasses: exec=100.0%, correct=100.0%

 - model springCoupledFlyingRigidBodies0: exec=0,diff=-3.0

 - model springCoupledFlyingRigidBodies1: exec=0,diff=-3.0

 - model springCoupledFlyingRigidBodies2: exec=0,diff=-3.0

 - model springCoupledFlyingRigidBodies3: exec=0,diff=-3.0

 - model springCoupledFlyingRigidBodies4: exec=0,diff=-3.0

 - model springCoupledFlyingRigidBodies5: exec=0,diff=-3.0

 - model springCoupledFlyingRigidBodies6: exec=0,diff=-3.0

 - model springCoupledFlyingRigidBodies7: exec=0,diff=-3.0

 - model springCoupledFlyingRigidBodies8: exec=0,diff=-3.0

 - model springCoupledFlyingRigidBodies9: exec=0,diff=-3.0


SUMMARY model springCoupledFlyingRigidBodies: exec=0.0%, correct=0.0%

 - model torsionalOscillator0: exec=1,diff=0

 - model torsionalOscillator1: exec=1,diff=0

 - model torsionalOscillator2: exec=1,diff=0

 - model torsionalOscillator3: exec=1,diff=0

 - model torsionalOscillator4: exec=1,diff=0

 - model torsionalOscillator5: exec=1,diff=0

 - model torsionalOscillator6: exec=1,diff=0

 - model torsionalOscillator7: exec=1,diff=0

 - model torsionalOscillator8: exec=1,diff=0

 - model torsionalOscillator9: exec=1,diff=0


SUMMARY model torsionalOscillator: exec=100.0%, correct=100.0%

 - model invertedSinglePendulum0: exec=1,diff=22.5738

 - model invertedSinglePendulum1: exec=1,diff=7.52427e-08

 - model invertedSinglePendulum2: exec=1,diff=2.78161e-07

 - model invertedSinglePendulum3: exec=0,diff=-3.0

 - model invertedSinglePendulum4: exec=1,diff=3.59659e-07

 - model invertedSinglePendulum5: exec=1,diff=0

 - model invertedSinglePendulum6: exec=1,diff=2.48495e-07

 - model invertedSinglePendulum7: exec=1,diff=2.8761e-07

 - model invertedSinglePendulum8: exec=1,diff=2.87625e-07

 - model invertedSinglePendulum9: exec=1,diff=2.91003e-07


SUMMARY model invertedSinglePendulum: exec=90.0%, correct=80.0%

 - model discRollingOnGround0: exec=1,diff=5.37629e-07

 - model discRollingOnGround1: exec=1,diff=3.11763e-06

 - model discRollingOnGround2: exec=1,diff=9.46564e-07

 - model discRollingOnGround3: exec=1,diff=1.90836e-07

 - model discRollingOnGround4: exec=1,diff=1.72286e-07

 - model discRollingOnGround5: exec=0,diff=-3.0

 - model discRollingOnGround6: exec=1,diff=3.40935e-07

 - model discRollingOnGround7: exec=1,diff=1.57299e-05

 - model discRollingOnGround8: exec=1,diff=1.00103e-06

 - model discRollingOnGround9: exec=1,diff=1.98244e-07


SUMMARY model discRollingOnGround: exec=90.0%, correct=80.0%

 - model doublePendulumElasticSpring0: exec=1,diff=32.6011

 - model doublePendulumElasticSpring1: exec=1,diff=404.091

 - model doublePendulumElasticSpring2: exec=1,diff=53.5928

 - model doublePendulumElasticSpring3: exec=1,diff=8.00417

 - model doublePendulumElasticSpring4: exec=1,diff=4035.93

 - model doublePendulumElasticSpring5: exec=1,diff=61.85

 - model doublePendulumElasticSpring6: exec=1,diff=387.15

 - model doublePendulumElasticSpring7: exec=1,diff=90.0605

 - model doublePendulumElasticSpring8: exec=1,diff=18.6618

 - model doublePendulumElasticSpring9: exec=1,diff=663.207


SUMMARY model doublePendulumElasticSpring: exec=100.0%, correct=0.0%

 - model nPendulumElasticSpring0: exec=1,diff=0

 - model nPendulumElasticSpring1: exec=1,diff=0

 - model nPendulumElasticSpring2: exec=1,diff=25.4211

 - model nPendulumElasticSpring3: exec=1,diff=0

 - model nPendulumElasticSpring4: exec=1,diff=10.777

 - model nPendulumElasticSpring5: exec=1,diff=67.6746

 - model nPendulumElasticSpring6: exec=1,diff=0

 - model nPendulumElasticSpring7: exec=1,diff=0

 - model nPendulumElasticSpring8: exec=1,diff=45.4749

 - model nPendulumElasticSpring9: exec=1,diff=60.8734


SUMMARY model nPendulumElasticSpring: exec=100.0%, correct=50.0%

 - model elasticChain0: exec=1,diff=0

 - model elasticChain1: exec=1,diff=0

 - model elasticChain2: exec=1,diff=0

 - model elasticChain3: exec=1,diff=0

 - model elasticChain4: exec=1,diff=0

 - model elasticChain5: exec=1,diff=0

 - model elasticChain6: exec=1,diff=0

 - model elasticChain7: exec=1,diff=0

 - model elasticChain8: exec=1,diff=0

 - model elasticChain9: exec=1,diff=0


SUMMARY model elasticChain: exec=100.0%, correct=100.0%

 - model singlePendulumRigidBody0: exec=1,diff=0

 - model singlePendulumRigidBody1: exec=1,diff=0

 - model singlePendulumRigidBody2: exec=1,diff=0

 - model singlePendulumRigidBody3: exec=1,diff=0

 - model singlePendulumRigidBody4: exec=1,diff=0

 - model singlePendulumRigidBody5: exec=1,diff=0

 - model singlePendulumRigidBody6: exec=1,diff=0

 - model singlePendulumRigidBody7: exec=1,diff=0

 - model singlePendulumRigidBody8: exec=1,diff=0

 - model singlePendulumRigidBody9: exec=1,diff=0


SUMMARY model singlePendulumRigidBody: exec=100.0%, correct=100.0%

 - model massPointOnStringRigid0: exec=1,diff=391.518

 - model massPointOnStringRigid1: exec=1,diff=0

 - model massPointOnStringRigid2: exec=1,diff=343.215

 - model massPointOnStringRigid3: exec=1,diff=253.729

 - model massPointOnStringRigid4: exec=1,diff=296.864

 - model massPointOnStringRigid5: exec=1,diff=0

 - model massPointOnStringRigid6: exec=1,diff=0

 - model massPointOnStringRigid7: exec=1,diff=0

 - model massPointOnStringRigid8: exec=1,diff=0

 - model massPointOnStringRigid9: exec=1,diff=0


SUMMARY model massPointOnStringRigid: exec=100.0%, correct=60.0%

 - model massPointOnStringElastic0: exec=1,diff=0

 - model massPointOnStringElastic1: exec=1,diff=235.872

 - model massPointOnStringElastic2: exec=1,diff=0

 - model massPointOnStringElastic3: exec=1,diff=231.583

 - model massPointOnStringElastic4: exec=1,diff=262.196

 - model massPointOnStringElastic5: exec=1,diff=0

 - model massPointOnStringElastic6: exec=1,diff=0

 - model massPointOnStringElastic7: exec=1,diff=330.76

 - model massPointOnStringElastic8: exec=1,diff=351.808

 - model massPointOnStringElastic9: exec=1,diff=200.716


SUMMARY model massPointOnStringElastic: exec=100.0%, correct=40.0%

 - model linkOnTwoPrismaticJoints0: exec=1,diff=23.2142

 - model linkOnTwoPrismaticJoints1: exec=1,diff=0

 - model linkOnTwoPrismaticJoints2: exec=1,diff=0

 - model linkOnTwoPrismaticJoints3: exec=1,diff=0

 - model linkOnTwoPrismaticJoints4: exec=1,diff=0

 - model linkOnTwoPrismaticJoints5: exec=1,diff=0

 - model linkOnTwoPrismaticJoints6: exec=1,diff=0

 - model linkOnTwoPrismaticJoints7: exec=1,diff=0

 - model linkOnTwoPrismaticJoints8: exec=1,diff=0

 - model linkOnTwoPrismaticJoints9: exec=1,diff=0


SUMMARY model linkOnTwoPrismaticJoints: exec=100.0%, correct=90.0%

 - model flyingRigidBody0: exec=1,diff=0

 - model flyingRigidBody1: exec=1,diff=158.415

 - model flyingRigidBody2: exec=1,diff=0

 - model flyingRigidBody3: exec=1,diff=158.415

 - model flyingRigidBody4: exec=1,diff=0

 - model flyingRigidBody5: exec=1,diff=0

 - model flyingRigidBody6: exec=1,diff=0

 - model flyingRigidBody7: exec=1,diff=0

 - model flyingRigidBody8: exec=1,diff=60.2331

 - model flyingRigidBody9: exec=1,diff=158.415


SUMMARY model flyingRigidBody: exec=100.0%, correct=60.0%

 - model suspendedRigidBody0: exec=1,diff=0

 - model suspendedRigidBody1: exec=1,diff=0

 - model suspendedRigidBody2: exec=1,diff=0

 - model suspendedRigidBody3: exec=1,diff=0

 - model suspendedRigidBody4: exec=1,diff=0

 - model suspendedRigidBody5: exec=1,diff=0

 - model suspendedRigidBody6: exec=1,diff=0

 - model suspendedRigidBody7: exec=1,diff=0

 - model suspendedRigidBody8: exec=1,diff=0

 - model suspendedRigidBody9: exec=1,diff=0


SUMMARY model suspendedRigidBody: exec=100.0%, correct=100.0%

 - model gyroscopeOnSphericalJoint0: exec=1,diff=0

 - model gyroscopeOnSphericalJoint1: exec=1,diff=0

 - model gyroscopeOnSphericalJoint2: exec=1,diff=0

 - model gyroscopeOnSphericalJoint3: exec=1,diff=0

 - model gyroscopeOnSphericalJoint4: exec=1,diff=0

 - model gyroscopeOnSphericalJoint5: exec=1,diff=0

 - model gyroscopeOnSphericalJoint6: exec=1,diff=0

 - model gyroscopeOnSphericalJoint7: exec=1,diff=0

 - model gyroscopeOnSphericalJoint8: exec=1,diff=0

 - model gyroscopeOnSphericalJoint9: exec=1,diff=0


SUMMARY model gyroscopeOnSphericalJoint: exec=100.0%, correct=100.0%

 - model prismaticJointSystem0: exec=1,diff=0

 - model prismaticJointSystem1: exec=1,diff=0

 - model prismaticJointSystem2: exec=1,diff=0

 - model prismaticJointSystem3: exec=1,diff=0

 - model prismaticJointSystem4: exec=1,diff=0

 - model prismaticJointSystem5: exec=1,diff=0

 - model prismaticJointSystem6: exec=1,diff=0

 - model prismaticJointSystem7: exec=1,diff=0

 - model prismaticJointSystem8: exec=1,diff=0

 - model prismaticJointSystem9: exec=1,diff=0


SUMMARY model prismaticJointSystem: exec=100.0%, correct=100.0%

 - model twoMassPointsWithSprings0: exec=1,diff=0

 - model twoMassPointsWithSprings1: exec=1,diff=0

 - model twoMassPointsWithSprings2: exec=1,diff=0

 - model twoMassPointsWithSprings3: exec=1,diff=0

 - model twoMassPointsWithSprings4: exec=1,diff=0

 - model twoMassPointsWithSprings5: exec=1,diff=0

 - model twoMassPointsWithSprings6: exec=1,diff=0

 - model twoMassPointsWithSprings7: exec=1,diff=0

 - model twoMassPointsWithSprings8: exec=1,diff=0

 - model twoMassPointsWithSprings9: exec=1,diff=0


SUMMARY model twoMassPointsWithSprings: exec=100.0%, correct=100.0%

 - model twoMassPointsWithDistances0: exec=1,diff=0

 - model twoMassPointsWithDistances1: exec=1,diff=0

 - model twoMassPointsWithDistances2: exec=1,diff=0

 - model twoMassPointsWithDistances3: exec=1,diff=0

 - model twoMassPointsWithDistances4: exec=1,diff=5.55095

 - model twoMassPointsWithDistances5: exec=1,diff=7.72104

 - model twoMassPointsWithDistances6: exec=1,diff=0

 - model twoMassPointsWithDistances7: exec=1,diff=0

 - model twoMassPointsWithDistances8: exec=1,diff=0

 - model twoMassPointsWithDistances9: exec=1,diff=0


SUMMARY model twoMassPointsWithDistances: exec=100.0%, correct=80.0%

 - model rigidRotorSimplySupported0: exec=0,diff=-3.0

 - model rigidRotorSimplySupported1: exec=0,diff=-3.0

 - model rigidRotorSimplySupported2: exec=0,diff=-3.0

 - model rigidRotorSimplySupported3: exec=0,diff=-3.0

 - model rigidRotorSimplySupported4: exec=0,diff=-3.0

 - model rigidRotorSimplySupported5: exec=0,diff=-3.0

 - model rigidRotorSimplySupported6: exec=0,diff=-3.0

 - model rigidRotorSimplySupported7: exec=0,diff=-3.0

 - model rigidRotorSimplySupported8: exec=0,diff=-3.0

 - model rigidRotorSimplySupported9: exec=0,diff=-3.0


SUMMARY model rigidRotorSimplySupported: exec=0.0%, correct=0.0%

 - model rigidRotorUnbalanced0: exec=0,diff=-3.0

 - model rigidRotorUnbalanced1: exec=0,diff=-3.0

 - model rigidRotorUnbalanced2: exec=0,diff=-3.0

 - model rigidRotorUnbalanced3: exec=0,diff=-3.0

 - model rigidRotorUnbalanced4: exec=1,diff=8373.38

 - model rigidRotorUnbalanced5: exec=0,diff=-3.0

 - model rigidRotorUnbalanced6: exec=0,diff=-3.0

 - model rigidRotorUnbalanced7: exec=0,diff=-3.0

 - model rigidRotorUnbalanced8: exec=0,diff=-3.0

 - model rigidRotorUnbalanced9: exec=0,diff=-3.0


SUMMARY model rigidRotorUnbalanced: exec=10.0%, correct=0.0%

 - model doublePendulumRigidBodies0: exec=1,diff=0

 - model doublePendulumRigidBodies1: exec=1,diff=0

 - model doublePendulumRigidBodies2: exec=1,diff=0

 - model doublePendulumRigidBodies3: exec=1,diff=0

 - model doublePendulumRigidBodies4: exec=1,diff=0

 - model doublePendulumRigidBodies5: exec=1,diff=0

 - model doublePendulumRigidBodies6: exec=1,diff=0

 - model doublePendulumRigidBodies7: exec=1,diff=0

 - model doublePendulumRigidBodies8: exec=1,diff=0

 - model doublePendulumRigidBodies9: exec=1,diff=0


SUMMARY model doublePendulumRigidBodies: exec=100.0%, correct=100.0%

 - model sliderCrankRigidBodies0: exec=1,diff=0

 - model sliderCrankRigidBodies1: exec=1,diff=0

 - model sliderCrankRigidBodies2: exec=1,diff=0

 - model sliderCrankRigidBodies3: exec=1,diff=0

 - model sliderCrankRigidBodies4: exec=1,diff=15.0311

 - model sliderCrankRigidBodies5: exec=1,diff=31.6754

 - model sliderCrankRigidBodies6: exec=1,diff=0

 - model sliderCrankRigidBodies7: exec=1,diff=0

 - model sliderCrankRigidBodies8: exec=1,diff=0

 - model sliderCrankRigidBodies9: exec=1,diff=18.7287


SUMMARY model sliderCrankRigidBodies: exec=100.0%, correct=70.0%


***

numberOfTokensGlobal:140427, numberOfRemovedTokensGlobal:0, tokensPerSecondGlobal:32.615083225429835


***


executable      = 90.86%
correct         = 68.0%
