
***

RunMBSmodelTests: using LLM model: phi-4-Q4_0.gguf

***

Creating simulation code for mbs models: ['flyingMassPoint', 'freeFallMassPoint', 'singleMassOscillator', 'singleMassOscillatorGravity', 'sliderCrankSimple', 'singlePendulumElasticSpring', 'singleMassOscillatorUserFunction', 'spinningDisc', 'doubleMassOscillator', 'nMassOscillator', 'singlePendulum', 'doublePendulum', 'nPendulum', 'fourBarMechanismPointMasses', 'springCoupledFlyingRigidBodies', 'torsionalOscillator', 'invertedSinglePendulum', 'discRollingOnGround', 'doublePendulumElasticSpring', 'nPendulumElasticSpring', 'elasticChain', 'singlePendulumRigidBody', 'massPointOnStringRigid', 'massPointOnStringElastic', 'linkOnTwoPrismaticJoints', 'flyingRigidBody', 'suspendedRigidBody', 'gyroscopeOnSphericalJoint', 'prismaticJointSystem', 'twoMassPointsWithSprings', 'twoMassPointsWithDistances', 'rigidRotorSimplySupported', 'rigidRotorUnbalanced', 'doublePendulumRigidBodies', 'sliderCrankRigidBodies']

***

RunMBSmodelTests: using Exudyn version: 1.9.83.dev1

***

Do space variation with factor: 7

***

Creating simulation code for flyingMassPoint; spaceVar ID0 / 10; model ID0 / 35

***

 - executable=True, diff=0

***

Creating simulation code for flyingMassPoint; spaceVar ID1 / 10; model ID0 / 35

***

 - executable=True, diff=0

***

Creating simulation code for flyingMassPoint; spaceVar ID2 / 10; model ID0 / 35

***

 - executable=True, diff=0

***

Creating simulation code for flyingMassPoint; spaceVar ID3 / 10; model ID0 / 35

***

 - executable=True, diff=0

***

Creating simulation code for flyingMassPoint; spaceVar ID4 / 10; model ID0 / 35; time to go=1012.83s

***

 - executable=True, diff=0

***

Creating simulation code for flyingMassPoint; spaceVar ID5 / 10; model ID0 / 35; time to go=980.92s

***

 - executable=True, diff=0

***

Creating simulation code for flyingMassPoint; spaceVar ID6 / 10; model ID0 / 35; time to go=960.33s

***

 - executable=True, diff=0

***

Creating simulation code for flyingMassPoint; spaceVar ID7 / 10; model ID0 / 35; time to go=943.86s

***

 - executable=True, diff=0

***

Creating simulation code for flyingMassPoint; spaceVar ID8 / 10; model ID0 / 35; time to go=930.63s

***

 - executable=True, diff=0

***

Creating simulation code for flyingMassPoint; spaceVar ID9 / 10; model ID0 / 35; time to go=919.69s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; spaceVar ID0 / 10; model ID1 / 35; time to go=912.12s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; spaceVar ID1 / 10; model ID1 / 35; time to go=904.12s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; spaceVar ID2 / 10; model ID1 / 35; time to go=897.02s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; spaceVar ID3 / 10; model ID1 / 35; time to go=890.51s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; spaceVar ID4 / 10; model ID1 / 35; time to go=885.07s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; spaceVar ID5 / 10; model ID1 / 35; time to go=879.89s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; spaceVar ID6 / 10; model ID1 / 35; time to go=875.16s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; spaceVar ID7 / 10; model ID1 / 35; time to go=870.11s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; spaceVar ID8 / 10; model ID1 / 35; time to go=865.8s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; spaceVar ID9 / 10; model ID1 / 35; time to go=861.27s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillator; spaceVar ID0 / 10; model ID2 / 35; time to go=857.64s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillator; spaceVar ID1 / 10; model ID2 / 35; time to go=876.08s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillator; spaceVar ID2 / 10; model ID2 / 35; time to go=891.86s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillator; spaceVar ID3 / 10; model ID2 / 35; time to go=906.57s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillator; spaceVar ID4 / 10; model ID2 / 35; time to go=919.71s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillator; spaceVar ID5 / 10; model ID2 / 35; time to go=931.69s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillator; spaceVar ID6 / 10; model ID2 / 35; time to go=941.8s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillator; spaceVar ID7 / 10; model ID2 / 35; time to go=950.87s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillator; spaceVar ID8 / 10; model ID2 / 35; time to go=958.93s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillator; spaceVar ID9 / 10; model ID2 / 35; time to go=966.17s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorGravity; spaceVar ID0 / 10; model ID3 / 35; time to go=972.64s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorGravity; spaceVar ID1 / 10; model ID3 / 35; time to go=978.95s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorGravity; spaceVar ID2 / 10; model ID3 / 35; time to go=984.62s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorGravity; spaceVar ID3 / 10; model ID3 / 35; time to go=989.76s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorGravity; spaceVar ID4 / 10; model ID3 / 35; time to go=994.58s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorGravity; spaceVar ID5 / 10; model ID3 / 35; time to go=998.5s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorGravity; spaceVar ID6 / 10; model ID3 / 35; time to go=1001.9s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorGravity; spaceVar ID7 / 10; model ID3 / 35; time to go=1004.98s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorGravity; spaceVar ID8 / 10; model ID3 / 35; time to go=1007.66s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorGravity; spaceVar ID9 / 10; model ID3 / 35; time to go=1009.99s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankSimple; spaceVar ID0 / 10; model ID4 / 35; time to go=1011.95s

***

*****
ERROR:** 

```
Execute code error message: SolveDynamic terminated
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 55, in <module>
  File "C:\Users\c8501009\Anaconda\envs\venvP311gpt4all\Lib\site-packages\exudyn\solver.py", line 267, in SolveDynamic
    raise ValueError("SolveDynamic terminated")
ValueError: SolveDynamic terminated

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: dynamicSolver not successful!
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for sliderCrankSimple; spaceVar ID1 / 10; model ID4 / 35; time to go=1025.47s

***

*****
ERROR:** 

```
Execute code error message: SolveDynamic terminated
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 55, in <module>
  File "C:\Users\c8501009\Anaconda\envs\venvP311gpt4all\Lib\site-packages\exudyn\solver.py", line 267, in SolveDynamic
    raise ValueError("SolveDynamic terminated")
ValueError: SolveDynamic terminated

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: dynamicSolver not successful!
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for sliderCrankSimple; spaceVar ID2 / 10; model ID4 / 35; time to go=1037.47s

***

*****
ERROR:** 

```
Execute code error message: SolveDynamic terminated
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 55, in <module>
  File "C:\Users\c8501009\Anaconda\envs\venvP311gpt4all\Lib\site-packages\exudyn\solver.py", line 267, in SolveDynamic
    raise ValueError("SolveDynamic terminated")
ValueError: SolveDynamic terminated

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: dynamicSolver not successful!
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for sliderCrankSimple; spaceVar ID3 / 10; model ID4 / 35; time to go=1048.67s

***

*****
ERROR:** 

```
Execute code error message: SolveDynamic terminated
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 55, in <module>
  File "C:\Users\c8501009\Anaconda\envs\venvP311gpt4all\Lib\site-packages\exudyn\solver.py", line 267, in SolveDynamic
    raise ValueError("SolveDynamic terminated")
ValueError: SolveDynamic terminated

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: dynamicSolver not successful!
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for sliderCrankSimple; spaceVar ID4 / 10; model ID4 / 35; time to go=1059.07s

***

*****
ERROR:** 

```
Execute code error message: SolveDynamic terminated
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 55, in <module>
  File "C:\Users\c8501009\Anaconda\envs\venvP311gpt4all\Lib\site-packages\exudyn\solver.py", line 267, in SolveDynamic
    raise ValueError("SolveDynamic terminated")
ValueError: SolveDynamic terminated

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: dynamicSolver not successful!
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for sliderCrankSimple; spaceVar ID5 / 10; model ID4 / 35; time to go=1068.77s

***

 - executable=True, diff=100.811

***

Creating simulation code for sliderCrankSimple; spaceVar ID6 / 10; model ID4 / 35; time to go=1079.51s

***

*****
ERROR:** 

```
Execute code error message: SolveDynamic terminated
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 55, in <module>
  File "C:\Users\c8501009\Anaconda\envs\venvP311gpt4all\Lib\site-packages\exudyn\solver.py", line 267, in SolveDynamic
    raise ValueError("SolveDynamic terminated")
ValueError: SolveDynamic terminated

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: dynamicSolver not successful!
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for sliderCrankSimple; spaceVar ID7 / 10; model ID4 / 35; time to go=1087.88s

***

*****
ERROR:** 

```
Execute code error message: SolveDynamic terminated
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 55, in <module>
  File "C:\Users\c8501009\Anaconda\envs\venvP311gpt4all\Lib\site-packages\exudyn\solver.py", line 267, in SolveDynamic
    raise ValueError("SolveDynamic terminated")
ValueError: SolveDynamic terminated

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: dynamicSolver not successful!
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for sliderCrankSimple; spaceVar ID8 / 10; model ID4 / 35; time to go=1095.7s

***

*****
ERROR:** 

```
Execute code error message: SolveDynamic terminated
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 55, in <module>
  File "C:\Users\c8501009\Anaconda\envs\venvP311gpt4all\Lib\site-packages\exudyn\solver.py", line 267, in SolveDynamic
    raise ValueError("SolveDynamic terminated")
ValueError: SolveDynamic terminated

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: dynamicSolver not successful!
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for sliderCrankSimple; spaceVar ID9 / 10; model ID4 / 35; time to go=1102.95s

***

*****
ERROR:** 

```
Execute code error message: SolveDynamic terminated
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 55, in <module>
  File "C:\Users\c8501009\Anaconda\envs\venvP311gpt4all\Lib\site-packages\exudyn\solver.py", line 267, in SolveDynamic
    raise ValueError("SolveDynamic terminated")
ValueError: SolveDynamic terminated

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: dynamicSolver not successful!
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for singlePendulumElasticSpring; spaceVar ID0 / 10; model ID5 / 35; time to go=1109.74s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumElasticSpring; spaceVar ID1 / 10; model ID5 / 35; time to go=1114.68s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumElasticSpring; spaceVar ID2 / 10; model ID5 / 35; time to go=1111.92s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumElasticSpring; spaceVar ID3 / 10; model ID5 / 35; time to go=1115.75s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumElasticSpring; spaceVar ID4 / 10; model ID5 / 35; time to go=1119.17s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumElasticSpring; spaceVar ID5 / 10; model ID5 / 35; time to go=1122.2s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumElasticSpring; spaceVar ID6 / 10; model ID5 / 35; time to go=1120.12s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumElasticSpring; spaceVar ID7 / 10; model ID5 / 35; time to go=1122.7s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumElasticSpring; spaceVar ID8 / 10; model ID5 / 35; time to go=1125.08s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumElasticSpring; spaceVar ID9 / 10; model ID5 / 35; time to go=1128.94s

***

 - executable=True, diff=0

***

Creating simulation code for singleMassOscillatorUserFunction; spaceVar ID0 / 10; model ID6 / 35; time to go=1131.18s

***

 - executable=True, diff=581.962

***

Creating simulation code for singleMassOscillatorUserFunction; spaceVar ID1 / 10; model ID6 / 35; time to go=1138.53s

***

 - executable=True, diff=581.962

***

Creating simulation code for singleMassOscillatorUserFunction; spaceVar ID2 / 10; model ID6 / 35; time to go=1144.58s

***

 - executable=True, diff=581.962

***

Creating simulation code for singleMassOscillatorUserFunction; spaceVar ID3 / 10; model ID6 / 35; time to go=1151.05s

***

 - executable=True, diff=581.962

***

Creating simulation code for singleMassOscillatorUserFunction; spaceVar ID4 / 10; model ID6 / 35; time to go=1156.31s

***

 - executable=True, diff=581.962

***

Creating simulation code for singleMassOscillatorUserFunction; spaceVar ID5 / 10; model ID6 / 35; time to go=1161.19s

***

 - executable=True, diff=581.962

***

Creating simulation code for singleMassOscillatorUserFunction; spaceVar ID6 / 10; model ID6 / 35; time to go=1166.53s

***

 - executable=True, diff=581.962

***

Creating simulation code for singleMassOscillatorUserFunction; spaceVar ID7 / 10; model ID6 / 35; time to go=1170.77s

***

 - executable=True, diff=581.962

***

Creating simulation code for singleMassOscillatorUserFunction; spaceVar ID8 / 10; model ID6 / 35; time to go=1175.31s

***

 - executable=True, diff=581.962

***

Creating simulation code for singleMassOscillatorUserFunction; spaceVar ID9 / 10; model ID6 / 35; time to go=1179.05s

***

 - executable=True, diff=581.962

***

Creating simulation code for spinningDisc; spaceVar ID0 / 10; model ID7 / 35; time to go=1182.44s

***

 - executable=True, diff=0

***

Creating simulation code for spinningDisc; spaceVar ID1 / 10; model ID7 / 35; time to go=1180.84s

***

 - executable=True, diff=0

***

Creating simulation code for spinningDisc; spaceVar ID2 / 10; model ID7 / 35; time to go=1178.81s

***

 - executable=True, diff=0

***

Creating simulation code for spinningDisc; spaceVar ID3 / 10; model ID7 / 35; time to go=1177.05s

***

 - executable=True, diff=0

***

Creating simulation code for spinningDisc; spaceVar ID4 / 10; model ID7 / 35; time to go=1175.41s

***

 - executable=True, diff=0

***

Creating simulation code for spinningDisc; spaceVar ID5 / 10; model ID7 / 35; time to go=1173.6s

***

 - executable=True, diff=0

***

Creating simulation code for spinningDisc; spaceVar ID6 / 10; model ID7 / 35; time to go=1173.09s

***

 - executable=True, diff=0

***

Creating simulation code for spinningDisc; spaceVar ID7 / 10; model ID7 / 35; time to go=1170.43s

***

 - executable=True, diff=0

***

Creating simulation code for spinningDisc; spaceVar ID8 / 10; model ID7 / 35; time to go=1168.3s

***

 - executable=True, diff=0

***

Creating simulation code for spinningDisc; spaceVar ID9 / 10; model ID7 / 35; time to go=1165.7s

***

 - executable=True, diff=0

***

Creating simulation code for doubleMassOscillator; spaceVar ID0 / 10; model ID8 / 35; time to go=1162.98s

***

 - executable=True, diff=0

***

Creating simulation code for doubleMassOscillator; spaceVar ID1 / 10; model ID8 / 35; time to go=1164.22s

***

 - executable=True, diff=0

***

Creating simulation code for doubleMassOscillator; spaceVar ID2 / 10; model ID8 / 35; time to go=1165.21s

***

 - executable=True, diff=0

***

Creating simulation code for doubleMassOscillator; spaceVar ID3 / 10; model ID8 / 35; time to go=1166.07s

***

 - executable=True, diff=0

***

Creating simulation code for doubleMassOscillator; spaceVar ID4 / 10; model ID8 / 35; time to go=1166.87s

***

 - executable=True, diff=0

***

Creating simulation code for doubleMassOscillator; spaceVar ID5 / 10; model ID8 / 35; time to go=1167.45s

***

 - executable=True, diff=0

***

Creating simulation code for doubleMassOscillator; spaceVar ID6 / 10; model ID8 / 35; time to go=1167.9s

***

 - executable=True, diff=0

***

Creating simulation code for doubleMassOscillator; spaceVar ID7 / 10; model ID8 / 35; time to go=1168.15s

***

 - executable=True, diff=0

***

Creating simulation code for doubleMassOscillator; spaceVar ID8 / 10; model ID8 / 35; time to go=1168.26s

***

 - executable=True, diff=0

***

Creating simulation code for doubleMassOscillator; spaceVar ID9 / 10; model ID8 / 35; time to go=1168.31s

***

 - executable=True, diff=0

***

Creating simulation code for nMassOscillator; spaceVar ID0 / 10; model ID9 / 35; time to go=1168.22s

***

 - executable=True, diff=0

***

Creating simulation code for nMassOscillator; spaceVar ID1 / 10; model ID9 / 35; time to go=1169.91s

***

 - executable=True, diff=0

***

Creating simulation code for nMassOscillator; spaceVar ID2 / 10; model ID9 / 35; time to go=1171.32s

***

 - executable=True, diff=0

***

Creating simulation code for nMassOscillator; spaceVar ID3 / 10; model ID9 / 35; time to go=1172.55s

***

 - executable=True, diff=0

***

Creating simulation code for nMassOscillator; spaceVar ID4 / 10; model ID9 / 35; time to go=1173.69s

***

 - executable=True, diff=0

***

Creating simulation code for nMassOscillator; spaceVar ID5 / 10; model ID9 / 35; time to go=1174.67s

***

 - executable=True, diff=0

***

Creating simulation code for nMassOscillator; spaceVar ID6 / 10; model ID9 / 35; time to go=1175.49s

***

 - executable=True, diff=0

***

Creating simulation code for nMassOscillator; spaceVar ID7 / 10; model ID9 / 35; time to go=1176.13s

***

 - executable=True, diff=0

***

Creating simulation code for nMassOscillator; spaceVar ID8 / 10; model ID9 / 35; time to go=1176.65s

***

 - executable=True, diff=0

***

Creating simulation code for nMassOscillator; spaceVar ID9 / 10; model ID9 / 35; time to go=1177.05s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulum; spaceVar ID0 / 10; model ID10 / 35; time to go=1177.31s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulum; spaceVar ID1 / 10; model ID10 / 35; time to go=1170.98s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulum; spaceVar ID2 / 10; model ID10 / 35; time to go=1164.82s

***

 - executable=True, diff=14.1774

***

Creating simulation code for singlePendulum; spaceVar ID3 / 10; model ID10 / 35; time to go=1162.34s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulum; spaceVar ID4 / 10; model ID10 / 35; time to go=1156.16s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulum; spaceVar ID5 / 10; model ID10 / 35; time to go=1150.01s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulum; spaceVar ID6 / 10; model ID10 / 35; time to go=1143.87s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulum; spaceVar ID7 / 10; model ID10 / 35; time to go=1137.88s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulum; spaceVar ID8 / 10; model ID10 / 35; time to go=1131.88s

***

 - executable=True, diff=14.1774

***

Creating simulation code for singlePendulum; spaceVar ID9 / 10; model ID10 / 35; time to go=1129.18s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulum; spaceVar ID0 / 10; model ID11 / 35; time to go=1126.09s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulum; spaceVar ID1 / 10; model ID11 / 35; time to go=1125.49s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulum; spaceVar ID2 / 10; model ID11 / 35; time to go=1125.91s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulum; spaceVar ID3 / 10; model ID11 / 35; time to go=1122.67s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulum; spaceVar ID4 / 10; model ID11 / 35; time to go=1119.27s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulum; spaceVar ID5 / 10; model ID11 / 35; time to go=1118.4s

***

*****
ERROR:** 

```
Execute code error message: SolveDynamic terminated
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 55, in <module>
  File "C:\Users\c8501009\Anaconda\envs\venvP311gpt4all\Lib\site-packages\exudyn\solver.py", line 267, in SolveDynamic
    raise ValueError("SolveDynamic terminated")
ValueError: SolveDynamic terminated

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: dynamicSolver not successful!
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for doublePendulum; spaceVar ID6 / 10; model ID11 / 35; time to go=1114.96s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulum; spaceVar ID7 / 10; model ID11 / 35; time to go=1111.46s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulum; spaceVar ID8 / 10; model ID11 / 35; time to go=1110.32s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulum; spaceVar ID9 / 10; model ID11 / 35; time to go=1110.06s

***

 - executable=True, diff=0

***

Creating simulation code for nPendulum; spaceVar ID0 / 10; model ID12 / 35; time to go=1109.73s

***

 - executable=True, diff=0

***

Creating simulation code for nPendulum; spaceVar ID1 / 10; model ID12 / 35; time to go=1106.43s

***

 - executable=True, diff=0

***

Creating simulation code for nPendulum; spaceVar ID2 / 10; model ID12 / 35; time to go=1103.07s

***

 - executable=True, diff=0

***

Creating simulation code for nPendulum; spaceVar ID3 / 10; model ID12 / 35; time to go=1099.68s

***

 - executable=True, diff=0

***

Creating simulation code for nPendulum; spaceVar ID4 / 10; model ID12 / 35; time to go=1096.41s

***

 - executable=True, diff=0

***

Creating simulation code for nPendulum; spaceVar ID5 / 10; model ID12 / 35; time to go=1092.96s

***

 - executable=True, diff=0

***

Creating simulation code for nPendulum; spaceVar ID6 / 10; model ID12 / 35; time to go=1089.55s

***

 - executable=True, diff=0

***

Creating simulation code for nPendulum; spaceVar ID7 / 10; model ID12 / 35; time to go=1085.88s

***

 - executable=True, diff=0

***

Creating simulation code for nPendulum; spaceVar ID8 / 10; model ID12 / 35; time to go=1082.37s

***

 - executable=True, diff=0

***

Creating simulation code for nPendulum; spaceVar ID9 / 10; model ID12 / 35; time to go=1078.58s

***

 - executable=True, diff=0

***

Creating simulation code for fourBarMechanismPointMasses; spaceVar ID0 / 10; model ID13 / 35; time to go=1086.09s

***

 - executable=True, diff=5647.18

***

Creating simulation code for fourBarMechanismPointMasses; spaceVar ID1 / 10; model ID13 / 35; time to go=1083.66s

***

 - executable=True, diff=5647.18

***

Creating simulation code for fourBarMechanismPointMasses; spaceVar ID2 / 10; model ID13 / 35; time to go=1080.84s

***

 - executable=True, diff=5647.18

***

Creating simulation code for fourBarMechanismPointMasses; spaceVar ID3 / 10; model ID13 / 35; time to go=1077.92s

***

 - executable=True, diff=5647.18

***

Creating simulation code for fourBarMechanismPointMasses; spaceVar ID4 / 10; model ID13 / 35; time to go=1074.99s

***

 - executable=True, diff=5647.18

***

Creating simulation code for fourBarMechanismPointMasses; spaceVar ID5 / 10; model ID13 / 35; time to go=1072.0s

***

 - executable=True, diff=5647.18

***

Creating simulation code for fourBarMechanismPointMasses; spaceVar ID6 / 10; model ID13 / 35; time to go=1068.9s

***

 - executable=True, diff=5647.18

***

Creating simulation code for fourBarMechanismPointMasses; spaceVar ID7 / 10; model ID13 / 35; time to go=1065.73s

***

 - executable=True, diff=5647.18

***

Creating simulation code for fourBarMechanismPointMasses; spaceVar ID8 / 10; model ID13 / 35; time to go=1062.52s

***

 - executable=True, diff=5647.18

***

Creating simulation code for fourBarMechanismPointMasses; spaceVar ID9 / 10; model ID13 / 35; time to go=1059.32s

***

 - executable=True, diff=5647.18

***

Creating simulation code for springCoupledFlyingRigidBodies; spaceVar ID0 / 10; model ID14 / 35; time to go=1056.07s

***

 - executable=True, diff=0

***

Creating simulation code for springCoupledFlyingRigidBodies; spaceVar ID1 / 10; model ID14 / 35; time to go=1054.36s

***

 - executable=True, diff=0

***

Creating simulation code for springCoupledFlyingRigidBodies; spaceVar ID2 / 10; model ID14 / 35; time to go=1053.05s

***

 - executable=True, diff=0

***

Creating simulation code for springCoupledFlyingRigidBodies; spaceVar ID3 / 10; model ID14 / 35; time to go=1052.02s

***

 - executable=True, diff=0

***

Creating simulation code for springCoupledFlyingRigidBodies; spaceVar ID4 / 10; model ID14 / 35; time to go=1051.53s

***

 - executable=True, diff=0

***

Creating simulation code for springCoupledFlyingRigidBodies; spaceVar ID5 / 10; model ID14 / 35; time to go=1049.95s

***

 - executable=True, diff=0

***

Creating simulation code for springCoupledFlyingRigidBodies; spaceVar ID6 / 10; model ID14 / 35; time to go=1048.11s

***

 - executable=True, diff=0

***

Creating simulation code for springCoupledFlyingRigidBodies; spaceVar ID7 / 10; model ID14 / 35; time to go=1045.84s

***

 - executable=True, diff=0

***

Creating simulation code for springCoupledFlyingRigidBodies; spaceVar ID8 / 10; model ID14 / 35; time to go=1043.77s

***

 - executable=True, diff=0

***

Creating simulation code for springCoupledFlyingRigidBodies; spaceVar ID9 / 10; model ID14 / 35; time to go=1041.36s

***

 - executable=True, diff=0

***

Creating simulation code for torsionalOscillator; spaceVar ID0 / 10; model ID15 / 35; time to go=1038.92s

***

 - executable=True, diff=0

***

Creating simulation code for torsionalOscillator; spaceVar ID1 / 10; model ID15 / 35; time to go=1034.92s

***

 - executable=True, diff=1.33885

***

Creating simulation code for torsionalOscillator; spaceVar ID2 / 10; model ID15 / 35; time to go=1031.12s

***

 - executable=True, diff=0

***

Creating simulation code for torsionalOscillator; spaceVar ID3 / 10; model ID15 / 35; time to go=1027.03s

***

 - executable=True, diff=0

***

Creating simulation code for torsionalOscillator; spaceVar ID4 / 10; model ID15 / 35; time to go=1022.92s

***

 - executable=True, diff=0

***

Creating simulation code for torsionalOscillator; spaceVar ID5 / 10; model ID15 / 35; time to go=1018.75s

***

 - executable=True, diff=0

***

Creating simulation code for torsionalOscillator; spaceVar ID6 / 10; model ID15 / 35; time to go=1014.6s

***

 - executable=True, diff=0

***

Creating simulation code for torsionalOscillator; spaceVar ID7 / 10; model ID15 / 35; time to go=1010.43s

***

 - executable=True, diff=0

***

Creating simulation code for torsionalOscillator; spaceVar ID8 / 10; model ID15 / 35; time to go=1006.25s

***

 - executable=True, diff=0

***

Creating simulation code for torsionalOscillator; spaceVar ID9 / 10; model ID15 / 35; time to go=1002.06s

***

 - executable=True, diff=0

***

Creating simulation code for invertedSinglePendulum; spaceVar ID0 / 10; model ID16 / 35; time to go=997.99s

***

 - executable=True, diff=0

***

Creating simulation code for invertedSinglePendulum; spaceVar ID1 / 10; model ID16 / 35; time to go=993.73s

***

 - executable=True, diff=0

***

Creating simulation code for invertedSinglePendulum; spaceVar ID2 / 10; model ID16 / 35; time to go=991.16s

***

 - executable=True, diff=0

***

Creating simulation code for invertedSinglePendulum; spaceVar ID3 / 10; model ID16 / 35; time to go=986.85s

***

 - executable=True, diff=0

***

Creating simulation code for invertedSinglePendulum; spaceVar ID4 / 10; model ID16 / 35; time to go=982.53s

***

 - executable=True, diff=0

***

Creating simulation code for invertedSinglePendulum; spaceVar ID5 / 10; model ID16 / 35; time to go=978.17s

***

 - executable=True, diff=0

***

Creating simulation code for invertedSinglePendulum; spaceVar ID6 / 10; model ID16 / 35; time to go=973.81s

***

 - executable=True, diff=0

***

Creating simulation code for invertedSinglePendulum; spaceVar ID7 / 10; model ID16 / 35; time to go=969.39s

***

 - executable=True, diff=0

***

Creating simulation code for invertedSinglePendulum; spaceVar ID8 / 10; model ID16 / 35; time to go=964.99s

***

 - executable=True, diff=2.29701e-07

***

Creating simulation code for invertedSinglePendulum; spaceVar ID9 / 10; model ID16 / 35; time to go=960.75s

***

 - executable=True, diff=0

***

Creating simulation code for discRollingOnGround; spaceVar ID0 / 10; model ID17 / 35; time to go=956.26s

***

 - executable=True, diff=2.04824e-07

***

Creating simulation code for discRollingOnGround; spaceVar ID1 / 10; model ID17 / 35; time to go=950.8s

***

 - executable=True, diff=2.04824e-07

***

Creating simulation code for discRollingOnGround; spaceVar ID2 / 10; model ID17 / 35; time to go=945.32s

***

 - executable=True, diff=2.04824e-07

***

Creating simulation code for discRollingOnGround; spaceVar ID3 / 10; model ID17 / 35; time to go=939.84s

***

 - executable=True, diff=2.04824e-07

***

Creating simulation code for discRollingOnGround; spaceVar ID4 / 10; model ID17 / 35; time to go=934.38s

***

 - executable=True, diff=2.04824e-07

***

Creating simulation code for discRollingOnGround; spaceVar ID5 / 10; model ID17 / 35; time to go=928.9s

***

 - executable=True, diff=2.04824e-07

***

Creating simulation code for discRollingOnGround; spaceVar ID6 / 10; model ID17 / 35; time to go=923.43s

***

 - executable=True, diff=2.04824e-07

***

Creating simulation code for discRollingOnGround; spaceVar ID7 / 10; model ID17 / 35; time to go=917.96s

***

 - executable=True, diff=2.04824e-07

***

Creating simulation code for discRollingOnGround; spaceVar ID8 / 10; model ID17 / 35; time to go=912.5s

***

 - executable=True, diff=2.04824e-07

***

Creating simulation code for discRollingOnGround; spaceVar ID9 / 10; model ID17 / 35; time to go=907.03s

***

 - executable=True, diff=2.04824e-07

***

Creating simulation code for doublePendulumElasticSpring; spaceVar ID0 / 10; model ID18 / 35; time to go=901.6s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumElasticSpring; spaceVar ID1 / 10; model ID18 / 35; time to go=897.29s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumElasticSpring; spaceVar ID2 / 10; model ID18 / 35; time to go=892.99s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumElasticSpring; spaceVar ID3 / 10; model ID18 / 35; time to go=888.66s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumElasticSpring; spaceVar ID4 / 10; model ID18 / 35; time to go=884.29s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumElasticSpring; spaceVar ID5 / 10; model ID18 / 35; time to go=879.96s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumElasticSpring; spaceVar ID6 / 10; model ID18 / 35; time to go=875.58s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumElasticSpring; spaceVar ID7 / 10; model ID18 / 35; time to go=871.15s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumElasticSpring; spaceVar ID8 / 10; model ID18 / 35; time to go=866.7s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumElasticSpring; spaceVar ID9 / 10; model ID18 / 35; time to go=862.6s

***

 - executable=True, diff=0

***

Creating simulation code for nPendulumElasticSpring; spaceVar ID0 / 10; model ID19 / 35; time to go=858.15s

***

 - executable=True, diff=49.4337

***

Creating simulation code for nPendulumElasticSpring; spaceVar ID1 / 10; model ID19 / 35; time to go=853.68s

***

 - executable=True, diff=49.4337

***

Creating simulation code for nPendulumElasticSpring; spaceVar ID2 / 10; model ID19 / 35; time to go=849.21s

***

 - executable=True, diff=49.4337

***

Creating simulation code for nPendulumElasticSpring; spaceVar ID3 / 10; model ID19 / 35; time to go=844.69s

***

 - executable=True, diff=49.4337

***

Creating simulation code for nPendulumElasticSpring; spaceVar ID4 / 10; model ID19 / 35; time to go=840.07s

***

 - executable=True, diff=49.4337

***

Creating simulation code for nPendulumElasticSpring; spaceVar ID5 / 10; model ID19 / 35; time to go=835.55s

***

 - executable=True, diff=49.4337

***

Creating simulation code for nPendulumElasticSpring; spaceVar ID6 / 10; model ID19 / 35; time to go=830.99s

***

 - executable=True, diff=49.4337

***

Creating simulation code for nPendulumElasticSpring; spaceVar ID7 / 10; model ID19 / 35; time to go=826.31s

***

 - executable=True, diff=49.4337

***

Creating simulation code for nPendulumElasticSpring; spaceVar ID8 / 10; model ID19 / 35; time to go=821.61s

***

 - executable=True, diff=49.4337

***

Creating simulation code for nPendulumElasticSpring; spaceVar ID9 / 10; model ID19 / 35; time to go=816.99s

***

 - executable=True, diff=49.4337

***

Creating simulation code for elasticChain; spaceVar ID0 / 10; model ID20 / 35; time to go=812.24s

***

 - executable=True, diff=167.955

***

Creating simulation code for elasticChain; spaceVar ID1 / 10; model ID20 / 35; time to go=807.38s

***

*****
ERROR:** 

```
Execute code error message: SolveDynamic terminated
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 62, in <module>
  File "C:\Users\c8501009\Anaconda\envs\venvP311gpt4all\Lib\site-packages\exudyn\solver.py", line 267, in SolveDynamic
    raise ValueError("SolveDynamic terminated")
ValueError: SolveDynamic terminated

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: dynamicSolver not successful!
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for elasticChain; spaceVar ID2 / 10; model ID20 / 35; time to go=803.09s

***

 - executable=True, diff=0

***

Creating simulation code for elasticChain; spaceVar ID3 / 10; model ID20 / 35; time to go=798.72s

***

*****
ERROR:** 

```
Execute code error message: 'exudyn.exudynCPP.MainSystem' object has no attribute 'GetBody'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 42, in <module>
AttributeError: 'exudyn.exudynCPP.MainSystem' object has no attribute 'GetBody'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for elasticChain; spaceVar ID4 / 10; model ID20 / 35; time to go=795.35s

***

*****
ERROR:** 

```
Execute code error message: SolveDynamic terminated
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 62, in <module>
  File "C:\Users\c8501009\Anaconda\envs\venvP311gpt4all\Lib\site-packages\exudyn\solver.py", line 267, in SolveDynamic
    raise ValueError("SolveDynamic terminated")
ValueError: SolveDynamic terminated

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: dynamicSolver not successful!
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for elasticChain; spaceVar ID5 / 10; model ID20 / 35; time to go=790.98s

***

 - executable=True, diff=167.955

***

Creating simulation code for elasticChain; spaceVar ID6 / 10; model ID20 / 35; time to go=786.01s

***

 - executable=True, diff=167.955

***

Creating simulation code for elasticChain; spaceVar ID7 / 10; model ID20 / 35; time to go=781.01s

***

*****
ERROR:** 

```
Execute code error message: 'exudyn.exudynCPP.MainSystem' object has no attribute 'GetBody'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 35, in <module>
AttributeError: 'exudyn.exudynCPP.MainSystem' object has no attribute 'GetBody'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for elasticChain; spaceVar ID8 / 10; model ID20 / 35; time to go=776.75s

***

*****
ERROR:** 

```
Execute code error message: 'exudyn.exudynCPP.MainSystem' object has no attribute 'GetBody'
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 35, in <module>
AttributeError: 'exudyn.exudynCPP.MainSystem' object has no attribute 'GetBody'

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: mbs.sys does not contain dynamicSolver/staticSolver (probably did not solve)
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for elasticChain; spaceVar ID9 / 10; model ID20 / 35; time to go=772.48s

***

*****
ERROR:** 

```
Execute code error message: SolveDynamic terminated
Traceback (most recent call last):
  File "D:\DATA\Paper\2024_LLMtrainer\llmpaper2024_git\08_ExuAI\exuai\agent.py", line 362, in ExecuteCodeAndGetLocalVariables
    exec(code, globals(), localEnv)
  File "<string>", line 62, in <module>
  File "C:\Users\c8501009\Anaconda\envs\venvP311gpt4all\Lib\site-packages\exudyn\solver.py", line 267, in SolveDynamic
    raise ValueError("SolveDynamic terminated")
ValueError: SolveDynamic terminated

***
```


***

*****
ERROR:** 

```
Evaluate executables, LLM generated code: dynamicSolver not successful!
***
```


***

 - executable=False, diff=-3.0

***

Creating simulation code for singlePendulumRigidBody; spaceVar ID0 / 10; model ID21 / 35; time to go=768.03s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumRigidBody; spaceVar ID1 / 10; model ID21 / 35; time to go=762.01s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumRigidBody; spaceVar ID2 / 10; model ID21 / 35; time to go=756.0s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumRigidBody; spaceVar ID3 / 10; model ID21 / 35; time to go=749.99s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumRigidBody; spaceVar ID4 / 10; model ID21 / 35; time to go=743.75s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumRigidBody; spaceVar ID5 / 10; model ID21 / 35; time to go=737.78s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumRigidBody; spaceVar ID6 / 10; model ID21 / 35; time to go=731.84s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumRigidBody; spaceVar ID7 / 10; model ID21 / 35; time to go=725.88s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumRigidBody; spaceVar ID8 / 10; model ID21 / 35; time to go=719.7s

***

 - executable=True, diff=0

***

Creating simulation code for singlePendulumRigidBody; spaceVar ID9 / 10; model ID21 / 35; time to go=713.76s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringRigid; spaceVar ID0 / 10; model ID22 / 35; time to go=707.87s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringRigid; spaceVar ID1 / 10; model ID22 / 35; time to go=701.3s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringRigid; spaceVar ID2 / 10; model ID22 / 35; time to go=694.68s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringRigid; spaceVar ID3 / 10; model ID22 / 35; time to go=688.08s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringRigid; spaceVar ID4 / 10; model ID22 / 35; time to go=681.51s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringRigid; spaceVar ID5 / 10; model ID22 / 35; time to go=675.04s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringRigid; spaceVar ID6 / 10; model ID22 / 35; time to go=668.61s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringRigid; spaceVar ID7 / 10; model ID22 / 35; time to go=662.09s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringRigid; spaceVar ID8 / 10; model ID22 / 35; time to go=655.6s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringRigid; spaceVar ID9 / 10; model ID22 / 35; time to go=649.25s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringElastic; spaceVar ID0 / 10; model ID23 / 35; time to go=642.81s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringElastic; spaceVar ID1 / 10; model ID23 / 35; time to go=636.56s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringElastic; spaceVar ID2 / 10; model ID23 / 35; time to go=630.32s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringElastic; spaceVar ID3 / 10; model ID23 / 35; time to go=624.11s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringElastic; spaceVar ID4 / 10; model ID23 / 35; time to go=617.92s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringElastic; spaceVar ID5 / 10; model ID23 / 35; time to go=611.75s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringElastic; spaceVar ID6 / 10; model ID23 / 35; time to go=605.61s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringElastic; spaceVar ID7 / 10; model ID23 / 35; time to go=599.48s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringElastic; spaceVar ID8 / 10; model ID23 / 35; time to go=593.38s

***

 - executable=True, diff=0

***

Creating simulation code for massPointOnStringElastic; spaceVar ID9 / 10; model ID23 / 35; time to go=587.3s

***

 - executable=True, diff=0

***

Creating simulation code for linkOnTwoPrismaticJoints; spaceVar ID0 / 10; model ID24 / 35; time to go=581.23s

***

 - executable=True, diff=1.60894e-06

***

Creating simulation code for linkOnTwoPrismaticJoints; spaceVar ID1 / 10; model ID24 / 35; time to go=576.56s

***

 - executable=True, diff=0

***

Creating simulation code for linkOnTwoPrismaticJoints; spaceVar ID2 / 10; model ID24 / 35; time to go=571.88s

***

 - executable=True, diff=0

***

Creating simulation code for linkOnTwoPrismaticJoints; spaceVar ID3 / 10; model ID24 / 35; time to go=567.19s

***

 - executable=True, diff=0

***

Creating simulation code for linkOnTwoPrismaticJoints; spaceVar ID4 / 10; model ID24 / 35; time to go=562.48s

***

 - executable=True, diff=1.66098e-07

***

Creating simulation code for linkOnTwoPrismaticJoints; spaceVar ID5 / 10; model ID24 / 35; time to go=557.75s

***

 - executable=True, diff=1.66098e-07

***

Creating simulation code for linkOnTwoPrismaticJoints; spaceVar ID6 / 10; model ID24 / 35; time to go=553.02s

***

 - executable=True, diff=0

***

Creating simulation code for linkOnTwoPrismaticJoints; spaceVar ID7 / 10; model ID24 / 35; time to go=548.27s

***

 - executable=True, diff=0

***

Creating simulation code for linkOnTwoPrismaticJoints; spaceVar ID8 / 10; model ID24 / 35; time to go=543.52s

***

 - executable=True, diff=0

***

Creating simulation code for linkOnTwoPrismaticJoints; spaceVar ID9 / 10; model ID24 / 35; time to go=538.76s

***

 - executable=True, diff=0

***

Creating simulation code for flyingRigidBody; spaceVar ID0 / 10; model ID25 / 35; time to go=533.97s

***

 - executable=True, diff=2.48602e-07

***

Creating simulation code for flyingRigidBody; spaceVar ID1 / 10; model ID25 / 35; time to go=528.09s

***

 - executable=True, diff=2.48602e-07

***

Creating simulation code for flyingRigidBody; spaceVar ID2 / 10; model ID25 / 35; time to go=522.17s

***

 - executable=True, diff=2.48602e-07

***

Creating simulation code for flyingRigidBody; spaceVar ID3 / 10; model ID25 / 35; time to go=516.27s

***

 - executable=True, diff=2.48602e-07

***

Creating simulation code for flyingRigidBody; spaceVar ID4 / 10; model ID25 / 35; time to go=510.71s

***

 - executable=True, diff=2.48602e-07

***

Creating simulation code for flyingRigidBody; spaceVar ID5 / 10; model ID25 / 35; time to go=504.83s

***

 - executable=True, diff=0

***

Creating simulation code for flyingRigidBody; spaceVar ID6 / 10; model ID25 / 35; time to go=499.04s

***

 - executable=True, diff=0

***

Creating simulation code for flyingRigidBody; spaceVar ID7 / 10; model ID25 / 35; time to go=493.42s

***

 - executable=True, diff=2.48602e-07

***

Creating simulation code for flyingRigidBody; spaceVar ID8 / 10; model ID25 / 35; time to go=487.64s

***

 - executable=True, diff=0

***

Creating simulation code for flyingRigidBody; spaceVar ID9 / 10; model ID25 / 35; time to go=481.88s

***

 - executable=True, diff=2.48602e-07

***

Creating simulation code for suspendedRigidBody; spaceVar ID0 / 10; model ID26 / 35; time to go=476.12s

***

 - executable=True, diff=204.368

***

Creating simulation code for suspendedRigidBody; spaceVar ID1 / 10; model ID26 / 35; time to go=471.52s

***

 - executable=True, diff=17.9999

***

Creating simulation code for suspendedRigidBody; spaceVar ID2 / 10; model ID26 / 35; time to go=466.99s

***

 - executable=True, diff=17.1698

***

Creating simulation code for suspendedRigidBody; spaceVar ID3 / 10; model ID26 / 35; time to go=462.75s

***

 - executable=True, diff=139.432

***

Creating simulation code for suspendedRigidBody; spaceVar ID4 / 10; model ID26 / 35; time to go=457.78s

***

 - executable=True, diff=0

***

Creating simulation code for suspendedRigidBody; spaceVar ID5 / 10; model ID26 / 35; time to go=453.4s

***

 - executable=True, diff=17.1698

***

Creating simulation code for suspendedRigidBody; spaceVar ID6 / 10; model ID26 / 35; time to go=449.08s

***

 - executable=True, diff=0

***

Creating simulation code for suspendedRigidBody; spaceVar ID7 / 10; model ID26 / 35; time to go=444.67s

***

 - executable=True, diff=0

***

Creating simulation code for suspendedRigidBody; spaceVar ID8 / 10; model ID26 / 35; time to go=439.75s

***

 - executable=True, diff=17.1698

***

Creating simulation code for suspendedRigidBody; spaceVar ID9 / 10; model ID26 / 35; time to go=435.3s

***

 - executable=True, diff=17.1698

***

Creating simulation code for gyroscopeOnSphericalJoint; spaceVar ID0 / 10; model ID27 / 35; time to go=430.85s

***

 - executable=True, diff=0

***

Creating simulation code for gyroscopeOnSphericalJoint; spaceVar ID1 / 10; model ID27 / 35; time to go=425.59s

***

 - executable=True, diff=0

***

Creating simulation code for gyroscopeOnSphericalJoint; spaceVar ID2 / 10; model ID27 / 35; time to go=420.31s

***

 - executable=True, diff=0

***

Creating simulation code for gyroscopeOnSphericalJoint; spaceVar ID3 / 10; model ID27 / 35; time to go=415.05s

***

 - executable=True, diff=0

***

Creating simulation code for gyroscopeOnSphericalJoint; spaceVar ID4 / 10; model ID27 / 35; time to go=409.77s

***

 - executable=True, diff=0

***

Creating simulation code for gyroscopeOnSphericalJoint; spaceVar ID5 / 10; model ID27 / 35; time to go=404.49s

***

 - executable=True, diff=0

***

Creating simulation code for gyroscopeOnSphericalJoint; spaceVar ID6 / 10; model ID27 / 35; time to go=399.2s

***

 - executable=True, diff=0

***

Creating simulation code for gyroscopeOnSphericalJoint; spaceVar ID7 / 10; model ID27 / 35; time to go=393.92s

***

 - executable=True, diff=0

***

Creating simulation code for gyroscopeOnSphericalJoint; spaceVar ID8 / 10; model ID27 / 35; time to go=388.62s

***

 - executable=True, diff=0

***

Creating simulation code for gyroscopeOnSphericalJoint; spaceVar ID9 / 10; model ID27 / 35; time to go=383.33s

***

 - executable=True, diff=0

***

Creating simulation code for prismaticJointSystem; spaceVar ID0 / 10; model ID28 / 35; time to go=378.04s

***

 - executable=True, diff=0

***

Creating simulation code for prismaticJointSystem; spaceVar ID1 / 10; model ID28 / 35; time to go=372.62s

***

 - executable=True, diff=0

***

Creating simulation code for prismaticJointSystem; spaceVar ID2 / 10; model ID28 / 35; time to go=367.21s

***

 - executable=True, diff=0

***

Creating simulation code for prismaticJointSystem; spaceVar ID3 / 10; model ID28 / 35; time to go=361.8s

***

 - executable=True, diff=0

***

Creating simulation code for prismaticJointSystem; spaceVar ID4 / 10; model ID28 / 35; time to go=356.39s

***

 - executable=True, diff=0

***

Creating simulation code for prismaticJointSystem; spaceVar ID5 / 10; model ID28 / 35; time to go=350.97s

***

 - executable=True, diff=0

***

Creating simulation code for prismaticJointSystem; spaceVar ID6 / 10; model ID28 / 35; time to go=345.55s

***

 - executable=True, diff=0

***

Creating simulation code for prismaticJointSystem; spaceVar ID7 / 10; model ID28 / 35; time to go=340.13s

***

 - executable=True, diff=0

***

Creating simulation code for prismaticJointSystem; spaceVar ID8 / 10; model ID28 / 35; time to go=334.71s

***

 - executable=True, diff=0

***

Creating simulation code for prismaticJointSystem; spaceVar ID9 / 10; model ID28 / 35; time to go=329.29s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithSprings; spaceVar ID0 / 10; model ID29 / 35; time to go=323.88s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithSprings; spaceVar ID1 / 10; model ID29 / 35; time to go=318.29s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithSprings; spaceVar ID2 / 10; model ID29 / 35; time to go=312.73s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithSprings; spaceVar ID3 / 10; model ID29 / 35; time to go=307.08s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithSprings; spaceVar ID4 / 10; model ID29 / 35; time to go=301.52s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithSprings; spaceVar ID5 / 10; model ID29 / 35; time to go=295.96s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithSprings; spaceVar ID6 / 10; model ID29 / 35; time to go=290.41s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithSprings; spaceVar ID7 / 10; model ID29 / 35; time to go=284.8s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithSprings; spaceVar ID8 / 10; model ID29 / 35; time to go=279.19s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithSprings; spaceVar ID9 / 10; model ID29 / 35; time to go=273.66s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithDistances; spaceVar ID0 / 10; model ID30 / 35; time to go=268.15s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithDistances; spaceVar ID1 / 10; model ID30 / 35; time to go=262.6s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithDistances; spaceVar ID2 / 10; model ID30 / 35; time to go=257.06s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithDistances; spaceVar ID3 / 10; model ID30 / 35; time to go=251.47s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithDistances; spaceVar ID4 / 10; model ID30 / 35; time to go=245.94s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithDistances; spaceVar ID5 / 10; model ID30 / 35; time to go=240.42s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithDistances; spaceVar ID6 / 10; model ID30 / 35; time to go=234.92s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithDistances; spaceVar ID7 / 10; model ID30 / 35; time to go=229.43s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithDistances; spaceVar ID8 / 10; model ID30 / 35; time to go=223.94s

***

 - executable=True, diff=0

***

Creating simulation code for twoMassPointsWithDistances; spaceVar ID9 / 10; model ID30 / 35; time to go=218.45s

***

 - executable=True, diff=0

***

Creating simulation code for rigidRotorSimplySupported; spaceVar ID0 / 10; model ID31 / 35; time to go=212.98s

***

 - executable=True, diff=121.93

***

Creating simulation code for rigidRotorSimplySupported; spaceVar ID1 / 10; model ID31 / 35; time to go=207.61s

***

 - executable=True, diff=0

***

Creating simulation code for rigidRotorSimplySupported; spaceVar ID2 / 10; model ID31 / 35; time to go=202.37s

***

 - executable=True, diff=121.93

***

Creating simulation code for rigidRotorSimplySupported; spaceVar ID3 / 10; model ID31 / 35; time to go=197.0s

***

 - executable=True, diff=121.93

***

Creating simulation code for rigidRotorSimplySupported; spaceVar ID4 / 10; model ID31 / 35; time to go=191.67s

***

 - executable=True, diff=0

***

Creating simulation code for rigidRotorSimplySupported; spaceVar ID5 / 10; model ID31 / 35; time to go=186.42s

***

 - executable=True, diff=121.93

***

Creating simulation code for rigidRotorSimplySupported; spaceVar ID6 / 10; model ID31 / 35; time to go=181.05s

***

 - executable=True, diff=121.93

***

Creating simulation code for rigidRotorSimplySupported; spaceVar ID7 / 10; model ID31 / 35; time to go=175.69s

***

 - executable=True, diff=121.93

***

Creating simulation code for rigidRotorSimplySupported; spaceVar ID8 / 10; model ID31 / 35; time to go=170.36s

***

 - executable=True, diff=121.93

***

Creating simulation code for rigidRotorSimplySupported; spaceVar ID9 / 10; model ID31 / 35; time to go=165.03s

***

 - executable=True, diff=121.93

***

Creating simulation code for rigidRotorUnbalanced; spaceVar ID0 / 10; model ID32 / 35; time to go=159.7s

***

 - executable=True, diff=24661.9

***

Creating simulation code for rigidRotorUnbalanced; spaceVar ID1 / 10; model ID32 / 35; time to go=154.57s

***

 - executable=True, diff=24661.9

***

Creating simulation code for rigidRotorUnbalanced; spaceVar ID2 / 10; model ID32 / 35; time to go=149.44s

***

 - executable=True, diff=24661.9

***

Creating simulation code for rigidRotorUnbalanced; spaceVar ID3 / 10; model ID32 / 35; time to go=144.29s

***

 - executable=True, diff=24661.9

***

Creating simulation code for rigidRotorUnbalanced; spaceVar ID4 / 10; model ID32 / 35; time to go=139.11s

***

 - executable=True, diff=24661.9

***

Creating simulation code for rigidRotorUnbalanced; spaceVar ID5 / 10; model ID32 / 35; time to go=133.93s

***

 - executable=True, diff=24663.0

***

Creating simulation code for rigidRotorUnbalanced; spaceVar ID6 / 10; model ID32 / 35; time to go=128.65s

***

 - executable=True, diff=24663.0

***

Creating simulation code for rigidRotorUnbalanced; spaceVar ID7 / 10; model ID32 / 35; time to go=123.37s

***

 - executable=True, diff=24663.0

***

Creating simulation code for rigidRotorUnbalanced; spaceVar ID8 / 10; model ID32 / 35; time to go=118.08s

***

 - executable=True, diff=24661.9

***

Creating simulation code for rigidRotorUnbalanced; spaceVar ID9 / 10; model ID32 / 35; time to go=112.85s

***

 - executable=True, diff=24663.0

***

Creating simulation code for doublePendulumRigidBodies; spaceVar ID0 / 10; model ID33 / 35; time to go=107.54s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumRigidBodies; spaceVar ID1 / 10; model ID33 / 35; time to go=102.35s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumRigidBodies; spaceVar ID2 / 10; model ID33 / 35; time to go=97.09s

***

 - executable=True, diff=5.13563e-06

***

Creating simulation code for doublePendulumRigidBodies; spaceVar ID3 / 10; model ID33 / 35; time to go=91.79s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumRigidBodies; spaceVar ID4 / 10; model ID33 / 35; time to go=86.51s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumRigidBodies; spaceVar ID5 / 10; model ID33 / 35; time to go=81.2s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumRigidBodies; spaceVar ID6 / 10; model ID33 / 35; time to go=75.88s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumRigidBodies; spaceVar ID7 / 10; model ID33 / 35; time to go=70.54s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumRigidBodies; spaceVar ID8 / 10; model ID33 / 35; time to go=65.2s

***

 - executable=True, diff=0

***

Creating simulation code for doublePendulumRigidBodies; spaceVar ID9 / 10; model ID33 / 35; time to go=59.83s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankRigidBodies; spaceVar ID0 / 10; model ID34 / 35; time to go=54.46s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankRigidBodies; spaceVar ID1 / 10; model ID34 / 35; time to go=49.19s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankRigidBodies; spaceVar ID2 / 10; model ID34 / 35; time to go=43.88s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankRigidBodies; spaceVar ID3 / 10; model ID34 / 35; time to go=38.56s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankRigidBodies; spaceVar ID4 / 10; model ID34 / 35; time to go=33.18s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankRigidBodies; spaceVar ID5 / 10; model ID34 / 35; time to go=27.75s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankRigidBodies; spaceVar ID6 / 10; model ID34 / 35; time to go=22.27s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankRigidBodies; spaceVar ID7 / 10; model ID34 / 35; time to go=16.76s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankRigidBodies; spaceVar ID8 / 10; model ID34 / 35; time to go=11.21s

***

 - executable=True, diff=0

***

Creating simulation code for sliderCrankRigidBodies; spaceVar ID9 / 10; model ID34 / 35; time to go=5.62s

***

 - executable=True, diff=0
**FINAL TEST RESULTS** 
 - flyingMassPoint0: 

   + executable: True

   + diff: 0.0

 - flyingMassPoint1: 

   + executable: True

   + diff: 0.0

 - flyingMassPoint2: 

   + executable: True

   + diff: 0.0

 - flyingMassPoint3: 

   + executable: True

   + diff: 0.0

 - flyingMassPoint4: 

   + executable: True

   + diff: 0.0

 - flyingMassPoint5: 

   + executable: True

   + diff: 0.0

 - flyingMassPoint6: 

   + executable: True

   + diff: 0.0

 - flyingMassPoint7: 

   + executable: True

   + diff: 0.0

 - flyingMassPoint8: 

   + executable: True

   + diff: 0.0

 - flyingMassPoint9: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint0: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint1: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint2: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint3: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint4: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint5: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint6: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint7: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint8: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint9: 

   + executable: True

   + diff: 0.0

 - singleMassOscillator0: 

   + executable: True

   + diff: 0.0

 - singleMassOscillator1: 

   + executable: True

   + diff: 0.0

 - singleMassOscillator2: 

   + executable: True

   + diff: 0.0

 - singleMassOscillator3: 

   + executable: True

   + diff: 0.0

 - singleMassOscillator4: 

   + executable: True

   + diff: 0.0

 - singleMassOscillator5: 

   + executable: True

   + diff: 0.0

 - singleMassOscillator6: 

   + executable: True

   + diff: 0.0

 - singleMassOscillator7: 

   + executable: True

   + diff: 0.0

 - singleMassOscillator8: 

   + executable: True

   + diff: 0.0

 - singleMassOscillator9: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorGravity0: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorGravity1: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorGravity2: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorGravity3: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorGravity4: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorGravity5: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorGravity6: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorGravity7: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorGravity8: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorGravity9: 

   + executable: True

   + diff: 0.0

 - sliderCrankSimple0: 

   + executable: False

   + diff: -3

 - sliderCrankSimple1: 

   + executable: False

   + diff: -3

 - sliderCrankSimple2: 

   + executable: False

   + diff: -3

 - sliderCrankSimple3: 

   + executable: False

   + diff: -3

 - sliderCrankSimple4: 

   + executable: False

   + diff: -3

 - sliderCrankSimple5: 

   + executable: True

   + diff: 100.81133460142797

 - sliderCrankSimple6: 

   + executable: False

   + diff: -3

 - sliderCrankSimple7: 

   + executable: False

   + diff: -3

 - sliderCrankSimple8: 

   + executable: False

   + diff: -3

 - sliderCrankSimple9: 

   + executable: False

   + diff: -3

 - singlePendulumElasticSpring0: 

   + executable: True

   + diff: 0.0

 - singlePendulumElasticSpring1: 

   + executable: True

   + diff: 0.0

 - singlePendulumElasticSpring2: 

   + executable: True

   + diff: 0.0

 - singlePendulumElasticSpring3: 

   + executable: True

   + diff: 0.0

 - singlePendulumElasticSpring4: 

   + executable: True

   + diff: 0.0

 - singlePendulumElasticSpring5: 

   + executable: True

   + diff: 0.0

 - singlePendulumElasticSpring6: 

   + executable: True

   + diff: 0.0

 - singlePendulumElasticSpring7: 

   + executable: True

   + diff: 0.0

 - singlePendulumElasticSpring8: 

   + executable: True

   + diff: 0.0

 - singlePendulumElasticSpring9: 

   + executable: True

   + diff: 0.0

 - singleMassOscillatorUserFunction0: 

   + executable: True

   + diff: 581.9617885089519

 - singleMassOscillatorUserFunction1: 

   + executable: True

   + diff: 581.9617885089519

 - singleMassOscillatorUserFunction2: 

   + executable: True

   + diff: 581.9617885089519

 - singleMassOscillatorUserFunction3: 

   + executable: True

   + diff: 581.9617885089519

 - singleMassOscillatorUserFunction4: 

   + executable: True

   + diff: 581.9617885089519

 - singleMassOscillatorUserFunction5: 

   + executable: True

   + diff: 581.9617885089519

 - singleMassOscillatorUserFunction6: 

   + executable: True

   + diff: 581.9617885089519

 - singleMassOscillatorUserFunction7: 

   + executable: True

   + diff: 581.9617885089519

 - singleMassOscillatorUserFunction8: 

   + executable: True

   + diff: 581.9617885089519

 - singleMassOscillatorUserFunction9: 

   + executable: True

   + diff: 581.9617885089519

 - spinningDisc0: 

   + executable: True

   + diff: 0.0

 - spinningDisc1: 

   + executable: True

   + diff: 0.0

 - spinningDisc2: 

   + executable: True

   + diff: 0.0

 - spinningDisc3: 

   + executable: True

   + diff: 0.0

 - spinningDisc4: 

   + executable: True

   + diff: 0.0

 - spinningDisc5: 

   + executable: True

   + diff: 0.0

 - spinningDisc6: 

   + executable: True

   + diff: 0.0

 - spinningDisc7: 

   + executable: True

   + diff: 0.0

 - spinningDisc8: 

   + executable: True

   + diff: 0.0

 - spinningDisc9: 

   + executable: True

   + diff: 0.0

 - doubleMassOscillator0: 

   + executable: True

   + diff: 0.0

 - doubleMassOscillator1: 

   + executable: True

   + diff: 0.0

 - doubleMassOscillator2: 

   + executable: True

   + diff: 0.0

 - doubleMassOscillator3: 

   + executable: True

   + diff: 0.0

 - doubleMassOscillator4: 

   + executable: True

   + diff: 0.0

 - doubleMassOscillator5: 

   + executable: True

   + diff: 0.0

 - doubleMassOscillator6: 

   + executable: True

   + diff: 0.0

 - doubleMassOscillator7: 

   + executable: True

   + diff: 0.0

 - doubleMassOscillator8: 

   + executable: True

   + diff: 0.0

 - doubleMassOscillator9: 

   + executable: True

   + diff: 0.0

 - nMassOscillator0: 

   + executable: True

   + diff: 0.0

 - nMassOscillator1: 

   + executable: True

   + diff: 0.0

 - nMassOscillator2: 

   + executable: True

   + diff: 0.0

 - nMassOscillator3: 

   + executable: True

   + diff: 0.0

 - nMassOscillator4: 

   + executable: True

   + diff: 0.0

 - nMassOscillator5: 

   + executable: True

   + diff: 0.0

 - nMassOscillator6: 

   + executable: True

   + diff: 0.0

 - nMassOscillator7: 

   + executable: True

   + diff: 0.0

 - nMassOscillator8: 

   + executable: True

   + diff: 0.0

 - nMassOscillator9: 

   + executable: True

   + diff: 0.0

 - singlePendulum0: 

   + executable: True

   + diff: 0.0

 - singlePendulum1: 

   + executable: True

   + diff: 0.0

 - singlePendulum2: 

   + executable: True

   + diff: 14.177446878777541

 - singlePendulum3: 

   + executable: True

   + diff: 0.0

 - singlePendulum4: 

   + executable: True

   + diff: 0.0

 - singlePendulum5: 

   + executable: True

   + diff: 0.0

 - singlePendulum6: 

   + executable: True

   + diff: 0.0

 - singlePendulum7: 

   + executable: True

   + diff: 0.0

 - singlePendulum8: 

   + executable: True

   + diff: 14.177446878777541

 - singlePendulum9: 

   + executable: True

   + diff: 0.0

 - doublePendulum0: 

   + executable: True

   + diff: 0.0

 - doublePendulum1: 

   + executable: True

   + diff: 0.0

 - doublePendulum2: 

   + executable: True

   + diff: 0.0

 - doublePendulum3: 

   + executable: True

   + diff: 0.0

 - doublePendulum4: 

   + executable: True

   + diff: 0.0

 - doublePendulum5: 

   + executable: False

   + diff: -3

 - doublePendulum6: 

   + executable: True

   + diff: 0.0

 - doublePendulum7: 

   + executable: True

   + diff: 0.0

 - doublePendulum8: 

   + executable: True

   + diff: 0.0

 - doublePendulum9: 

   + executable: True

   + diff: 0.0

 - nPendulum0: 

   + executable: True

   + diff: 0.0

 - nPendulum1: 

   + executable: True

   + diff: 0.0

 - nPendulum2: 

   + executable: True

   + diff: 0.0

 - nPendulum3: 

   + executable: True

   + diff: 0.0

 - nPendulum4: 

   + executable: True

   + diff: 0.0

 - nPendulum5: 

   + executable: True

   + diff: 0.0

 - nPendulum6: 

   + executable: True

   + diff: 0.0

 - nPendulum7: 

   + executable: True

   + diff: 0.0

 - nPendulum8: 

   + executable: True

   + diff: 0.0

 - nPendulum9: 

   + executable: True

   + diff: 0.0

 - fourBarMechanismPointMasses0: 

   + executable: True

   + diff: 5647.183368884497

 - fourBarMechanismPointMasses1: 

   + executable: True

   + diff: 5647.183368884497

 - fourBarMechanismPointMasses2: 

   + executable: True

   + diff: 5647.183368884497

 - fourBarMechanismPointMasses3: 

   + executable: True

   + diff: 5647.183368884497

 - fourBarMechanismPointMasses4: 

   + executable: True

   + diff: 5647.183368884497

 - fourBarMechanismPointMasses5: 

   + executable: True

   + diff: 5647.183368884497

 - fourBarMechanismPointMasses6: 

   + executable: True

   + diff: 5647.183368884497

 - fourBarMechanismPointMasses7: 

   + executable: True

   + diff: 5647.183368884497

 - fourBarMechanismPointMasses8: 

   + executable: True

   + diff: 5647.183368884497

 - fourBarMechanismPointMasses9: 

   + executable: True

   + diff: 5647.183368884497

 - springCoupledFlyingRigidBodies0: 

   + executable: True

   + diff: 0.0

 - springCoupledFlyingRigidBodies1: 

   + executable: True

   + diff: 0.0

 - springCoupledFlyingRigidBodies2: 

   + executable: True

   + diff: 0.0

 - springCoupledFlyingRigidBodies3: 

   + executable: True

   + diff: 0.0

 - springCoupledFlyingRigidBodies4: 

   + executable: True

   + diff: 0.0

 - springCoupledFlyingRigidBodies5: 

   + executable: True

   + diff: 0.0

 - springCoupledFlyingRigidBodies6: 

   + executable: True

   + diff: 0.0

 - springCoupledFlyingRigidBodies7: 

   + executable: True

   + diff: 0.0

 - springCoupledFlyingRigidBodies8: 

   + executable: True

   + diff: 0.0

 - springCoupledFlyingRigidBodies9: 

   + executable: True

   + diff: 0.0

 - torsionalOscillator0: 

   + executable: True

   + diff: 0.0

 - torsionalOscillator1: 

   + executable: True

   + diff: 1.3388537942639345

 - torsionalOscillator2: 

   + executable: True

   + diff: 0.0

 - torsionalOscillator3: 

   + executable: True

   + diff: 0.0

 - torsionalOscillator4: 

   + executable: True

   + diff: 0.0

 - torsionalOscillator5: 

   + executable: True

   + diff: 0.0

 - torsionalOscillator6: 

   + executable: True

   + diff: 0.0

 - torsionalOscillator7: 

   + executable: True

   + diff: 0.0

 - torsionalOscillator8: 

   + executable: True

   + diff: 0.0

 - torsionalOscillator9: 

   + executable: True

   + diff: 0.0

 - invertedSinglePendulum0: 

   + executable: True

   + diff: 0.0

 - invertedSinglePendulum1: 

   + executable: True

   + diff: 0.0

 - invertedSinglePendulum2: 

   + executable: True

   + diff: 0.0

 - invertedSinglePendulum3: 

   + executable: True

   + diff: 0.0

 - invertedSinglePendulum4: 

   + executable: True

   + diff: 0.0

 - invertedSinglePendulum5: 

   + executable: True

   + diff: 0.0

 - invertedSinglePendulum6: 

   + executable: True

   + diff: 0.0

 - invertedSinglePendulum7: 

   + executable: True

   + diff: 0.0

 - invertedSinglePendulum8: 

   + executable: True

   + diff: 2.297012363949053e-07

 - invertedSinglePendulum9: 

   + executable: True

   + diff: 0.0

 - discRollingOnGround0: 

   + executable: True

   + diff: 2.048238984227359e-07

 - discRollingOnGround1: 

   + executable: True

   + diff: 2.048238984227359e-07

 - discRollingOnGround2: 

   + executable: True

   + diff: 2.048238984227359e-07

 - discRollingOnGround3: 

   + executable: True

   + diff: 2.048238984227359e-07

 - discRollingOnGround4: 

   + executable: True

   + diff: 2.048238984227359e-07

 - discRollingOnGround5: 

   + executable: True

   + diff: 2.048238984227359e-07

 - discRollingOnGround6: 

   + executable: True

   + diff: 2.048238984227359e-07

 - discRollingOnGround7: 

   + executable: True

   + diff: 2.048238984227359e-07

 - discRollingOnGround8: 

   + executable: True

   + diff: 2.048238984227359e-07

 - discRollingOnGround9: 

   + executable: True

   + diff: 2.048238984227359e-07

 - doublePendulumElasticSpring0: 

   + executable: True

   + diff: 0.0

 - doublePendulumElasticSpring1: 

   + executable: True

   + diff: 0.0

 - doublePendulumElasticSpring2: 

   + executable: True

   + diff: 0.0

 - doublePendulumElasticSpring3: 

   + executable: True

   + diff: 0.0

 - doublePendulumElasticSpring4: 

   + executable: True

   + diff: 0.0

 - doublePendulumElasticSpring5: 

   + executable: True

   + diff: 0.0

 - doublePendulumElasticSpring6: 

   + executable: True

   + diff: 0.0

 - doublePendulumElasticSpring7: 

   + executable: True

   + diff: 0.0

 - doublePendulumElasticSpring8: 

   + executable: True

   + diff: 0.0

 - doublePendulumElasticSpring9: 

   + executable: True

   + diff: 0.0

 - nPendulumElasticSpring0: 

   + executable: True

   + diff: 49.43368984475479

 - nPendulumElasticSpring1: 

   + executable: True

   + diff: 49.43368984475479

 - nPendulumElasticSpring2: 

   + executable: True

   + diff: 49.43368984475479

 - nPendulumElasticSpring3: 

   + executable: True

   + diff: 49.43368984475479

 - nPendulumElasticSpring4: 

   + executable: True

   + diff: 49.43368984475479

 - nPendulumElasticSpring5: 

   + executable: True

   + diff: 49.43368984475479

 - nPendulumElasticSpring6: 

   + executable: True

   + diff: 49.43368984475479

 - nPendulumElasticSpring7: 

   + executable: True

   + diff: 49.43368984475479

 - nPendulumElasticSpring8: 

   + executable: True

   + diff: 49.43368984475479

 - nPendulumElasticSpring9: 

   + executable: True

   + diff: 49.43368984475479

 - elasticChain0: 

   + executable: True

   + diff: 167.95529298336885

 - elasticChain1: 

   + executable: False

   + diff: -3

 - elasticChain2: 

   + executable: True

   + diff: 0.0

 - elasticChain3: 

   + executable: False

   + diff: -3

 - elasticChain4: 

   + executable: False

   + diff: -3

 - elasticChain5: 

   + executable: True

   + diff: 167.95529298336885

 - elasticChain6: 

   + executable: True

   + diff: 167.95529298336885

 - elasticChain7: 

   + executable: False

   + diff: -3

 - elasticChain8: 

   + executable: False

   + diff: -3

 - elasticChain9: 

   + executable: False

   + diff: -3

 - singlePendulumRigidBody0: 

   + executable: True

   + diff: 0.0

 - singlePendulumRigidBody1: 

   + executable: True

   + diff: 0.0

 - singlePendulumRigidBody2: 

   + executable: True

   + diff: 0.0

 - singlePendulumRigidBody3: 

   + executable: True

   + diff: 0.0

 - singlePendulumRigidBody4: 

   + executable: True

   + diff: 0.0

 - singlePendulumRigidBody5: 

   + executable: True

   + diff: 0.0

 - singlePendulumRigidBody6: 

   + executable: True

   + diff: 0.0

 - singlePendulumRigidBody7: 

   + executable: True

   + diff: 0.0

 - singlePendulumRigidBody8: 

   + executable: True

   + diff: 0.0

 - singlePendulumRigidBody9: 

   + executable: True

   + diff: 0.0

 - massPointOnStringRigid0: 

   + executable: True

   + diff: 0.0

 - massPointOnStringRigid1: 

   + executable: True

   + diff: 0.0

 - massPointOnStringRigid2: 

   + executable: True

   + diff: 0.0

 - massPointOnStringRigid3: 

   + executable: True

   + diff: 0.0

 - massPointOnStringRigid4: 

   + executable: True

   + diff: 0.0

 - massPointOnStringRigid5: 

   + executable: True

   + diff: 0.0

 - massPointOnStringRigid6: 

   + executable: True

   + diff: 0.0

 - massPointOnStringRigid7: 

   + executable: True

   + diff: 0.0

 - massPointOnStringRigid8: 

   + executable: True

   + diff: 0.0

 - massPointOnStringRigid9: 

   + executable: True

   + diff: 0.0

 - massPointOnStringElastic0: 

   + executable: True

   + diff: 0.0

 - massPointOnStringElastic1: 

   + executable: True

   + diff: 0.0

 - massPointOnStringElastic2: 

   + executable: True

   + diff: 0.0

 - massPointOnStringElastic3: 

   + executable: True

   + diff: 0.0

 - massPointOnStringElastic4: 

   + executable: True

   + diff: 0.0

 - massPointOnStringElastic5: 

   + executable: True

   + diff: 0.0

 - massPointOnStringElastic6: 

   + executable: True

   + diff: 0.0

 - massPointOnStringElastic7: 

   + executable: True

   + diff: 0.0

 - massPointOnStringElastic8: 

   + executable: True

   + diff: 0.0

 - massPointOnStringElastic9: 

   + executable: True

   + diff: 0.0

 - linkOnTwoPrismaticJoints0: 

   + executable: True

   + diff: 1.6089384524370566e-06

 - linkOnTwoPrismaticJoints1: 

   + executable: True

   + diff: 0.0

 - linkOnTwoPrismaticJoints2: 

   + executable: True

   + diff: 0.0

 - linkOnTwoPrismaticJoints3: 

   + executable: True

   + diff: 0.0

 - linkOnTwoPrismaticJoints4: 

   + executable: True

   + diff: 1.660978325171358e-07

 - linkOnTwoPrismaticJoints5: 

   + executable: True

   + diff: 1.660978325171358e-07

 - linkOnTwoPrismaticJoints6: 

   + executable: True

   + diff: 0.0

 - linkOnTwoPrismaticJoints7: 

   + executable: True

   + diff: 0.0

 - linkOnTwoPrismaticJoints8: 

   + executable: True

   + diff: 0.0

 - linkOnTwoPrismaticJoints9: 

   + executable: True

   + diff: 0.0

 - flyingRigidBody0: 

   + executable: True

   + diff: 2.486023961562353e-07

 - flyingRigidBody1: 

   + executable: True

   + diff: 2.486023961562353e-07

 - flyingRigidBody2: 

   + executable: True

   + diff: 2.486023961562353e-07

 - flyingRigidBody3: 

   + executable: True

   + diff: 2.486023961562353e-07

 - flyingRigidBody4: 

   + executable: True

   + diff: 2.486023961562353e-07

 - flyingRigidBody5: 

   + executable: True

   + diff: 0.0

 - flyingRigidBody6: 

   + executable: True

   + diff: 0.0

 - flyingRigidBody7: 

   + executable: True

   + diff: 2.486023961562353e-07

 - flyingRigidBody8: 

   + executable: True

   + diff: 0.0

 - flyingRigidBody9: 

   + executable: True

   + diff: 2.486023961562353e-07

 - suspendedRigidBody0: 

   + executable: True

   + diff: 204.36808156828516

 - suspendedRigidBody1: 

   + executable: True

   + diff: 17.999929868611325

 - suspendedRigidBody2: 

   + executable: True

   + diff: 17.169841521640063

 - suspendedRigidBody3: 

   + executable: True

   + diff: 139.43207234087285

 - suspendedRigidBody4: 

   + executable: True

   + diff: 0.0

 - suspendedRigidBody5: 

   + executable: True

   + diff: 17.169841521640063

 - suspendedRigidBody6: 

   + executable: True

   + diff: 0.0

 - suspendedRigidBody7: 

   + executable: True

   + diff: 0.0

 - suspendedRigidBody8: 

   + executable: True

   + diff: 17.169841521640063

 - suspendedRigidBody9: 

   + executable: True

   + diff: 17.169841521640063

 - gyroscopeOnSphericalJoint0: 

   + executable: True

   + diff: 0.0

 - gyroscopeOnSphericalJoint1: 

   + executable: True

   + diff: 0.0

 - gyroscopeOnSphericalJoint2: 

   + executable: True

   + diff: 0.0

 - gyroscopeOnSphericalJoint3: 

   + executable: True

   + diff: 0.0

 - gyroscopeOnSphericalJoint4: 

   + executable: True

   + diff: 0.0

 - gyroscopeOnSphericalJoint5: 

   + executable: True

   + diff: 0.0

 - gyroscopeOnSphericalJoint6: 

   + executable: True

   + diff: 0.0

 - gyroscopeOnSphericalJoint7: 

   + executable: True

   + diff: 0.0

 - gyroscopeOnSphericalJoint8: 

   + executable: True

   + diff: 0.0

 - gyroscopeOnSphericalJoint9: 

   + executable: True

   + diff: 0.0

 - prismaticJointSystem0: 

   + executable: True

   + diff: 0.0

 - prismaticJointSystem1: 

   + executable: True

   + diff: 0.0

 - prismaticJointSystem2: 

   + executable: True

   + diff: 0.0

 - prismaticJointSystem3: 

   + executable: True

   + diff: 0.0

 - prismaticJointSystem4: 

   + executable: True

   + diff: 0.0

 - prismaticJointSystem5: 

   + executable: True

   + diff: 0.0

 - prismaticJointSystem6: 

   + executable: True

   + diff: 0.0

 - prismaticJointSystem7: 

   + executable: True

   + diff: 0.0

 - prismaticJointSystem8: 

   + executable: True

   + diff: 0.0

 - prismaticJointSystem9: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithSprings0: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithSprings1: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithSprings2: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithSprings3: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithSprings4: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithSprings5: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithSprings6: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithSprings7: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithSprings8: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithSprings9: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithDistances0: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithDistances1: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithDistances2: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithDistances3: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithDistances4: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithDistances5: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithDistances6: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithDistances7: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithDistances8: 

   + executable: True

   + diff: 0.0

 - twoMassPointsWithDistances9: 

   + executable: True

   + diff: 0.0

 - rigidRotorSimplySupported0: 

   + executable: True

   + diff: 121.93037900265061

 - rigidRotorSimplySupported1: 

   + executable: True

   + diff: 0.0

 - rigidRotorSimplySupported2: 

   + executable: True

   + diff: 121.93037900265061

 - rigidRotorSimplySupported3: 

   + executable: True

   + diff: 121.93037900265061

 - rigidRotorSimplySupported4: 

   + executable: True

   + diff: 0.0

 - rigidRotorSimplySupported5: 

   + executable: True

   + diff: 121.93037900265061

 - rigidRotorSimplySupported6: 

   + executable: True

   + diff: 121.93037900265061

 - rigidRotorSimplySupported7: 

   + executable: True

   + diff: 121.93037900265061

 - rigidRotorSimplySupported8: 

   + executable: True

   + diff: 121.93037900265061

 - rigidRotorSimplySupported9: 

   + executable: True

   + diff: 121.93037900265061

 - rigidRotorUnbalanced0: 

   + executable: True

   + diff: 24661.864271674836

 - rigidRotorUnbalanced1: 

   + executable: True

   + diff: 24661.864271674836

 - rigidRotorUnbalanced2: 

   + executable: True

   + diff: 24661.864271674836

 - rigidRotorUnbalanced3: 

   + executable: True

   + diff: 24661.864271674836

 - rigidRotorUnbalanced4: 

   + executable: True

   + diff: 24661.864271674836

 - rigidRotorUnbalanced5: 

   + executable: True

   + diff: 24663.03951399376

 - rigidRotorUnbalanced6: 

   + executable: True

   + diff: 24663.03951399376

 - rigidRotorUnbalanced7: 

   + executable: True

   + diff: 24663.03951399376

 - rigidRotorUnbalanced8: 

   + executable: True

   + diff: 24661.864271674836

 - rigidRotorUnbalanced9: 

   + executable: True

   + diff: 24663.03951399376

 - doublePendulumRigidBodies0: 

   + executable: True

   + diff: 0.0

 - doublePendulumRigidBodies1: 

   + executable: True

   + diff: 0.0

 - doublePendulumRigidBodies2: 

   + executable: True

   + diff: 5.135628815481592e-06

 - doublePendulumRigidBodies3: 

   + executable: True

   + diff: 0.0

 - doublePendulumRigidBodies4: 

   + executable: True

   + diff: 0.0

 - doublePendulumRigidBodies5: 

   + executable: True

   + diff: 0.0

 - doublePendulumRigidBodies6: 

   + executable: True

   + diff: 0.0

 - doublePendulumRigidBodies7: 

   + executable: True

   + diff: 0.0

 - doublePendulumRigidBodies8: 

   + executable: True

   + diff: 0.0

 - doublePendulumRigidBodies9: 

   + executable: True

   + diff: 0.0

 - sliderCrankRigidBodies0: 

   + executable: True

   + diff: 0.0

 - sliderCrankRigidBodies1: 

   + executable: True

   + diff: 0.0

 - sliderCrankRigidBodies2: 

   + executable: True

   + diff: 0.0

 - sliderCrankRigidBodies3: 

   + executable: True

   + diff: 0.0

 - sliderCrankRigidBodies4: 

   + executable: True

   + diff: 0.0

 - sliderCrankRigidBodies5: 

   + executable: True

   + diff: 0.0

 - sliderCrankRigidBodies6: 

   + executable: True

   + diff: 0.0

 - sliderCrankRigidBodies7: 

   + executable: True

   + diff: 0.0

 - sliderCrankRigidBodies8: 

   + executable: True

   + diff: 0.0

 - sliderCrankRigidBodies9: 

   + executable: True

   + diff: 0.0

 - model flyingMassPoint0: exec=1,diff=0

 - model flyingMassPoint1: exec=1,diff=0

 - model flyingMassPoint2: exec=1,diff=0

 - model flyingMassPoint3: exec=1,diff=0

 - model flyingMassPoint4: exec=1,diff=0

 - model flyingMassPoint5: exec=1,diff=0

 - model flyingMassPoint6: exec=1,diff=0

 - model flyingMassPoint7: exec=1,diff=0

 - model flyingMassPoint8: exec=1,diff=0

 - model flyingMassPoint9: exec=1,diff=0


SUMMARY model flyingMassPoint: exec=100.0%, correct=100.0%

 - model freeFallMassPoint0: exec=1,diff=0

 - model freeFallMassPoint1: exec=1,diff=0

 - model freeFallMassPoint2: exec=1,diff=0

 - model freeFallMassPoint3: exec=1,diff=0

 - model freeFallMassPoint4: exec=1,diff=0

 - model freeFallMassPoint5: exec=1,diff=0

 - model freeFallMassPoint6: exec=1,diff=0

 - model freeFallMassPoint7: exec=1,diff=0

 - model freeFallMassPoint8: exec=1,diff=0

 - model freeFallMassPoint9: exec=1,diff=0


SUMMARY model freeFallMassPoint: exec=100.0%, correct=100.0%

 - model singleMassOscillator0: exec=1,diff=0

 - model singleMassOscillator1: exec=1,diff=0

 - model singleMassOscillator2: exec=1,diff=0

 - model singleMassOscillator3: exec=1,diff=0

 - model singleMassOscillator4: exec=1,diff=0

 - model singleMassOscillator5: exec=1,diff=0

 - model singleMassOscillator6: exec=1,diff=0

 - model singleMassOscillator7: exec=1,diff=0

 - model singleMassOscillator8: exec=1,diff=0

 - model singleMassOscillator9: exec=1,diff=0


SUMMARY model singleMassOscillator: exec=100.0%, correct=100.0%

 - model singleMassOscillatorGravity0: exec=1,diff=0

 - model singleMassOscillatorGravity1: exec=1,diff=0

 - model singleMassOscillatorGravity2: exec=1,diff=0

 - model singleMassOscillatorGravity3: exec=1,diff=0

 - model singleMassOscillatorGravity4: exec=1,diff=0

 - model singleMassOscillatorGravity5: exec=1,diff=0

 - model singleMassOscillatorGravity6: exec=1,diff=0

 - model singleMassOscillatorGravity7: exec=1,diff=0

 - model singleMassOscillatorGravity8: exec=1,diff=0

 - model singleMassOscillatorGravity9: exec=1,diff=0


SUMMARY model singleMassOscillatorGravity: exec=100.0%, correct=100.0%

 - model sliderCrankSimple0: exec=0,diff=-3.0

 - model sliderCrankSimple1: exec=0,diff=-3.0

 - model sliderCrankSimple2: exec=0,diff=-3.0

 - model sliderCrankSimple3: exec=0,diff=-3.0

 - model sliderCrankSimple4: exec=0,diff=-3.0

 - model sliderCrankSimple5: exec=1,diff=100.811

 - model sliderCrankSimple6: exec=0,diff=-3.0

 - model sliderCrankSimple7: exec=0,diff=-3.0

 - model sliderCrankSimple8: exec=0,diff=-3.0

 - model sliderCrankSimple9: exec=0,diff=-3.0


SUMMARY model sliderCrankSimple: exec=10.0%, correct=0.0%

 - model singlePendulumElasticSpring0: exec=1,diff=0

 - model singlePendulumElasticSpring1: exec=1,diff=0

 - model singlePendulumElasticSpring2: exec=1,diff=0

 - model singlePendulumElasticSpring3: exec=1,diff=0

 - model singlePendulumElasticSpring4: exec=1,diff=0

 - model singlePendulumElasticSpring5: exec=1,diff=0

 - model singlePendulumElasticSpring6: exec=1,diff=0

 - model singlePendulumElasticSpring7: exec=1,diff=0

 - model singlePendulumElasticSpring8: exec=1,diff=0

 - model singlePendulumElasticSpring9: exec=1,diff=0


SUMMARY model singlePendulumElasticSpring: exec=100.0%, correct=100.0%

 - model singleMassOscillatorUserFunction0: exec=1,diff=581.962

 - model singleMassOscillatorUserFunction1: exec=1,diff=581.962

 - model singleMassOscillatorUserFunction2: exec=1,diff=581.962

 - model singleMassOscillatorUserFunction3: exec=1,diff=581.962

 - model singleMassOscillatorUserFunction4: exec=1,diff=581.962

 - model singleMassOscillatorUserFunction5: exec=1,diff=581.962

 - model singleMassOscillatorUserFunction6: exec=1,diff=581.962

 - model singleMassOscillatorUserFunction7: exec=1,diff=581.962

 - model singleMassOscillatorUserFunction8: exec=1,diff=581.962

 - model singleMassOscillatorUserFunction9: exec=1,diff=581.962


SUMMARY model singleMassOscillatorUserFunction: exec=100.0%, correct=0.0%

 - model spinningDisc0: exec=1,diff=0

 - model spinningDisc1: exec=1,diff=0

 - model spinningDisc2: exec=1,diff=0

 - model spinningDisc3: exec=1,diff=0

 - model spinningDisc4: exec=1,diff=0

 - model spinningDisc5: exec=1,diff=0

 - model spinningDisc6: exec=1,diff=0

 - model spinningDisc7: exec=1,diff=0

 - model spinningDisc8: exec=1,diff=0

 - model spinningDisc9: exec=1,diff=0


SUMMARY model spinningDisc: exec=100.0%, correct=100.0%

 - model doubleMassOscillator0: exec=1,diff=0

 - model doubleMassOscillator1: exec=1,diff=0

 - model doubleMassOscillator2: exec=1,diff=0

 - model doubleMassOscillator3: exec=1,diff=0

 - model doubleMassOscillator4: exec=1,diff=0

 - model doubleMassOscillator5: exec=1,diff=0

 - model doubleMassOscillator6: exec=1,diff=0

 - model doubleMassOscillator7: exec=1,diff=0

 - model doubleMassOscillator8: exec=1,diff=0

 - model doubleMassOscillator9: exec=1,diff=0


SUMMARY model doubleMassOscillator: exec=100.0%, correct=100.0%

 - model nMassOscillator0: exec=1,diff=0

 - model nMassOscillator1: exec=1,diff=0

 - model nMassOscillator2: exec=1,diff=0

 - model nMassOscillator3: exec=1,diff=0

 - model nMassOscillator4: exec=1,diff=0

 - model nMassOscillator5: exec=1,diff=0

 - model nMassOscillator6: exec=1,diff=0

 - model nMassOscillator7: exec=1,diff=0

 - model nMassOscillator8: exec=1,diff=0

 - model nMassOscillator9: exec=1,diff=0


SUMMARY model nMassOscillator: exec=100.0%, correct=100.0%

 - model singlePendulum0: exec=1,diff=0

 - model singlePendulum1: exec=1,diff=0

 - model singlePendulum2: exec=1,diff=14.1774

 - model singlePendulum3: exec=1,diff=0

 - model singlePendulum4: exec=1,diff=0

 - model singlePendulum5: exec=1,diff=0

 - model singlePendulum6: exec=1,diff=0

 - model singlePendulum7: exec=1,diff=0

 - model singlePendulum8: exec=1,diff=14.1774

 - model singlePendulum9: exec=1,diff=0


SUMMARY model singlePendulum: exec=100.0%, correct=80.0%

 - model doublePendulum0: exec=1,diff=0

 - model doublePendulum1: exec=1,diff=0

 - model doublePendulum2: exec=1,diff=0

 - model doublePendulum3: exec=1,diff=0

 - model doublePendulum4: exec=1,diff=0

 - model doublePendulum5: exec=0,diff=-3.0

 - model doublePendulum6: exec=1,diff=0

 - model doublePendulum7: exec=1,diff=0

 - model doublePendulum8: exec=1,diff=0

 - model doublePendulum9: exec=1,diff=0


SUMMARY model doublePendulum: exec=90.0%, correct=90.0%

 - model nPendulum0: exec=1,diff=0

 - model nPendulum1: exec=1,diff=0

 - model nPendulum2: exec=1,diff=0

 - model nPendulum3: exec=1,diff=0

 - model nPendulum4: exec=1,diff=0

 - model nPendulum5: exec=1,diff=0

 - model nPendulum6: exec=1,diff=0

 - model nPendulum7: exec=1,diff=0

 - model nPendulum8: exec=1,diff=0

 - model nPendulum9: exec=1,diff=0


SUMMARY model nPendulum: exec=100.0%, correct=100.0%

 - model fourBarMechanismPointMasses0: exec=1,diff=5647.18

 - model fourBarMechanismPointMasses1: exec=1,diff=5647.18

 - model fourBarMechanismPointMasses2: exec=1,diff=5647.18

 - model fourBarMechanismPointMasses3: exec=1,diff=5647.18

 - model fourBarMechanismPointMasses4: exec=1,diff=5647.18

 - model fourBarMechanismPointMasses5: exec=1,diff=5647.18

 - model fourBarMechanismPointMasses6: exec=1,diff=5647.18

 - model fourBarMechanismPointMasses7: exec=1,diff=5647.18

 - model fourBarMechanismPointMasses8: exec=1,diff=5647.18

 - model fourBarMechanismPointMasses9: exec=1,diff=5647.18


SUMMARY model fourBarMechanismPointMasses: exec=100.0%, correct=0.0%

 - model springCoupledFlyingRigidBodies0: exec=1,diff=0

 - model springCoupledFlyingRigidBodies1: exec=1,diff=0

 - model springCoupledFlyingRigidBodies2: exec=1,diff=0

 - model springCoupledFlyingRigidBodies3: exec=1,diff=0

 - model springCoupledFlyingRigidBodies4: exec=1,diff=0

 - model springCoupledFlyingRigidBodies5: exec=1,diff=0

 - model springCoupledFlyingRigidBodies6: exec=1,diff=0

 - model springCoupledFlyingRigidBodies7: exec=1,diff=0

 - model springCoupledFlyingRigidBodies8: exec=1,diff=0

 - model springCoupledFlyingRigidBodies9: exec=1,diff=0


SUMMARY model springCoupledFlyingRigidBodies: exec=100.0%, correct=100.0%

 - model torsionalOscillator0: exec=1,diff=0

 - model torsionalOscillator1: exec=1,diff=1.33885

 - model torsionalOscillator2: exec=1,diff=0

 - model torsionalOscillator3: exec=1,diff=0

 - model torsionalOscillator4: exec=1,diff=0

 - model torsionalOscillator5: exec=1,diff=0

 - model torsionalOscillator6: exec=1,diff=0

 - model torsionalOscillator7: exec=1,diff=0

 - model torsionalOscillator8: exec=1,diff=0

 - model torsionalOscillator9: exec=1,diff=0


SUMMARY model torsionalOscillator: exec=100.0%, correct=90.0%

 - model invertedSinglePendulum0: exec=1,diff=0

 - model invertedSinglePendulum1: exec=1,diff=0

 - model invertedSinglePendulum2: exec=1,diff=0

 - model invertedSinglePendulum3: exec=1,diff=0

 - model invertedSinglePendulum4: exec=1,diff=0

 - model invertedSinglePendulum5: exec=1,diff=0

 - model invertedSinglePendulum6: exec=1,diff=0

 - model invertedSinglePendulum7: exec=1,diff=0

 - model invertedSinglePendulum8: exec=1,diff=2.29701e-07

 - model invertedSinglePendulum9: exec=1,diff=0


SUMMARY model invertedSinglePendulum: exec=100.0%, correct=100.0%

 - model discRollingOnGround0: exec=1,diff=2.04824e-07

 - model discRollingOnGround1: exec=1,diff=2.04824e-07

 - model discRollingOnGround2: exec=1,diff=2.04824e-07

 - model discRollingOnGround3: exec=1,diff=2.04824e-07

 - model discRollingOnGround4: exec=1,diff=2.04824e-07

 - model discRollingOnGround5: exec=1,diff=2.04824e-07

 - model discRollingOnGround6: exec=1,diff=2.04824e-07

 - model discRollingOnGround7: exec=1,diff=2.04824e-07

 - model discRollingOnGround8: exec=1,diff=2.04824e-07

 - model discRollingOnGround9: exec=1,diff=2.04824e-07


SUMMARY model discRollingOnGround: exec=100.0%, correct=100.0%

 - model doublePendulumElasticSpring0: exec=1,diff=0

 - model doublePendulumElasticSpring1: exec=1,diff=0

 - model doublePendulumElasticSpring2: exec=1,diff=0

 - model doublePendulumElasticSpring3: exec=1,diff=0

 - model doublePendulumElasticSpring4: exec=1,diff=0

 - model doublePendulumElasticSpring5: exec=1,diff=0

 - model doublePendulumElasticSpring6: exec=1,diff=0

 - model doublePendulumElasticSpring7: exec=1,diff=0

 - model doublePendulumElasticSpring8: exec=1,diff=0

 - model doublePendulumElasticSpring9: exec=1,diff=0


SUMMARY model doublePendulumElasticSpring: exec=100.0%, correct=100.0%

 - model nPendulumElasticSpring0: exec=1,diff=49.4337

 - model nPendulumElasticSpring1: exec=1,diff=49.4337

 - model nPendulumElasticSpring2: exec=1,diff=49.4337

 - model nPendulumElasticSpring3: exec=1,diff=49.4337

 - model nPendulumElasticSpring4: exec=1,diff=49.4337

 - model nPendulumElasticSpring5: exec=1,diff=49.4337

 - model nPendulumElasticSpring6: exec=1,diff=49.4337

 - model nPendulumElasticSpring7: exec=1,diff=49.4337

 - model nPendulumElasticSpring8: exec=1,diff=49.4337

 - model nPendulumElasticSpring9: exec=1,diff=49.4337


SUMMARY model nPendulumElasticSpring: exec=100.0%, correct=0.0%

 - model elasticChain0: exec=1,diff=167.955

 - model elasticChain1: exec=0,diff=-3.0

 - model elasticChain2: exec=1,diff=0

 - model elasticChain3: exec=0,diff=-3.0

 - model elasticChain4: exec=0,diff=-3.0

 - model elasticChain5: exec=1,diff=167.955

 - model elasticChain6: exec=1,diff=167.955

 - model elasticChain7: exec=0,diff=-3.0

 - model elasticChain8: exec=0,diff=-3.0

 - model elasticChain9: exec=0,diff=-3.0


SUMMARY model elasticChain: exec=40.0%, correct=10.0%

 - model singlePendulumRigidBody0: exec=1,diff=0

 - model singlePendulumRigidBody1: exec=1,diff=0

 - model singlePendulumRigidBody2: exec=1,diff=0

 - model singlePendulumRigidBody3: exec=1,diff=0

 - model singlePendulumRigidBody4: exec=1,diff=0

 - model singlePendulumRigidBody5: exec=1,diff=0

 - model singlePendulumRigidBody6: exec=1,diff=0

 - model singlePendulumRigidBody7: exec=1,diff=0

 - model singlePendulumRigidBody8: exec=1,diff=0

 - model singlePendulumRigidBody9: exec=1,diff=0


SUMMARY model singlePendulumRigidBody: exec=100.0%, correct=100.0%

 - model massPointOnStringRigid0: exec=1,diff=0

 - model massPointOnStringRigid1: exec=1,diff=0

 - model massPointOnStringRigid2: exec=1,diff=0

 - model massPointOnStringRigid3: exec=1,diff=0

 - model massPointOnStringRigid4: exec=1,diff=0

 - model massPointOnStringRigid5: exec=1,diff=0

 - model massPointOnStringRigid6: exec=1,diff=0

 - model massPointOnStringRigid7: exec=1,diff=0

 - model massPointOnStringRigid8: exec=1,diff=0

 - model massPointOnStringRigid9: exec=1,diff=0


SUMMARY model massPointOnStringRigid: exec=100.0%, correct=100.0%

 - model massPointOnStringElastic0: exec=1,diff=0

 - model massPointOnStringElastic1: exec=1,diff=0

 - model massPointOnStringElastic2: exec=1,diff=0

 - model massPointOnStringElastic3: exec=1,diff=0

 - model massPointOnStringElastic4: exec=1,diff=0

 - model massPointOnStringElastic5: exec=1,diff=0

 - model massPointOnStringElastic6: exec=1,diff=0

 - model massPointOnStringElastic7: exec=1,diff=0

 - model massPointOnStringElastic8: exec=1,diff=0

 - model massPointOnStringElastic9: exec=1,diff=0


SUMMARY model massPointOnStringElastic: exec=100.0%, correct=100.0%

 - model linkOnTwoPrismaticJoints0: exec=1,diff=1.60894e-06

 - model linkOnTwoPrismaticJoints1: exec=1,diff=0

 - model linkOnTwoPrismaticJoints2: exec=1,diff=0

 - model linkOnTwoPrismaticJoints3: exec=1,diff=0

 - model linkOnTwoPrismaticJoints4: exec=1,diff=1.66098e-07

 - model linkOnTwoPrismaticJoints5: exec=1,diff=1.66098e-07

 - model linkOnTwoPrismaticJoints6: exec=1,diff=0

 - model linkOnTwoPrismaticJoints7: exec=1,diff=0

 - model linkOnTwoPrismaticJoints8: exec=1,diff=0

 - model linkOnTwoPrismaticJoints9: exec=1,diff=0


SUMMARY model linkOnTwoPrismaticJoints: exec=100.0%, correct=100.0%

 - model flyingRigidBody0: exec=1,diff=2.48602e-07

 - model flyingRigidBody1: exec=1,diff=2.48602e-07

 - model flyingRigidBody2: exec=1,diff=2.48602e-07

 - model flyingRigidBody3: exec=1,diff=2.48602e-07

 - model flyingRigidBody4: exec=1,diff=2.48602e-07

 - model flyingRigidBody5: exec=1,diff=0

 - model flyingRigidBody6: exec=1,diff=0

 - model flyingRigidBody7: exec=1,diff=2.48602e-07

 - model flyingRigidBody8: exec=1,diff=0

 - model flyingRigidBody9: exec=1,diff=2.48602e-07


SUMMARY model flyingRigidBody: exec=100.0%, correct=100.0%

 - model suspendedRigidBody0: exec=1,diff=204.368

 - model suspendedRigidBody1: exec=1,diff=17.9999

 - model suspendedRigidBody2: exec=1,diff=17.1698

 - model suspendedRigidBody3: exec=1,diff=139.432

 - model suspendedRigidBody4: exec=1,diff=0

 - model suspendedRigidBody5: exec=1,diff=17.1698

 - model suspendedRigidBody6: exec=1,diff=0

 - model suspendedRigidBody7: exec=1,diff=0

 - model suspendedRigidBody8: exec=1,diff=17.1698

 - model suspendedRigidBody9: exec=1,diff=17.1698


SUMMARY model suspendedRigidBody: exec=100.0%, correct=30.0%

 - model gyroscopeOnSphericalJoint0: exec=1,diff=0

 - model gyroscopeOnSphericalJoint1: exec=1,diff=0

 - model gyroscopeOnSphericalJoint2: exec=1,diff=0

 - model gyroscopeOnSphericalJoint3: exec=1,diff=0

 - model gyroscopeOnSphericalJoint4: exec=1,diff=0

 - model gyroscopeOnSphericalJoint5: exec=1,diff=0

 - model gyroscopeOnSphericalJoint6: exec=1,diff=0

 - model gyroscopeOnSphericalJoint7: exec=1,diff=0

 - model gyroscopeOnSphericalJoint8: exec=1,diff=0

 - model gyroscopeOnSphericalJoint9: exec=1,diff=0


SUMMARY model gyroscopeOnSphericalJoint: exec=100.0%, correct=100.0%

 - model prismaticJointSystem0: exec=1,diff=0

 - model prismaticJointSystem1: exec=1,diff=0

 - model prismaticJointSystem2: exec=1,diff=0

 - model prismaticJointSystem3: exec=1,diff=0

 - model prismaticJointSystem4: exec=1,diff=0

 - model prismaticJointSystem5: exec=1,diff=0

 - model prismaticJointSystem6: exec=1,diff=0

 - model prismaticJointSystem7: exec=1,diff=0

 - model prismaticJointSystem8: exec=1,diff=0

 - model prismaticJointSystem9: exec=1,diff=0


SUMMARY model prismaticJointSystem: exec=100.0%, correct=100.0%

 - model twoMassPointsWithSprings0: exec=1,diff=0

 - model twoMassPointsWithSprings1: exec=1,diff=0

 - model twoMassPointsWithSprings2: exec=1,diff=0

 - model twoMassPointsWithSprings3: exec=1,diff=0

 - model twoMassPointsWithSprings4: exec=1,diff=0

 - model twoMassPointsWithSprings5: exec=1,diff=0

 - model twoMassPointsWithSprings6: exec=1,diff=0

 - model twoMassPointsWithSprings7: exec=1,diff=0

 - model twoMassPointsWithSprings8: exec=1,diff=0

 - model twoMassPointsWithSprings9: exec=1,diff=0


SUMMARY model twoMassPointsWithSprings: exec=100.0%, correct=100.0%

 - model twoMassPointsWithDistances0: exec=1,diff=0

 - model twoMassPointsWithDistances1: exec=1,diff=0

 - model twoMassPointsWithDistances2: exec=1,diff=0

 - model twoMassPointsWithDistances3: exec=1,diff=0

 - model twoMassPointsWithDistances4: exec=1,diff=0

 - model twoMassPointsWithDistances5: exec=1,diff=0

 - model twoMassPointsWithDistances6: exec=1,diff=0

 - model twoMassPointsWithDistances7: exec=1,diff=0

 - model twoMassPointsWithDistances8: exec=1,diff=0

 - model twoMassPointsWithDistances9: exec=1,diff=0


SUMMARY model twoMassPointsWithDistances: exec=100.0%, correct=100.0%

 - model rigidRotorSimplySupported0: exec=1,diff=121.93

 - model rigidRotorSimplySupported1: exec=1,diff=0

 - model rigidRotorSimplySupported2: exec=1,diff=121.93

 - model rigidRotorSimplySupported3: exec=1,diff=121.93

 - model rigidRotorSimplySupported4: exec=1,diff=0

 - model rigidRotorSimplySupported5: exec=1,diff=121.93

 - model rigidRotorSimplySupported6: exec=1,diff=121.93

 - model rigidRotorSimplySupported7: exec=1,diff=121.93

 - model rigidRotorSimplySupported8: exec=1,diff=121.93

 - model rigidRotorSimplySupported9: exec=1,diff=121.93


SUMMARY model rigidRotorSimplySupported: exec=100.0%, correct=20.0%

 - model rigidRotorUnbalanced0: exec=1,diff=24661.9

 - model rigidRotorUnbalanced1: exec=1,diff=24661.9

 - model rigidRotorUnbalanced2: exec=1,diff=24661.9

 - model rigidRotorUnbalanced3: exec=1,diff=24661.9

 - model rigidRotorUnbalanced4: exec=1,diff=24661.9

 - model rigidRotorUnbalanced5: exec=1,diff=24663.0

 - model rigidRotorUnbalanced6: exec=1,diff=24663.0

 - model rigidRotorUnbalanced7: exec=1,diff=24663.0

 - model rigidRotorUnbalanced8: exec=1,diff=24661.9

 - model rigidRotorUnbalanced9: exec=1,diff=24663.0


SUMMARY model rigidRotorUnbalanced: exec=100.0%, correct=0.0%

 - model doublePendulumRigidBodies0: exec=1,diff=0

 - model doublePendulumRigidBodies1: exec=1,diff=0

 - model doublePendulumRigidBodies2: exec=1,diff=5.13563e-06

 - model doublePendulumRigidBodies3: exec=1,diff=0

 - model doublePendulumRigidBodies4: exec=1,diff=0

 - model doublePendulumRigidBodies5: exec=1,diff=0

 - model doublePendulumRigidBodies6: exec=1,diff=0

 - model doublePendulumRigidBodies7: exec=1,diff=0

 - model doublePendulumRigidBodies8: exec=1,diff=0

 - model doublePendulumRigidBodies9: exec=1,diff=0


SUMMARY model doublePendulumRigidBodies: exec=100.0%, correct=100.0%

 - model sliderCrankRigidBodies0: exec=1,diff=0

 - model sliderCrankRigidBodies1: exec=1,diff=0

 - model sliderCrankRigidBodies2: exec=1,diff=0

 - model sliderCrankRigidBodies3: exec=1,diff=0

 - model sliderCrankRigidBodies4: exec=1,diff=0

 - model sliderCrankRigidBodies5: exec=1,diff=0

 - model sliderCrankRigidBodies6: exec=1,diff=0

 - model sliderCrankRigidBodies7: exec=1,diff=0

 - model sliderCrankRigidBodies8: exec=1,diff=0

 - model sliderCrankRigidBodies9: exec=1,diff=0


SUMMARY model sliderCrankRigidBodies: exec=100.0%, correct=100.0%


***

numberOfTokensGlobal:112241, numberOfRemovedTokensGlobal:1163, tokensPerSecondGlobal:59.141453104811184


***


executable      = 95.43%
correct         = 77.71000000000001%
