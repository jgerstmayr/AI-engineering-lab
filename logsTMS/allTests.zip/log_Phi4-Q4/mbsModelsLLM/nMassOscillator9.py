# ** given model description: **
# A serial chain of 2 masses connected with springs-dampers. Each mass has
# m = 10 kg, the stiffnesses are k = 5000 N/m, and the damping coefficients
# are d = 50 Ns/m. A force f = 100 N is applied to the last mass (with highest
# index). The first mass is connected to ground via the first spring-damper. The
# relaxed length of each  spring is 0.5 m, and the first mass is located at x = 0.5
# m. The serial chain is oriented along the global x-axis. Gravity acts in positive
# x-direction, with g = 9.81 m/s^2.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

# First mass
oMass1 = mbs.CreateMassPoint(physicsMass=10, referencePosition=[0.5,0,0], 
                             initialDisplacement=[0,0,0],  
                             initialVelocity=[0,0,0],    
                             gravity=[9.81,0,0])         

# Spring-damper between ground and first mass
oSpringDamper1 = mbs.CreateSpringDamper(bodyNumbers=[oGround, oMass1], 
                                        localPosition0=[0,0,0], 
                                        localPosition1=[0,0,0], 
                                        referenceLength=0.5, 
                                        stiffness=5000, damping=50)

# Second mass
oMass2 = mbs.CreateMassPoint(physicsMass=10, referencePosition=[1.5,0,0], 
                             initialDisplacement=[0,0,0],  
                             initialVelocity=[0,0,0],    
                             gravity=[9.81,0,0])         

# Spring-damper between first and second mass
oSpringDamper2 = mbs.CreateSpringDamper(bodyNumbers=[oMass1, oMass2], 
                                        localPosition0=[0,0,0], 
                                        localPosition1=[0,0,0], 
                                        referenceLength=1.0, 
                                        stiffness=5000, damping=50)

# Apply force to the last mass
loadMassPoint = mbs.CreateForce(bodyNumber=oMass2, loadVector=[100,0,0])

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 1e-1
simulationSettings.solutionSettings.sensorsWritePeriod = 5e-3
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.1


#start solver:
mbs.SolveDynamic(simulationSettings)


