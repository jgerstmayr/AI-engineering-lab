# ** given model description: **
# Straight elastic chain modelled with 20 mass points connected with spring-dampers
# with the following properties: masses m = 5 kg, lengths  of each chain element
# l_single = 4 m, stiffness k = 2000.0 and damping d = 100.0 of chain elements, and
# gravity g = 9.81 m/s^2 which acts in negative y-direction. The chain starts from
# horizontal configuration, where all masses are aligned with the x-axis, the first
# mass located at x=0. The left-most and right-most spring-dampers are fixed to
# ground using spherical joints.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

# Initialize the first mass point at the origin
previous_mass = mbs.CreateMassPoint(physicsMass=5, referencePosition=[0,0,0], 
                                    initialDisplacement=[0,0,0], 
                                    initialVelocity=[0,0,0], 
                                    gravity=[0,-9.81,0])

# Create the rest of the mass points and connect them with spring-dampers
for i in range(1, 20):
    # Calculate the reference position for the current mass point
    reference_position = [i * 4, 0, 0]  # Each mass point is 4 meters apart on the x-axis

    # Create the current mass point
    current_mass = mbs.CreateMassPoint(physicsMass=5, referencePosition=reference_position, 
                                       initialDisplacement=[0,0,0], 
                                       initialVelocity=[0,0,0], 
                                       gravity=[0,-9.81,0])

    # Connect the current mass point with the previous one using a spring-damper
    mbs.CreateSpringDamper(bodyNumbers=[previous_mass, current_mass], 
                           localPosition0=[0,0,0], 
                           localPosition1=[0,0,0], 
                           referenceLength=4, 
                           stiffness=2000.0, 
                           damping=100.0)

    # Update the previous mass point to the current one for the next iteration
    previous_mass = current_mass

# Fix the left-most mass point to the ground
mbs.CreateSphericalJoint(bodyNumbers=[oGround, mbs.GetBody(1)], 
                         position=[0,0,0], 
                         constrainedAxes=[1,1,1])

# Fix the right-most mass point to the ground
mbs.CreateSphericalJoint(bodyNumbers=[oGround, mbs.GetBody(20)], 
                         position=[76,0,0],  # 19 * 4 = 76 meters from the origin
                         constrainedAxes=[1,1,1])

mbs.Assemble()

tEnd = 2
stepSize = 0.005

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 0.5
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.5
SC.visualizationSettings.nodes.tiling = 16
SC.visualizationSettings.connectors.defaultSize = 0.05 #spring


#start solver:
mbs.SolveDynamic(simulationSettings)


