# ** given model description: **
# A system consisting of a brick-shaped rigid body freely moving on a prismatic
# joint in x-direction. The COM of the rigid  body is placed at [0,0,0]. The rigid
# body has a mass of m = 10 kg and the side lengths of the body are all equal
# with s = 0.5 m. A force f = 20 N acts on the rigid body's COM in x-direction.
# Gravity is neglected.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

rbX = 0.5
rbY = 0.5
rbZ = 0.5

mass = 10  # kg
volume = rbX * rbY * rbZ
inertiaCube = InertiaCuboid(density=mass/volume, sideLengths=[rbX, rbY, rbZ])

oBody = mbs.CreateRigidBody(inertia=inertiaCube,
                           referencePosition=[0, 0, 0],
                           referenceRotationMatrix=RotationVector2RotationMatrix([0, 0, 0]),
                           initialAngularVelocity=[0, 0, 0],
                           initialVelocity=[0, 0, 0],
                           gravity=[0, 0, 0])

loadRigidBody = mbs.CreateForce(bodyNumber=oBody, localPosition=[0, 0, 0], loadVector=[20, 0, 0])

mbs.CreatePrismaticJoint(bodyNumbers=[oGround, oBody],
                         position=[0, 0, 0],
                         axis=[1, 0, 0],
                         useGlobalFrame=True)

mbs.Assemble()

tEnd = 1
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 5e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 5e-3
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=1
SC.visualizationSettings.openGL.lineWidth = 3


#start solver:
mbs.SolveDynamic(simulationSettings)


