# ** given model description: **
# Double pendulum modeled with brick-shape rigid bodies and revolute joints.
# Both bodies have density = 1000 kg/m^3, and xyz-dimensions lx=1.2 m, wy=0.4
# m, hz=0.2 m. The first body's  center is located initially at [lx/2,0,0] and
# the second body at [3*lx/2,0,0], both bodies having their COM locally at [0,0,0]
# (not translated). The first revolute joint between ground and body 1 is located
# at [0,0,0] (global coordinates), and the second revolute joint between body
# 1 and body 2 is located at [lx,0,0] (global coordinates). Both revolute joints'
# have a free rotation around the z-axis.Gravity g = 9.81 m/s^2 acts in negative
# y-direction, and no further force acts.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

lx, wy, hz = 1.2, 0.4, 0.2
density = 1000
volume = lx * wy * hz
mass = density * volume

inertiaCube1 = InertiaCuboid(density=density, sideLengths=[lx, wy, hz])
inertiaCube2 = InertiaCuboid(density=density, sideLengths=[lx, wy, hz])

oBody1 = mbs.CreateRigidBody(inertia=inertiaCube1,
                             referencePosition=[lx/2, 0, 0],
                             initialVelocity=[0, 0, 0],
                             initialAngularVelocity=[0, 0, 0],
                             gravity=[0, -9.81, 0])

oBody2 = mbs.CreateRigidBody(inertia=inertiaCube2,
                             referencePosition=[3*lx/2, 0, 0],
                             initialVelocity=[0, 0, 0],
                             initialAngularVelocity=[0, 0, 0],
                             gravity=[0, -9.81, 0])

mbs.CreateRevoluteJoint(bodyNumbers=[oGround, oBody1], 
                        position=[0, 0, 0], 
                        axis=[0, 0, 1], 
                        useGlobalFrame=True)

mbs.CreateRevoluteJoint(bodyNumbers=[oBody1, oBody2], 
                        position=[lx, 0, 0], 
                        axis=[0, 0, 1], 
                        useGlobalFrame=True)

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 1e-1
simulationSettings.solutionSettings.sensorsWritePeriod = 5e-3
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=1
SC.visualizationSettings.openGL.lineWidth = 3


#start solver:
mbs.SolveDynamic(simulationSettings)


