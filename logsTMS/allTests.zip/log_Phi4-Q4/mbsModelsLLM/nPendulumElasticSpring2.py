# ** given model description: **
# Multibody n-pendulum system consisting of 2 point masses connected with
# spring-dampers with the following  properties: masses m = 0.5 kg, lengths of single elastic
# strings l_single = 0.25 m, stiffness k = 1000.0 and damping d = 50.0 of strings,
# and gravity g = 9.81 m/s^2 which acts in negative y-direction. The pendulum
# starts from horizontal configuration, where all masses are aligned with the x-axis,
# the first mass located at x=0.25, with a spring-damper connected to ground.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

# First mass
oMass1 = mbs.CreateMassPoint(physicsMass=0.5, referencePosition=[0.25,0,0], 
                             initialDisplacement=[0,0,0],  
                             initialVelocity=[0,0,0],    
                             gravity=[0,-9.81,0])

# Spring-damper between ground and first mass
oSpringDamper1 = mbs.CreateSpringDamper(bodyNumbers=[oGround, oMass1], 
                                        localPosition0=[0,0,0], 
                                        localPosition1=[0,0,0], 
                                        referenceLength=0.25, 
                                        stiffness=1000.0, damping=50.0)

# Second mass
oMass2 = mbs.CreateMassPoint(physicsMass=0.5, referencePosition=[0.5,0,0], 
                             initialDisplacement=[0,0,0],  
                             initialVelocity=[0,0,0],    
                             gravity=[0,-9.81,0])

# Spring-damper between first and second mass
oSpringDamper2 = mbs.CreateSpringDamper(bodyNumbers=[oMass1, oMass2], 
                                        localPosition0=[0.25,0,0], 
                                        localPosition1=[0,0,0], 
                                        referenceLength=0.25, 
                                        stiffness=1000.0, damping=50.0)

mbs.Assemble()

tEnd = 0.5
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 5e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.06
SC.visualizationSettings.nodes.tiling = 16
SC.visualizationSettings.connectors.defaultSize = 0.02 #spring


#start solver:
mbs.SolveDynamic(simulationSettings)


