# ** given model description: **
# Double pendulum system consisting of two mass  points which are connected
# with inextensible strings with the following properties: mass m1 = 2 kg, mass
# m2 = 3 kg, length of the strings L1 = 0.8 m, L2 = 0.5 m, and gravity g = 9.81
# m/s^2 which acts in negative y-direction. The first arm of the pendulum points
# in positive x direction and the second arm in positive y-direction. The strings
# are massless, inelastic and the length shall be constrained. Air resistance
# is neglected.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

# First mass point
oMass1 = mbs.CreateMassPoint(physicsMass=2, referencePosition=[0.8,0,0], 
                             initialDisplacement=[0,0,0],  
                             initialVelocity=[0,0,0],    
                             gravity=[0,-9.81,0])

# Second mass point
oMass2 = mbs.CreateMassPoint(physicsMass=3, referencePosition=[0.8,0.5,0], 
                             initialDisplacement=[0,0,0],  
                             initialVelocity=[0,0,0],    
                             gravity=[0,-9.81,0])

# Distance constraints
oDistance1 = mbs.CreateDistanceConstraint(bodyNumbers=[oGround, oMass1], 
                                         localPosition0=[0,0,0], 
                                         localPosition1=[0,0,0], 
                                         distance=0.8)

oDistance2 = mbs.CreateDistanceConstraint(bodyNumbers=[oMass1, oMass2], 
                                         localPosition0=[0,0,0], 
                                         localPosition1=[0,0,0], 
                                         distance=0.5)

mbs.Assemble()

tEnd = 1
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 1e-1
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.05
SC.visualizationSettings.nodes.tiling = 32


#start solver:
mbs.SolveDynamic(simulationSettings)


