# ** given model description: **
# Straight elastic chain modelled with 20 mass points connected with spring-dampers
# with the following properties: masses m = 5 kg, lengths of each chain element
# l_single = 4 m, stiffness k = 2000.0 and damping d = 100.0 of chain elements, and
# gravity g = 9.81 m/s^2 which acts in negative y-direction. The chain starts from
# horizontal configuration, where all masses are aligned  with the x-axis, the first
# mass located at x=0. The left-most and right-most spring-dampers are fixed to
# ground using spherical joints.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

# Initialize the first mass point
previous_mass = mbs.CreateMassPoint(physicsMass=5, referencePosition=[0,0,0], 
                                    initialDisplacement=[0,0,0], 
                                    initialVelocity=[0,0,0], 
                                    gravity=[0,-9.81,0])

# Create the rest of the mass points and connect them with spring-dampers
for i in range(1, 20):
    current_position = [i * 4, 0, 0]  # Each mass point is 4 meters apart
    current_mass = mbs.CreateMassPoint(physicsMass=5, referencePosition=current_position, 
                                       initialDisplacement=[0,0,0], 
                                       initialVelocity=[0,0,0], 
                                       gravity=[0,-9.81,0])
    mbs.CreateSpringDamper(bodyNumbers=[previous_mass, current_mass], 
                           localPosition0=[0,0,0], 
                           localPosition1=[0,0,0], 
                           referenceLength=4, 
                           stiffness=2000.0, 
                           damping=100.0)
    previous_mass = current_mass

# Fix the left-most and right-most spring-dampers to the ground
mbs.CreateSphericalJoint(bodyNumbers=[oGround, previous_mass], 
                         position=[0,0,0], 
                         constrainedAxes=[1,1,1])
mbs.CreateSphericalJoint(bodyNumbers=[oGround, current_mass], 
                         position=[19 * 4, 0, 0], 
                         constrainedAxes=[1,1,1])

mbs.Assemble()

tEnd = 2
stepSize = 0.005

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 0.5
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.5
SC.visualizationSettings.nodes.tiling = 16
SC.visualizationSettings.connectors.defaultSize = 0.05 #spring


#start solver:
mbs.SolveDynamic(simulationSettings)


