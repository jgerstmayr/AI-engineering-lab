# ** given model description: **
# Pendulum modeled with a brick-shape rigid body and a revolute joint. The
# body has density = 1000 kg/m^3, and xyz-dimensions lx=1.2m, wy=0.4m, hz=0.2m.
# The center of mass is equal to the reference point and initially located at
# [lx/2,0,0], while the revolute joint (rotation around z-axis) is located at [0,0,0]
# (global coordinates). Gravity g = 9.81 m/s^2 acts in negative y-direction, and
# no further  force acts.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

lx, wy, hz = 1.2, 0.4, 0.2
density = 1000
volume = lx * wy * hz
mass = density * volume
inertiaCube = InertiaCuboid(density=density, sideLengths=[lx, wy, hz])

oBody = mbs.CreateRigidBody(inertia=inertiaCube,
                            referencePosition=[lx/2, 0, 0],
                            initialVelocity=[0, 0, 0],
                            initialAngularVelocity=[0, 0, 0],
                            gravity=[0, -9.81, 0])

mbs.CreateRevoluteJoint(bodyNumbers=[oBody, oGround], 
                        position=[0, 0, 0], 
                        axis=[0, 0, 1], 
                        useGlobalFrame=True)

mbs.Assemble()

tEnd = 1
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 5e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 5e-3
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=1
SC.visualizationSettings.openGL.lineWidth = 3


#start solver:
mbs.SolveDynamic(simulationSettings)


