# ** given model description: **
# A slider-crank mechanism is given with a crank rotating about the z-axis.
# The crank is modelled as rigid body with cylinder shape (axis=z) with mass
# m = 2 kg, radius r = 0.25 m, and width = 0.1 m, and it is initially located
# at [0,0,-0.1]. The brick-shaped conrod and piston have identical parameters:
# density =  7850 kg/m^3, and xyz-dimensions lx=0.4 m, wy=0.05 m, hz=0.05 m, initially
# not rotated (straight configuration of slider-crank). The conrod's center is
# located initially at [r+0.5*lx,0,0] and the piston is initially located at [r+1.5*lx,0,0].
# A torque [0,0,T] shall act on the crank, employing a user-function with T=2
# Nm until 1 s and 0 thereafter. The revolute joint between ground and crank
# is located at [0,0,0] (global coordinates), the revolute joint between crank
# and conrod is located at [r,0,0] (global coordinates), and the revolute joint
# between conrod and piston is located at [r+lx,0,0] (global coordinates). The prismatic
# joint (axis=x) between ground and piston is located at [r+1.5*lx,0,0] (global
# coordinates). No gravity acts on the system. Simulate the system for 2 s.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

mass = 2
outerRadius = 0.25
length = 0.1
volume = np.pi * outerRadius**2 * length
inertiaCylinder = InertiaCylinder(density=mass/volume, length=length, outerRadius=outerRadius, axis=2)

oCrank = mbs.CreateRigidBody(inertia=inertiaCylinder,
                             referencePosition=[0,0,-0.1],
                             initialVelocity=[0,0,0],
                             initialAngularVelocity=[0,0,0])

density = 7850
lx = 0.4
wy = 0.05
hz = 0.05
volume = lx * wy * hz
mass = density * volume
inertiaCube = InertiaCuboid(density=density, sideLengths=[lx, wy, hz])

oConrod = mbs.CreateRigidBody(inertia=inertiaCube,
                              referencePosition=[outerRadius+0.5*lx,0,0],
                              initialVelocity=[0,0,0],
                              initialAngularVelocity=[0,0,0])

oPiston = mbs.CreateRigidBody(inertia=inertiaCube,
                              referencePosition=[outerRadius+1.5*lx,0,0],
                              initialVelocity=[0,0,0],
                              initialAngularVelocity=[0,0,0])

def UserFunctionTorque(mbs, t, loadVector):
    return np.array([0, 0, 2 if t <= 1 else 0])

mbs.CreateTorque(bodyNumber=oCrank, loadVector=[0,0,0], 
                 loadVectorUserFunction=UserFunctionTorque)

mbs.CreateRevoluteJoint(bodyNumbers=[oGround, oCrank], 
                        position=[0,0,0], 
                        axis=[0,0,1], 
                        useGlobalFrame=True)

mbs.CreateRevoluteJoint(bodyNumbers=[oCrank, oConrod], 
                        position=[outerRadius,0,0], 
                        axis=[0,0,1], 
                        useGlobalFrame=True)

mbs.CreateRevoluteJoint(bodyNumbers=[oConrod, oPiston], 
                        position=[outerRadius+lx,0,0], 
                        axis=[0,0,1], 
                        useGlobalFrame=True)

mbs.CreatePrismaticJoint(bodyNumbers=[oGround, oPiston], 
                         position=[outerRadius+1.5*lx,0,0], 
                         axis=[1,0,0], 
                         useGlobalFrame=True)

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 1e-1
simulationSettings.solutionSettings.sensorsWritePeriod = 5e-3
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd
# simulationSettings.timeIntegration.verboseMode = 1

simulationSettings.linearSolverSettings.ignoreSingularJacobian = True
simulationSettings.linearSolverType = exu.LinearSolverType.EigenDense

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=1
SC.visualizationSettings.openGL.lineWidth = 3


#start solver:
mbs.SolveDynamic(simulationSettings)


