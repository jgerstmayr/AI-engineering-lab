# ** given model description: **
# Rolling motion of a solid disc rolling on a x/y plane with the following
# properties: mass m = 4 kg, radius r = 0.3 m, width w = 0.05 m, and gravity g = 9.81
# m/s^2 (in negative z-direction). The disc's axis  is initially aligned with the
# x-axis. The COM of the disc has an initial position of p0 = [1,1,0.3], translational
# velocity of v_y = 1 m/s and an initial angular velocity omega_x=-v_y/radius. Rolling
# shall be modelled ideal and without slipping.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

mass = 4
radius = 0.3
width = 0.05
volume = np.pi * radius**2 * width
inertiaCylinder = InertiaCylinder(density=mass/volume, length=width, outerRadius=radius, axis=0)

oDisc = mbs.CreateRigidBody(inertia=inertiaCylinder,
                            referencePosition=[1,1,0.3],
                            initialVelocity=[0,1,0],
                            initialAngularVelocity=[-1/radius,0,0],
                            gravity=[0,0,-9.81])

mbs.CreateRollingDisc(bodyNumbers=[oGround, oDisc], discRadius=radius, 
                      axisPosition=[0,0,0], axisVector=[1,0,0],
                      planePosition=[0,0,0], planeNormal=[0,0,1],
                      constrainedAxes=[1,1,1])

mbs.Assemble()

tEnd = 1
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 5e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 5e-3
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=1
SC.visualizationSettings.openGL.lineWidth = 2


#start solver:
mbs.SolveDynamic(simulationSettings)


