# ** given model description: **
# A rigid body is suspended by 4 Cartesian spring-dampers. The rigid body
# has a brick-shape with density = 400 kg/m^3, and xyz-dimensions lx=4m, ly=0.75m,
# lz=1.5m. The reference point of the body, which is equal to the COM, is located
# initially at [0,0.75/2,0]. The Cartesian spring-dampers are located at the x/z positions
# of the vertices of the body. The y-local-position of the spring-dampers at
#  the body is -0.75/2 and the local position for ground is y=0. All spring-dampers
# have equal parameters: stiffness = [10000,100000,10000] N/m and damping = [200,2000,200]
# Ns/m. Gravity g = 9.81 m/s^2 acts in negative y-direction, and no further forces
# or damping are applied and contact with ground is ignored.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

# Define the brick-shaped rigid body
density = 400  # kg/m^3
lx, ly, lz = 4, 0.75, 1.5
volume = lx * ly * lz
mass = density * volume
inertiaCube = InertiaCuboid(density=density, sideLengths=[lx, ly, lz])
inertiaCube = inertiaCube.Translated([lx/2, 0, lz/2])  # Translate COM to origin

oBody = mbs.CreateRigidBody(inertia=inertiaCube,
                            referencePosition=[0, ly/2, 0],
                            referenceRotationMatrix=RotationVector2RotationMatrix([0, 0, 0]),
                            initialAngularVelocity=[0, 0, 0],
                            initialVelocity=[0, 0, 0],
                            gravity=[0, -9.81, 0])

# Define Cartesian spring-dampers
stiffness = [10000, 100000, 10000]
damping = [200, 2000, 200]
localPositionsBody = [[lx/2, -ly/2, lz/2], [-lx/2, -ly/2, lz/2], [lx/2, -ly/2, -lz/2], [-lx/2, -ly/2, -lz/2]]
localPositionsGround = [[lx/2, 0, lz/2], [-lx/2, 0, lz/2], [lx/2, 0, -lz/2], [-lx/2, 0, -lz/2]]

for localPosBody, localPosGround in zip(localPositionsBody, localPositionsGround):
    mbs.CreateCartesianSpringDamper(
        bodyNumbers=[oGround, oBody],
        localPosition0=localPosGround,
        localPosition1=localPosBody,
        stiffness=stiffness,
        damping=damping
    )

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 5e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 5e-3
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=1
SC.visualizationSettings.openGL.lineWidth = 3

#start solver:
mbs.SolveDynamic(simulationSettings)

