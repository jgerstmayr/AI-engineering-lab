# ** given model description: **
# An inverted pendulum on a cart modelled  with two mass points, where the
# cart is attached to ground with a spherical joint where the x-coordinate is
# not constrained, such that it can move along the x-direction. The pendulum
# is modelled with a distance constraint between cart and pendulum mass: cart
# mass m1 = 4 kg, pendulum mass m2 = 0.5 kg, pendulum length = 0.8 m, and gravity
# g = 9.81 m/s^2 which acts in negative y-direction. The pendulum starts from
# the upright position, where m2 is located at the positive y-axis. A disturbance
# force f = 0.1 N acts in x-direction at the pendulum and no control is applied
# on the cart.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

# Cart mass point
oCart = mbs.CreateMassPoint(physicsMass=4, referencePosition=[0,0,0], 
                            initialDisplacement=[0,0,0],  
                            initialVelocity=[0,0,0],    
                            gravity=[0,-9.81,0])         

# Spherical joint for cart, allowing movement in x-direction
mbs.CreateSphericalJoint(bodyNumbers=[oGround, oCart],
                         position=[0,0,0], 
                         constrainedAxes=[0,1,1]) 

# Pendulum mass point
oPendulum = mbs.CreateMassPoint(physicsMass=0.5, referencePosition=[0,0.8,0], 
                                initialDisplacement=[0,0,0],  
                                initialVelocity=[0,0,0],    
                                gravity=[0,-9.81,0])         

# Distance constraint for pendulum
mbs.CreateDistanceConstraint(bodyNumbers=[oCart, oPendulum], 
                             localPosition0=[0,0,0], 
                             localPosition1=[0,0,0], 
                             distance=0.8)

# Disturbance force on pendulum
mbs.CreateForce(bodyNumber=oPendulum, loadVector=[0.1,0,0])

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 1e-1
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.05
SC.visualizationSettings.nodes.tiling = 32
SC.visualizationSettings.openGL.lineWidth = 3


#start solver:
mbs.SolveDynamic(simulationSettings)


