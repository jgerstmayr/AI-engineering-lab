# ** given model description: **
# Two free flying rigid elements, each modeled as a rigid body with brick-shape
# (density = 1000 kg/m^3, lx=1.0 m, wy=0.2 m, hz=0.1 m). Rigid body 1 is globally
#  placed at [lx/2,0,0] and rigid body 2 at [3*lx/2,0,0], both bodies' COMs
# being at their origin. A Cartesian spring-damper with stiffness [20000.0,20000.0,20000.0]
# N/m and damping [100.0,100.0,100.0] Ns/m is attached between rigid body 1 at
# [lx/2,0,0] (local position) and rigid body 2 at [-lx/2,0,0] (also local position).
# Body1 has initial velocity [0,4.0,0] and body2 has initial velocity [0,-4.0,0]
# and gravity is zero.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

density = 1000  # kg/m^3
lx = 1.0  # m
wy = 0.2  # m
hz = 0.1  # m
volume = lx * wy * hz
mass = density * volume

inertiaCube = InertiaCuboid(density=density, sideLengths=[lx, wy, hz])

oBody1 = mbs.CreateRigidBody(inertia=inertiaCube,
                             referencePosition=[lx/2, 0, 0],
                             referenceRotationMatrix=RotationVector2RotationMatrix([0, 0, 0]),
                             initialAngularVelocity=[0, 0, 0],
                             initialVelocity=[0, 4.0, 0],
                             gravity=[0, 0, 0])

oBody2 = mbs.CreateRigidBody(inertia=inertiaCube,
                             referencePosition=[3*lx/2, 0, 0],
                             referenceRotationMatrix=RotationVector2RotationMatrix([0, 0, 0]),
                             initialAngularVelocity=[0, 0, 0],
                             initialVelocity=[0, -4.0, 0],
                             gravity=[0, 0, 0])

mbs.CreateCartesianSpringDamper(
    bodyNumbers=[oBody1, oBody2],
    localPosition0=[lx/2, 0, 0],
    localPosition1=[-lx/2, 0, 0],
    stiffness=[20000.0, 20000.0, 20000.0],
    damping=[100.0, 100.0, 100.0],
)

mbs.Assemble()

tEnd = 2
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 1e-1
simulationSettings.solutionSettings.sensorsWritePeriod = 5e-3
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=1
SC.visualizationSettings.openGL.lineWidth = 3


#start solver:
mbs.SolveDynamic(simulationSettings)


