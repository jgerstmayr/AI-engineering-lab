# ** given model description: **
# Straight elastic chain modelled with 20 mass points connected with spring-dampers
# with the following properties: masses m = 5 kg, lengths of each chain element
# l_single = 4 m, stiffness k = 2000.0 and damping  d = 100.0 of chain elements, and
# gravity g = 9.81 m/s^2 which acts in negative y-direction. The chain starts from
# horizontal configuration, where all masses are aligned with the x-axis, the first
# mass located at x=0. The left-most and right-most spring-dampers are fixed to
# ground using spherical joints.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

# Create 20 mass points
mass_points = []
for i in range(20):
    position = [i * 4, 0, 0]  # Each mass point is 4 meters apart on the x-axis
    mass_points.append(mbs.CreateMassPoint(physicsMass=5, referencePosition=position, 
                                          initialDisplacement=[0,0,0], 
                                          initialVelocity=[0,0,0], 
                                          gravity=[0,-9.81,0]))

# Connect mass points with spring-dampers
for i in range(19):
    mbs.CreateSpringDamper(bodyNumbers=[mass_points[i], mass_points[i+1]], 
                           localPosition0=[0,0,0], 
                           localPosition1=[4,0,0], 
                           referenceLength=4, 
                           stiffness=2000.0, 
                           damping=100.0)

# Fix the left-most and right-most mass points to the ground
mbs.CreateSphericalJoint(bodyNumbers=[oGround, mass_points[0]], 
                         position=[0,0,0], 
                         constrainedAxes=[1,1,1])
mbs.CreateSphericalJoint(bodyNumbers=[oGround, mass_points[19]], 
                         position=[76,0,0], 
                         constrainedAxes=[1,1,1])

mbs.Assemble()

tEnd = 2
stepSize = 0.005

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 0.5
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.5
SC.visualizationSettings.nodes.tiling = 16
SC.visualizationSettings.connectors.defaultSize = 0.05 #spring


#start solver:
mbs.SolveDynamic(simulationSettings)


