# ** given model description: **
# Simple slider-crank mechanism modelled with two mass points that are connected
# with distance constraints. The crank is modelled with a point mass m1 = 0.5
# kg, located at radius r = 0.5 m (initially located at x=0, y=r) and constrained
# to ground  with a distance r; the slider is a point mass m2 = 2 kg, initially
# located at xSlider = 2 m and ySlider = 0. The connecting rod is only represented
# as distance constraint between crank mass and slider mass. Add a spherical
# joint between mass 1 and ground and only constrain the z-axis motion and a second
# spherical joint to constrain the y- and z-axes motion of mass 2. A force fx = 10
# acts on the slider in positive x-direction. The system is initially at rest,
# and no gravity is applied.
import exudyn as exu
from exudyn.utilities import *
import numpy as np

SC = exu.SystemContainer()
mbs = SC.AddSystem()

oGround = mbs.CreateGround(referencePosition=[0,0,0])

oCrank = mbs.CreateMassPoint(physicsMass=0.5, referencePosition=[0,0.5,0], 
                             initialDisplacement=[0,0,0], 
                             initialVelocity=[0,0,0])

oSlider = mbs.CreateMassPoint(physicsMass=2, referencePosition=[2,0,0], 
                              initialDisplacement=[0,0,0], 
                              initialVelocity=[0,0,0])

mbs.CreateDistanceConstraint(bodyNumbers=[oCrank, oSlider], 
                             localPosition0=[0,0,0], 
                             localPosition1=[0,0,0], 
                             distance=0.5)

mbs.CreateSphericalJoint(bodyNumbers=[oGround, oCrank], 
                         position=[0,0.5,0], 
                         constrainedAxes=[0,0,1])

mbs.CreateSphericalJoint(bodyNumbers=[oGround, oSlider], 
                         position=[2,0,0], 
                         constrainedAxes=[0,1,1])

loadSlider = mbs.CreateForce(bodyNumber=oSlider, loadVector=[10,0,0])

mbs.Assemble()

tEnd = 1
stepSize = 0.001

simulationSettings = exu.SimulationSettings()
simulationSettings.solutionSettings.solutionWritePeriod = 5e-2
simulationSettings.solutionSettings.sensorsWritePeriod = 1e-2
simulationSettings.timeIntegration.numberOfSteps = int(tEnd/stepSize) #must be integer
simulationSettings.timeIntegration.endTime = tEnd

SC.visualizationSettings.nodes.drawNodesAsPoint=False
SC.visualizationSettings.nodes.defaultSize=0.05
SC.visualizationSettings.nodes.tiling = 32


#start solver:
mbs.SolveDynamic(simulationSettings)


