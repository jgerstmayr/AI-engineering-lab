EvaluateLevenshtein: Found 10 .py files for comparison.
Evaluating normalized Levenshtein distances between model files...
Visualizing Levenshtein distance matrix...
Visualization of Levenshtein Distances Matrix saved to: ../../01_paper/figures/HFtransformerslevenstheinDistance.pdf
Total comparisons: 45
Threshold = 0.00
Pairs with distance < lower: 0.0 (0.00%)
Pairs with distance > upper: 0.0 (100.00%)
