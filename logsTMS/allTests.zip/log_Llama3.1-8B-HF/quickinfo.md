
***

RunMBSmodelTests: using LLM model: meta-llama/Llama-3.1-8B-Instruct

***

Creating simulation code for mbs models: ['freeFallMassPoint']

***

RunMBSmodelTests: using Exudyn version: 1.9.83.dev1

***

Do space variation with factor: 7

***

Creating simulation code for freeFallMassPoint; spaceVar ID0 / 10; model ID0 / 1

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; spaceVar ID1 / 10; model ID0 / 1

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; spaceVar ID2 / 10; model ID0 / 1; time to go=70.26s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; spaceVar ID3 / 10; model ID0 / 1; time to go=60.94s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; spaceVar ID4 / 10; model ID0 / 1; time to go=52.02s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; spaceVar ID5 / 10; model ID0 / 1; time to go=43.24s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; spaceVar ID6 / 10; model ID0 / 1; time to go=34.53s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; spaceVar ID7 / 10; model ID0 / 1; time to go=25.86s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; spaceVar ID8 / 10; model ID0 / 1; time to go=17.22s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; spaceVar ID9 / 10; model ID0 / 1; time to go=8.6s

***

 - executable=True, diff=0
**FINAL TEST RESULTS** 
 - freeFallMassPoint0: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint1: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint2: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint3: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint4: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint5: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint6: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint7: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint8: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint9: 

   + executable: True

   + diff: 0.0

 - model freeFallMassPoint0: exec=1,diff=0

 - model freeFallMassPoint1: exec=1,diff=0

 - model freeFallMassPoint2: exec=1,diff=0

 - model freeFallMassPoint3: exec=1,diff=0

 - model freeFallMassPoint4: exec=1,diff=0

 - model freeFallMassPoint5: exec=1,diff=0

 - model freeFallMassPoint6: exec=1,diff=0

 - model freeFallMassPoint7: exec=1,diff=0

 - model freeFallMassPoint8: exec=1,diff=0

 - model freeFallMassPoint9: exec=1,diff=0


SUMMARY model freeFallMassPoint: exec=100.0%, correct=100.0%


***

numberOfTokensGlobal:2335, numberOfRemovedTokensGlobal:0, tokensPerSecondGlobal:27.191637388463427


***


executable      = 100.0%
correct         = 100.0%
