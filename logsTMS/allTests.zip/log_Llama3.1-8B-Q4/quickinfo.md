
***

RunMBSmodelTests: using LLM model: Meta-Llama-3.1-8B-Instruct-128k-Q4_0.gguf

***

Creating simulation code for mbs models: ['freeFallMassPoint']

***

RunMBSmodelTests: using Exudyn version: 1.9.83.dev1

***

Do space variation with factor: 7

***

Creating simulation code for freeFallMassPoint; spaceVar ID0 / 10; model ID0 / 1

***

 - executable=True, diff=319.745

***

Creating simulation code for freeFallMassPoint; spaceVar ID1 / 10; model ID0 / 1; time to go=1.07hours

***

 - executable=True, diff=319.745

***

Creating simulation code for freeFallMassPoint; spaceVar ID2 / 10; model ID0 / 1; time to go=3424.73s

***

 - executable=True, diff=319.745

***

Creating simulation code for freeFallMassPoint; spaceVar ID3 / 10; model ID0 / 1; time to go=2786.83s

***

 - executable=True, diff=0

***

Creating simulation code for freeFallMassPoint; spaceVar ID4 / 10; model ID0 / 1; time to go=2203.48s

***

 - executable=True, diff=319.745

***

Creating simulation code for freeFallMassPoint; spaceVar ID5 / 10; model ID0 / 1; time to go=1737.21s

***

 - executable=True, diff=319.745

***

Creating simulation code for freeFallMassPoint; spaceVar ID6 / 10; model ID0 / 1; time to go=1357.48s

***

 - executable=True, diff=319.745

***

Creating simulation code for freeFallMassPoint; spaceVar ID7 / 10; model ID0 / 1; time to go=977.31s

***

 - executable=True, diff=319.745

***

Creating simulation code for freeFallMassPoint; spaceVar ID8 / 10; model ID0 / 1; time to go=648.49s

***

 - executable=True, diff=319.745

***

Creating simulation code for freeFallMassPoint; spaceVar ID9 / 10; model ID0 / 1; time to go=323.0s

***

 - executable=True, diff=319.745
**FINAL TEST RESULTS** 
 - freeFallMassPoint0: 

   + executable: True

   + diff: 319.74480702396426

 - freeFallMassPoint1: 

   + executable: True

   + diff: 319.74480702396426

 - freeFallMassPoint2: 

   + executable: True

   + diff: 319.74480702396426

 - freeFallMassPoint3: 

   + executable: True

   + diff: 0.0

 - freeFallMassPoint4: 

   + executable: True

   + diff: 319.74480702396426

 - freeFallMassPoint5: 

   + executable: True

   + diff: 319.74480702396426

 - freeFallMassPoint6: 

   + executable: True

   + diff: 319.74480702396426

 - freeFallMassPoint7: 

   + executable: True

   + diff: 319.74480702396426

 - freeFallMassPoint8: 

   + executable: True

   + diff: 319.74480702396426

 - freeFallMassPoint9: 

   + executable: True

   + diff: 319.74480702396426

 - model freeFallMassPoint0: exec=1,diff=319.745

 - model freeFallMassPoint1: exec=1,diff=319.745

 - model freeFallMassPoint2: exec=1,diff=319.745

 - model freeFallMassPoint3: exec=1,diff=0

 - model freeFallMassPoint4: exec=1,diff=319.745

 - model freeFallMassPoint5: exec=1,diff=319.745

 - model freeFallMassPoint6: exec=1,diff=319.745

 - model freeFallMassPoint7: exec=1,diff=319.745

 - model freeFallMassPoint8: exec=1,diff=319.745

 - model freeFallMassPoint9: exec=1,diff=319.745


SUMMARY model freeFallMassPoint: exec=100.0%, correct=10.0%


***

numberOfTokensGlobal:2370, numberOfRemovedTokensGlobal:0, tokensPerSecondGlobal:0.7359903514811079


***


executable      = 100.0%
correct         = 10.0%
