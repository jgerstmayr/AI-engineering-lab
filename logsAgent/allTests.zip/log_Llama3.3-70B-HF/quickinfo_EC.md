
***

Evaluate conjectures: nModels=70, nConjPerModel=8, LLM model=meta-llama/Llama-3.3-70B-Instruct

***

EvaluateAllConjectures flyingMassPoint0: model ID0 / 35 (random ID0 / 2)


 - Evaluation for flyingMassPoint0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint0c3: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint0c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint0c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint0c7: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for flyingMassPoint0:
  scoreConjectureCorrectModels=1.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=1.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingMassPoint1: model ID0 / 35 (random ID1 / 2); time to go=9.28hours


 - Evaluation for flyingMassPoint1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint1c3: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint1c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.99

 - Evaluation for flyingMassPoint1c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for flyingMassPoint1:
  scoreConjectureCorrectModels=0.99875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.99874,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures freeFallMassPoint0: model ID1 / 35 (random ID0 / 2); time to go=8.51hours


 - Evaluation for freeFallMassPoint0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for freeFallMassPoint0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for freeFallMassPoint0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for freeFallMassPoint0c3: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for freeFallMassPoint0c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for freeFallMassPoint0c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for freeFallMassPoint0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for freeFallMassPoint0:
  scoreConjectureCorrectModels=0.94,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.92694,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures freeFallMassPoint1: model ID1 / 35 (random ID1 / 2); time to go=7.63hours


 - Evaluation for freeFallMassPoint1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for freeFallMassPoint1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for freeFallMassPoint1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for freeFallMassPoint1c3: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for freeFallMassPoint1c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for freeFallMassPoint1c5: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for freeFallMassPoint1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for freeFallMassPoint1:
  scoreConjectureCorrectModels=1.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=1.0,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures singleMassOscillator0: model ID2 / 35 (random ID0 / 2); time to go=7.08hours


 - Evaluation for singleMassOscillator0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singleMassOscillator0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singleMassOscillator0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singleMassOscillator0c3: method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillator0c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillator0c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillator0c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for singleMassOscillator0c7: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for singleMassOscillator0:
  scoreConjectureCorrectModels=0.96,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.95884,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillator1: model ID2 / 35 (random ID1 / 2); time to go=7.42hours


 - Evaluation for singleMassOscillator1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singleMassOscillator1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singleMassOscillator1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for singleMassOscillator1c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillator1c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singleMassOscillator1c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singleMassOscillator1c7: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for singleMassOscillator1:
  scoreConjectureCorrectModels=0.87143,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.86223,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorGravity0: model ID3 / 35 (random ID0 / 2); time to go=7.4hours


 - Evaluation for singleMassOscillatorGravity0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singleMassOscillatorGravity0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillatorGravity0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillatorGravity0c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for singleMassOscillatorGravity0c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singleMassOscillatorGravity0c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillatorGravity0c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.6


Evaluation summary for singleMassOscillatorGravity0:
  scoreConjectureCorrectModels=0.82571,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.81742,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorGravity1: model ID3 / 35 (random ID1 / 2); time to go=7.48hours


 - Evaluation for singleMassOscillatorGravity1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillatorGravity1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillatorGravity1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillatorGravity1c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillatorGravity1c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillatorGravity1c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singleMassOscillatorGravity1c7: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for singleMassOscillatorGravity1:
  scoreConjectureCorrectModels=0.87143,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.86713,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankSimple0: model ID4 / 35 (random ID0 / 2); time to go=7.43hours



Evaluation summary for sliderCrankSimple0:
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankSimple1: model ID4 / 35 (random ID1 / 2); time to go=6.5hours


 - Evaluation for sliderCrankSimple1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for sliderCrankSimple1:
  scoreConjectureCorrectModels=0.8,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.8,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumElasticSpring0: model ID5 / 35 (random ID0 / 2); time to go=5.85hours


 - Evaluation for singlePendulumElasticSpring0c0: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for singlePendulumElasticSpring0c1: method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for singlePendulumElasticSpring0c2: method=Check if planar motion, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for singlePendulumElasticSpring0c3: method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for singlePendulumElasticSpring0c4: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for singlePendulumElasticSpring0c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for singlePendulumElasticSpring0c6: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for singlePendulumElasticSpring0c7: method=Evaluate symmetry, modelIsCorrect=False, scoreValue=0.8


Evaluation summary for singlePendulumElasticSpring0:
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.85
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.84721


***

EvaluateAllConjectures singlePendulumElasticSpring1: model ID5 / 35 (random ID1 / 2); time to go=5.95hours


 - Evaluation for singlePendulumElasticSpring1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulumElasticSpring1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singlePendulumElasticSpring1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singlePendulumElasticSpring1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singlePendulumElasticSpring1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singlePendulumElasticSpring1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumElasticSpring1c6: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for singlePendulumElasticSpring1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for singlePendulumElasticSpring1:
  scoreConjectureCorrectModels=0.75714,  scoreConjectureWrongModels=0.8
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.8


***

EvaluateAllConjectures singleMassOscillatorUserFunction0: model ID6 / 35 (random ID0 / 2); time to go=5.99hours


 - Evaluation for singleMassOscillatorUserFunction0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singleMassOscillatorUserFunction0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillatorUserFunction0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillatorUserFunction0c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillatorUserFunction0c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for singleMassOscillatorUserFunction0c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillatorUserFunction0c7: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for singleMassOscillatorUserFunction0:
  scoreConjectureCorrectModels=0.98286,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.98222,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorUserFunction1: model ID6 / 35 (random ID1 / 2); time to go=5.95hours


 - Evaluation for singleMassOscillatorUserFunction1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for singleMassOscillatorUserFunction1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singleMassOscillatorUserFunction1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillatorUserFunction1c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillatorUserFunction1c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillatorUserFunction1c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singleMassOscillatorUserFunction1c7: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for singleMassOscillatorUserFunction1:
  scoreConjectureCorrectModels=0.87857,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.86738,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures spinningDisc0: model ID7 / 35 (random ID0 / 2); time to go=6.0hours


 - Evaluation for spinningDisc0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc0c1: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc0c2: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc0c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc0c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc0c6: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc0c7: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for spinningDisc0:
  scoreConjectureCorrectModels=0.85714,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures spinningDisc1: model ID7 / 35 (random ID1 / 2); time to go=5.92hours


 - Evaluation for spinningDisc1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc1c1: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc1c2: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc1c3: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for spinningDisc1c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc1c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc1c6: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc1c7: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for spinningDisc1:
  scoreConjectureCorrectModels=0.7875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doubleMassOscillator0: model ID8 / 35 (random ID0 / 2); time to go=5.89hours


 - Evaluation for doubleMassOscillator0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for doubleMassOscillator0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doubleMassOscillator0c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doubleMassOscillator0c4: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doubleMassOscillator0c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doubleMassOscillator0c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doubleMassOscillator0c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for doubleMassOscillator0:
  scoreConjectureCorrectModels=0.78571,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.7126,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doubleMassOscillator1: model ID8 / 35 (random ID1 / 2); time to go=5.88hours


 - Evaluation for doubleMassOscillator1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doubleMassOscillator1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doubleMassOscillator1c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doubleMassOscillator1c4: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doubleMassOscillator1c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doubleMassOscillator1c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doubleMassOscillator1c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for doubleMassOscillator1:
  scoreConjectureCorrectModels=0.88571,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.88341,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nMassOscillator0: model ID9 / 35 (random ID0 / 2); time to go=5.81hours


 - Evaluation for nMassOscillator0c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for nMassOscillator0c2: method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.6

 - Evaluation for nMassOscillator0c3: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.6

 - Evaluation for nMassOscillator0c4: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for nMassOscillator0c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for nMassOscillator0c6: method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for nMassOscillator0c7: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.8


Evaluation summary for nMassOscillator0:
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.75714
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.74938


***

EvaluateAllConjectures nMassOscillator1: model ID9 / 35 (random ID1 / 2); time to go=5.72hours


 - Evaluation for nMassOscillator1c0: method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for nMassOscillator1c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for nMassOscillator1c2: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for nMassOscillator1c3: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for nMassOscillator1c4: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for nMassOscillator1c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for nMassOscillator1c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for nMassOscillator1c7: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for nMassOscillator1:
  scoreConjectureCorrectModels=0.76667,  scoreConjectureWrongModels=0.45
  multScoreConjectureCorrectModels=0.68683,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures singlePendulum0: model ID10 / 35 (random ID0 / 2); time to go=5.74hours


 - Evaluation for singlePendulum0c0: method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for singlePendulum0c1: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for singlePendulum0c2: method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for singlePendulum0c3: method=Check if planar motion, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for singlePendulum0c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singlePendulum0c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for singlePendulum0c6: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for singlePendulum0c7: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.9


Evaluation summary for singlePendulum0:
  scoreConjectureCorrectModels=0.99,  scoreConjectureWrongModels=0.88333
  multScoreConjectureCorrectModels=0.98995,  multScoreConjectureWrongModels=0.88068


***

EvaluateAllConjectures singlePendulum1: model ID10 / 35 (random ID1 / 2); time to go=5.69hours


 - Evaluation for singlePendulum1c1: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulum1c2: method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for singlePendulum1c3: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singlePendulum1c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singlePendulum1c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singlePendulum1c6: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulum1c7: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.8


Evaluation summary for singlePendulum1:
  scoreConjectureCorrectModels=0.96667,  scoreConjectureWrongModels=0.4
  multScoreConjectureCorrectModels=0.96549,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures doublePendulum0: model ID11 / 35 (random ID0 / 2); time to go=5.55hours


 - Evaluation for doublePendulum0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doublePendulum0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulum0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doublePendulum0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulum0c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulum0c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for doublePendulum0:
  scoreConjectureCorrectModels=0.72857,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulum1: model ID11 / 35 (random ID1 / 2); time to go=5.49hours


 - Evaluation for doublePendulum1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulum1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doublePendulum1c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum1c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum1c6: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum1c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for doublePendulum1:
  scoreConjectureCorrectModels=0.55833,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nPendulum0: model ID12 / 35 (random ID0 / 2); time to go=5.36hours


 - Evaluation for nPendulum0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for nPendulum0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for nPendulum0c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for nPendulum0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulum0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for nPendulum0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.6


Evaluation summary for nPendulum0:
  scoreConjectureCorrectModels=0.825,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.81533,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nPendulum1: model ID12 / 35 (random ID1 / 2); time to go=5.23hours


 - Evaluation for nPendulum1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for nPendulum1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for nPendulum1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for nPendulum1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for nPendulum1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for nPendulum1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum1c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for nPendulum1:
  scoreConjectureCorrectModels=0.74286,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures fourBarMechanismPointMasses0: model ID13 / 35 (random ID0 / 2); time to go=5.1hours


 - Evaluation for fourBarMechanismPointMasses0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for fourBarMechanismPointMasses0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for fourBarMechanismPointMasses0c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for fourBarMechanismPointMasses0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for fourBarMechanismPointMasses0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8


***

*****
ERROR:** 

```
EvaluateConjecture: score is invalid: ERROR in ExtractXMLtaggedString: received 0 start tags and 0 end tags!
***
```

 - Evaluation for fourBarMechanismPointMasses0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=-3

 - Evaluation for fourBarMechanismPointMasses0c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for fourBarMechanismPointMasses0:
  scoreConjectureCorrectModels=0.74286,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.88185,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures fourBarMechanismPointMasses1: model ID13 / 35 (random ID1 / 2); time to go=5.04hours


 - Evaluation for fourBarMechanismPointMasses1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for fourBarMechanismPointMasses1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for fourBarMechanismPointMasses1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for fourBarMechanismPointMasses1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for fourBarMechanismPointMasses1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for fourBarMechanismPointMasses1c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for fourBarMechanismPointMasses1:
  scoreConjectureCorrectModels=0.86667,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.85609,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures springCoupledFlyingRigidBodies0: model ID14 / 35 (random ID0 / 2); time to go=4.89hours


 - Evaluation for springCoupledFlyingRigidBodies0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for springCoupledFlyingRigidBodies0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for springCoupledFlyingRigidBodies0c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for springCoupledFlyingRigidBodies0c3: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for springCoupledFlyingRigidBodies0c6: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for springCoupledFlyingRigidBodies0c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.98


Evaluation summary for springCoupledFlyingRigidBodies0:
  scoreConjectureCorrectModels=0.88,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.87772,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures springCoupledFlyingRigidBodies1: model ID14 / 35 (random ID1 / 2); time to go=4.76hours


 - Evaluation for springCoupledFlyingRigidBodies1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for springCoupledFlyingRigidBodies1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for springCoupledFlyingRigidBodies1c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for springCoupledFlyingRigidBodies1c3: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for springCoupledFlyingRigidBodies1c4: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for springCoupledFlyingRigidBodies1c6: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for springCoupledFlyingRigidBodies1c7: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for springCoupledFlyingRigidBodies1:
  scoreConjectureCorrectModels=0.88571,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.88498,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures torsionalOscillator0: model ID15 / 35 (random ID0 / 2); time to go=4.65hours


 - Evaluation for torsionalOscillator0c0: method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for torsionalOscillator0c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator0c2: method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator0c3: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for torsionalOscillator0c4: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.6

 - Evaluation for torsionalOscillator0c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for torsionalOscillator0c6: method=Evaluate motion space, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for torsionalOscillator0c7: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.9


Evaluation summary for torsionalOscillator0:
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.625
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures torsionalOscillator1: model ID15 / 35 (random ID1 / 2); time to go=4.58hours


 - Evaluation for torsionalOscillator1c0: method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator1c1: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for torsionalOscillator1c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator1c3: method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator1c4: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.6

 - Evaluation for torsionalOscillator1c5: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.6

 - Evaluation for torsionalOscillator1c6: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0


Evaluation summary for torsionalOscillator1:
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.28571
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures invertedSinglePendulum0: model ID16 / 35 (random ID0 / 2); time to go=4.48hours


 - Evaluation for invertedSinglePendulum0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for invertedSinglePendulum0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for invertedSinglePendulum0c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for invertedSinglePendulum0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for invertedSinglePendulum0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for invertedSinglePendulum0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for invertedSinglePendulum0c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for invertedSinglePendulum0c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for invertedSinglePendulum0:
  scoreConjectureCorrectModels=0.8875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.88547,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures invertedSinglePendulum1: model ID16 / 35 (random ID1 / 2); time to go=4.37hours


 - Evaluation for invertedSinglePendulum1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for invertedSinglePendulum1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for invertedSinglePendulum1c3: method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.2

 - Evaluation for invertedSinglePendulum1c4: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.6

 - Evaluation for invertedSinglePendulum1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for invertedSinglePendulum1c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for invertedSinglePendulum1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for invertedSinglePendulum1:
  scoreConjectureCorrectModels=0.78,  scoreConjectureWrongModels=0.4
  multScoreConjectureCorrectModels=0.77327,  multScoreConjectureWrongModels=0.34641


***

EvaluateAllConjectures discRollingOnGround0: model ID17 / 35 (random ID0 / 2); time to go=4.26hours


 - Evaluation for discRollingOnGround0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround0c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for discRollingOnGround0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for discRollingOnGround0c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround0c7: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for discRollingOnGround0:
  scoreConjectureCorrectModels=0.9375,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.93337,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures discRollingOnGround1: model ID17 / 35 (random ID1 / 2); time to go=4.14hours


 - Evaluation for discRollingOnGround1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.99

 - Evaluation for discRollingOnGround1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround1c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for discRollingOnGround1:
  scoreConjectureCorrectModels=0.87375,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumElasticSpring0: model ID18 / 35 (random ID0 / 2); time to go=4.01hours


 - Evaluation for doublePendulumElasticSpring0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumElasticSpring0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumElasticSpring0c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for doublePendulumElasticSpring0c4: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumElasticSpring0c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumElasticSpring0c7: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for doublePendulumElasticSpring0:
  scoreConjectureCorrectModels=0.82,  scoreConjectureWrongModels=0.8
  multScoreConjectureCorrectModels=0.81907,  multScoreConjectureWrongModels=0.8


***

EvaluateAllConjectures doublePendulumElasticSpring1: model ID18 / 35 (random ID1 / 2); time to go=3.88hours


 - Evaluation for doublePendulumElasticSpring1c0: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for doublePendulumElasticSpring1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doublePendulumElasticSpring1c2: method=Evaluate static equilibrium for damped systems, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for doublePendulumElasticSpring1c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for doublePendulumElasticSpring1c4: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumElasticSpring1c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumElasticSpring1c7: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for doublePendulumElasticSpring1:
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.26667
  multScoreConjectureCorrectModels=0.84853,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures nPendulumElasticSpring0: model ID19 / 35 (random ID0 / 2); time to go=3.76hours


 - Evaluation for nPendulumElasticSpring0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for nPendulumElasticSpring0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for nPendulumElasticSpring0c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulumElasticSpring0c3: method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for nPendulumElasticSpring0c4: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for nPendulumElasticSpring0c5: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for nPendulumElasticSpring0c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for nPendulumElasticSpring0c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for nPendulumElasticSpring0:
  scoreConjectureCorrectModels=0.72857,  scoreConjectureWrongModels=0.8
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.8


***

EvaluateAllConjectures nPendulumElasticSpring1: model ID19 / 35 (random ID1 / 2); time to go=3.65hours


 - Evaluation for nPendulumElasticSpring1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for nPendulumElasticSpring1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for nPendulumElasticSpring1c2: method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for nPendulumElasticSpring1c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for nPendulumElasticSpring1c4: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for nPendulumElasticSpring1c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for nPendulumElasticSpring1c6: method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for nPendulumElasticSpring1c7: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.8


Evaluation summary for nPendulumElasticSpring1:
  scoreConjectureCorrectModels=0.88,  scoreConjectureWrongModels=0.83333
  multScoreConjectureCorrectModels=0.87687,  multScoreConjectureWrongModels=0.83203


***

EvaluateAllConjectures elasticChain0: model ID20 / 35 (random ID0 / 2); time to go=3.54hours


 - Evaluation for elasticChain0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for elasticChain0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for elasticChain0c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for elasticChain0c4: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for elasticChain0c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for elasticChain0c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for elasticChain0c7: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for elasticChain0:
  scoreConjectureCorrectModels=0.55714,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures elasticChain1: model ID20 / 35 (random ID1 / 2); time to go=3.41hours


 - Evaluation for elasticChain1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for elasticChain1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for elasticChain1c2: method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for elasticChain1c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for elasticChain1c4: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for elasticChain1c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for elasticChain1c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for elasticChain1c7: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for elasticChain1:
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.8404,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumRigidBody0: model ID21 / 35 (random ID0 / 2); time to go=3.3hours


 - Evaluation for singlePendulumRigidBody0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singlePendulumRigidBody0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singlePendulumRigidBody0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulumRigidBody0c3: method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for singlePendulumRigidBody0c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody0c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singlePendulumRigidBody0c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for singlePendulumRigidBody0c7: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for singlePendulumRigidBody0:
  scoreConjectureCorrectModels=0.76,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumRigidBody1: model ID21 / 35 (random ID1 / 2); time to go=3.2hours


 - Evaluation for singlePendulumRigidBody1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody1c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singlePendulumRigidBody1c4: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singlePendulumRigidBody1c5: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody1c6: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singlePendulumRigidBody1c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for singlePendulumRigidBody1:
  scoreConjectureCorrectModels=0.475,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringRigid0: model ID22 / 35 (random ID0 / 2); time to go=3.08hours


 - Evaluation for massPointOnStringRigid0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for massPointOnStringRigid0c1: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for massPointOnStringRigid0c2: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for massPointOnStringRigid0c3: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringRigid0c4: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringRigid0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringRigid0c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for massPointOnStringRigid0:
  scoreConjectureCorrectModels=0.88714,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.88357,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringRigid1: model ID22 / 35 (random ID1 / 2); time to go=2.96hours


 - Evaluation for massPointOnStringRigid1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for massPointOnStringRigid1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringRigid1c2: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for massPointOnStringRigid1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for massPointOnStringRigid1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for massPointOnStringRigid1c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringRigid1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for massPointOnStringRigid1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for massPointOnStringRigid1:
  scoreConjectureCorrectModels=0.93,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.92808,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringElastic0: model ID23 / 35 (random ID0 / 2); time to go=2.86hours


 - Evaluation for massPointOnStringElastic0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for massPointOnStringElastic0c2: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic0c3: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic0c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringElastic0c5: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for massPointOnStringElastic0c6: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic0c7: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.6


Evaluation summary for massPointOnStringElastic0:
  scoreConjectureCorrectModels=0.84167,  scoreConjectureWrongModels=0.7
  multScoreConjectureCorrectModels=0.83957,  multScoreConjectureWrongModels=0.69282


***

EvaluateAllConjectures massPointOnStringElastic1: model ID23 / 35 (random ID1 / 2); time to go=2.76hours


 - Evaluation for massPointOnStringElastic1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for massPointOnStringElastic1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic1c2: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic1c3: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic1c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for massPointOnStringElastic1c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringElastic1c6: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic1c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.6


Evaluation summary for massPointOnStringElastic1:
  scoreConjectureCorrectModels=0.81875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.81206,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures linkOnTwoPrismaticJoints0: model ID24 / 35 (random ID0 / 2); time to go=2.65hours


 - Evaluation for linkOnTwoPrismaticJoints0c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for linkOnTwoPrismaticJoints0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for linkOnTwoPrismaticJoints0c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for linkOnTwoPrismaticJoints0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for linkOnTwoPrismaticJoints0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for linkOnTwoPrismaticJoints0c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for linkOnTwoPrismaticJoints0:
  scoreConjectureCorrectModels=0.86667,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.86535,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures linkOnTwoPrismaticJoints1: model ID24 / 35 (random ID1 / 2); time to go=2.52hours


 - Evaluation for linkOnTwoPrismaticJoints1c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for linkOnTwoPrismaticJoints1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for linkOnTwoPrismaticJoints1c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for linkOnTwoPrismaticJoints1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for linkOnTwoPrismaticJoints1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for linkOnTwoPrismaticJoints1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for linkOnTwoPrismaticJoints1c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for linkOnTwoPrismaticJoints1:
  scoreConjectureCorrectModels=0.86857,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.8567,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingRigidBody0: model ID25 / 35 (random ID0 / 2); time to go=2.4hours


 - Evaluation for flyingRigidBody0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for flyingRigidBody0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingRigidBody0c2: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingRigidBody0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingRigidBody0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingRigidBody0c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for flyingRigidBody0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingRigidBody0c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for flyingRigidBody0:
  scoreConjectureCorrectModels=0.95375,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.95053,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingRigidBody1: model ID25 / 35 (random ID1 / 2); time to go=2.3hours


 - Evaluation for flyingRigidBody1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingRigidBody1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for flyingRigidBody1c2: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingRigidBody1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for flyingRigidBody1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingRigidBody1c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for flyingRigidBody1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingRigidBody1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for flyingRigidBody1:
  scoreConjectureCorrectModels=0.935,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.93101,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures suspendedRigidBody0: model ID26 / 35 (random ID0 / 2); time to go=2.2hours


 - Evaluation for suspendedRigidBody0c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for suspendedRigidBody0c2: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for suspendedRigidBody0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for suspendedRigidBody0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for suspendedRigidBody0c5: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for suspendedRigidBody0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for suspendedRigidBody0c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for suspendedRigidBody0:
  scoreConjectureCorrectModels=0.88571,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.88341,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures suspendedRigidBody1: model ID26 / 35 (random ID1 / 2); time to go=2.07hours


 - Evaluation for suspendedRigidBody1c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for suspendedRigidBody1c2: method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for suspendedRigidBody1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for suspendedRigidBody1c4: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for suspendedRigidBody1c5: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for suspendedRigidBody1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for suspendedRigidBody1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for suspendedRigidBody1:
  scoreConjectureCorrectModels=0.84,  scoreConjectureWrongModels=0.9
  multScoreConjectureCorrectModels=0.82784,  multScoreConjectureWrongModels=0.9


***

EvaluateAllConjectures gyroscopeOnSphericalJoint0: model ID27 / 35 (random ID0 / 2); time to go=1.94hours


 - Evaluation for gyroscopeOnSphericalJoint0c0: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for gyroscopeOnSphericalJoint0c1: method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for gyroscopeOnSphericalJoint0c2: method=Check if spherical motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for gyroscopeOnSphericalJoint0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for gyroscopeOnSphericalJoint0c4: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for gyroscopeOnSphericalJoint0c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for gyroscopeOnSphericalJoint0c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for gyroscopeOnSphericalJoint0:
  scoreConjectureCorrectModels=0.9,  scoreConjectureWrongModels=0.6
  multScoreConjectureCorrectModels=0.89628,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures gyroscopeOnSphericalJoint1: model ID27 / 35 (random ID1 / 2); time to go=1.82hours


 - Evaluation for gyroscopeOnSphericalJoint1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for gyroscopeOnSphericalJoint1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for gyroscopeOnSphericalJoint1c2: method=Check if spherical motion, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for gyroscopeOnSphericalJoint1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for gyroscopeOnSphericalJoint1c4: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for gyroscopeOnSphericalJoint1c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.6

 - Evaluation for gyroscopeOnSphericalJoint1c6: method=Evaluate symmetry, modelIsCorrect=False, scoreValue=0.8


Evaluation summary for gyroscopeOnSphericalJoint1:
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.8
  multScoreConjectureCorrectModels=0.84902,  multScoreConjectureWrongModels=0.7872


***

EvaluateAllConjectures prismaticJointSystem0: model ID28 / 35 (random ID0 / 2); time to go=1.7hours


 - Evaluation for prismaticJointSystem0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem0c2: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for prismaticJointSystem0:
  scoreConjectureCorrectModels=1.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=1.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures prismaticJointSystem1: model ID28 / 35 (random ID1 / 2); time to go=1.57hours


 - Evaluation for prismaticJointSystem1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem1c2: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem1c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.99


Evaluation summary for prismaticJointSystem1:
  scoreConjectureCorrectModels=0.99857,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.99857,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithSprings0: model ID29 / 35 (random ID0 / 2); time to go=1.45hours


 - Evaluation for twoMassPointsWithSprings0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for twoMassPointsWithSprings0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for twoMassPointsWithSprings0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for twoMassPointsWithSprings0c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for twoMassPointsWithSprings0c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for twoMassPointsWithSprings0:
  scoreConjectureCorrectModels=0.8,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithSprings1: model ID29 / 35 (random ID1 / 2); time to go=1.32hours


 - Evaluation for twoMassPointsWithSprings1c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for twoMassPointsWithSprings1c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for twoMassPointsWithSprings1c4: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for twoMassPointsWithSprings1c6: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for twoMassPointsWithSprings1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for twoMassPointsWithSprings1:
  scoreConjectureCorrectModels=0.756,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithDistances0: model ID30 / 35 (random ID0 / 2); time to go=1.2hours


 - Evaluation for twoMassPointsWithDistances0c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for twoMassPointsWithDistances0c2: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithDistances0c3: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for twoMassPointsWithDistances0c5: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for twoMassPointsWithDistances0c6: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for twoMassPointsWithDistances0c7: method=Perform a rough calculation, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for twoMassPointsWithDistances0:
  scoreConjectureCorrectModels=0.85833,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.85444,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithDistances1: model ID30 / 35 (random ID1 / 2); time to go=1.08hours


 - Evaluation for twoMassPointsWithDistances1c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for twoMassPointsWithDistances1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for twoMassPointsWithDistances1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for twoMassPointsWithDistances1c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for twoMassPointsWithDistances1:
  scoreConjectureCorrectModels=0.525,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.46058,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorSimplySupported0: model ID31 / 35 (random ID0 / 2); time to go=3420.84s


 - Evaluation for rigidRotorSimplySupported0c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorSimplySupported0c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for rigidRotorSimplySupported0c3: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for rigidRotorSimplySupported0:
  scoreConjectureCorrectModels=0.86667,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.86535,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorSimplySupported1: model ID31 / 35 (random ID1 / 2); time to go=2964.75s


 - Evaluation for rigidRotorSimplySupported1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for rigidRotorSimplySupported1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorSimplySupported1c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for rigidRotorSimplySupported1c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorSimplySupported1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for rigidRotorSimplySupported1:
  scoreConjectureCorrectModels=0.88,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.87687,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorUnbalanced0: model ID32 / 35 (random ID0 / 2); time to go=2527.84s


 - Evaluation for rigidRotorUnbalanced0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for rigidRotorUnbalanced0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced0c2: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced0c3: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for rigidRotorUnbalanced0c4: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced0c5: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced0c6: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for rigidRotorUnbalanced0c7: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for rigidRotorUnbalanced0:
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.84853,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorUnbalanced1: model ID32 / 35 (random ID1 / 2); time to go=2108.84s


 - Evaluation for rigidRotorUnbalanced1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced1c2: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced1c3: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for rigidRotorUnbalanced1c4: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced1c5: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for rigidRotorUnbalanced1c6: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for rigidRotorUnbalanced1c7: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for rigidRotorUnbalanced1:
  scoreConjectureCorrectModels=0.8375,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.83613,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumRigidBodies0: model ID33 / 35 (random ID0 / 2); time to go=1686.03s


 - Evaluation for doublePendulumRigidBodies0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumRigidBodies0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumRigidBodies0c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumRigidBodies0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doublePendulumRigidBodies0c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for doublePendulumRigidBodies0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for doublePendulumRigidBodies0:
  scoreConjectureCorrectModels=0.59167,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumRigidBodies1: model ID33 / 35 (random ID1 / 2); time to go=1264.24s


 - Evaluation for doublePendulumRigidBodies1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doublePendulumRigidBodies1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doublePendulumRigidBodies1c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumRigidBodies1c3: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for doublePendulumRigidBodies1c4: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doublePendulumRigidBodies1c6: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for doublePendulumRigidBodies1c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for doublePendulumRigidBodies1:
  scoreConjectureCorrectModels=0.51429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankRigidBodies0: model ID34 / 35 (random ID0 / 2); time to go=847.02s


 - Evaluation for sliderCrankRigidBodies0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for sliderCrankRigidBodies0c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for sliderCrankRigidBodies0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for sliderCrankRigidBodies0c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for sliderCrankRigidBodies0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for sliderCrankRigidBodies0c7: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for sliderCrankRigidBodies0:
  scoreConjectureCorrectModels=0.775,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankRigidBodies1: model ID34 / 35 (random ID1 / 2); time to go=423.63s


 - Evaluation for sliderCrankRigidBodies1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for sliderCrankRigidBodies1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for sliderCrankRigidBodies1c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for sliderCrankRigidBodies1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for sliderCrankRigidBodies1c7: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for sliderCrankRigidBodies1:
  scoreConjectureCorrectModels=0.78571,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

A total of:
  1 errors and
  0 warnings
were logged!

***

Summary of EvaluateAllConjectures
 - useSimEvaluationOnly = True
 - sumScoreTotalConjectures = 387.2500000000006
 - nTotalConjectures = 480
 - sumScoreTotalConjectureCorrectModels = 345.05000000000035
 - sumScoreTotalConjectureWrongModels = 42.19999999999999
 - nTotalConjectureCorrectModels = 414
 - nTotalConjectureWrongModels = 66
 - sumMultScoreTotalConjectureCorrectModels = 41.87602538265078
 - sumMultScoreTotalConjectureWrongModels = 8.435728597346412
 - nTotalMultConjectureCorrectModels = 65
 - nTotalMultConjectureWrongModels = 18
 - numberOfRemovedTokensGlobal = 0
 - numberOfTokensGlobal = 328569
 - totalScoreConjectureCorrectModels = 0.8334541062801941
 - totalScoreConjectureWrongModels = 0.6393939393939392
 - totalMultScoreConjectureCorrectModels = 0.6442465443484735
 - totalMultScoreConjectureWrongModels = 0.4686515887414673
 - runTime = 29610.845898866653
 - loggerErrors = 1
 - loggerWarnings = 0



***

Evaluate conjectures (using wrong models): nModels=70, nConjPerModel=8, LLM model=meta-llama/Llama-3.3-70B-Instruct

***

EvaluateAllConjectures flyingMassPoint0: model ID0 / 35 (random ID0 / 2)


 - Evaluation for flyingMassPoint0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint0c3 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint0c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint0c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint0c7 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for flyingMassPoint0 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingMassPoint1: model ID0 / 35 (random ID1 / 2); time to go=9.4hours


 - Evaluation for flyingMassPoint1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint1c3 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint1c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for flyingMassPoint1 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures freeFallMassPoint0: model ID1 / 35 (random ID0 / 2); time to go=8.83hours


 - Evaluation for freeFallMassPoint0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint0c3 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint0c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint0c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for freeFallMassPoint0 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures freeFallMassPoint1: model ID1 / 35 (random ID1 / 2); time to go=7.73hours


 - Evaluation for freeFallMassPoint1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint1c3 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint1c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for freeFallMassPoint1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for freeFallMassPoint1 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures singleMassOscillator0: model ID2 / 35 (random ID0 / 2); time to go=7.22hours


 - Evaluation for singleMassOscillator0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillator0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for singleMassOscillator0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillator0c3 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillator0c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for singleMassOscillator0c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillator0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillator0c7 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for singleMassOscillator0 (using wrong models):
  scoreConjectureCorrectModels=0.2,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillator1: model ID2 / 35 (random ID1 / 2); time to go=7.44hours


 - Evaluation for singleMassOscillator1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for singleMassOscillator1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillator1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for singleMassOscillator1c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillator1c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillator1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillator1c7 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for singleMassOscillator1 (using wrong models):
  scoreConjectureCorrectModels=0.45714,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorGravity0: model ID3 / 35 (random ID0 / 2); time to go=7.58hours


 - Evaluation for singleMassOscillatorGravity0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity0c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity0c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillatorGravity0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for singleMassOscillatorGravity0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for singleMassOscillatorGravity0 (using wrong models):
  scoreConjectureCorrectModels=0.14286,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorGravity1: model ID3 / 35 (random ID1 / 2); time to go=7.31hours


 - Evaluation for singleMassOscillatorGravity1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for singleMassOscillatorGravity1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity1c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity1c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singleMassOscillatorGravity1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillatorGravity1c7 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for singleMassOscillatorGravity1 (using wrong models):
  scoreConjectureCorrectModels=0.44286,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankSimple0: model ID4 / 35 (random ID0 / 2); time to go=7.23hours



Evaluation summary for sliderCrankSimple0 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankSimple1: model ID4 / 35 (random ID1 / 2); time to go=6.33hours


 - Evaluation for sliderCrankSimple1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.4


Evaluation summary for sliderCrankSimple1 (using wrong models):
  scoreConjectureCorrectModels=0.4,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.4,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumElasticSpring0: model ID5 / 35 (random ID0 / 2); time to go=5.71hours


 - Evaluation for singlePendulumElasticSpring0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulumElasticSpring0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulumElasticSpring0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for singlePendulumElasticSpring0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulumElasticSpring0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for singlePendulumElasticSpring0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulumElasticSpring0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for singlePendulumElasticSpring0c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=False, scoreValue=0.9


Evaluation summary for singlePendulumElasticSpring0 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.4375
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures singlePendulumElasticSpring1: model ID5 / 35 (random ID1 / 2); time to go=5.85hours


 - Evaluation for singlePendulumElasticSpring1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singlePendulumElasticSpring1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulumElasticSpring1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singlePendulumElasticSpring1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulumElasticSpring1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singlePendulumElasticSpring1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumElasticSpring1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.6

 - Evaluation for singlePendulumElasticSpring1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for singlePendulumElasticSpring1 (using wrong models):
  scoreConjectureCorrectModels=0.75714,  scoreConjectureWrongModels=0.6
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.6


***

EvaluateAllConjectures singleMassOscillatorUserFunction0: model ID6 / 35 (random ID0 / 2); time to go=5.93hours


 - Evaluation for singleMassOscillatorUserFunction0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillatorUserFunction0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorUserFunction0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillatorUserFunction0c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorUserFunction0c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorUserFunction0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillatorUserFunction0c7 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for singleMassOscillatorUserFunction0 (using wrong models):
  scoreConjectureCorrectModels=0.45714,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorUserFunction1: model ID6 / 35 (random ID1 / 2); time to go=5.95hours


 - Evaluation for singleMassOscillatorUserFunction1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for singleMassOscillatorUserFunction1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singleMassOscillatorUserFunction1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillatorUserFunction1c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorUserFunction1c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillatorUserFunction1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for singleMassOscillatorUserFunction1c7 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for singleMassOscillatorUserFunction1 (using wrong models):
  scoreConjectureCorrectModels=0.55714,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures spinningDisc0: model ID7 / 35 (random ID0 / 2); time to go=5.94hours


 - Evaluation for spinningDisc0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc0c1 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for spinningDisc0c2 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc0c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc0c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc0c6 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc0c7 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for spinningDisc0 (using wrong models):
  scoreConjectureCorrectModels=0.57143,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures spinningDisc1: model ID7 / 35 (random ID1 / 2); time to go=5.96hours


 - Evaluation for spinningDisc1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc1c1 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc1c2 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc1c3 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for spinningDisc1c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc1c6 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc1c7 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for spinningDisc1 (using wrong models):
  scoreConjectureCorrectModels=0.3125,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doubleMassOscillator0: model ID8 / 35 (random ID0 / 2); time to go=5.89hours


 - Evaluation for doubleMassOscillator0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for doubleMassOscillator0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for doubleMassOscillator0c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doubleMassOscillator0c4 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doubleMassOscillator0c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doubleMassOscillator0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doubleMassOscillator0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for doubleMassOscillator0 (using wrong models):
  scoreConjectureCorrectModels=0.78571,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.77365,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doubleMassOscillator1: model ID8 / 35 (random ID1 / 2); time to go=5.85hours


 - Evaluation for doubleMassOscillator1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for doubleMassOscillator1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doubleMassOscillator1c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doubleMassOscillator1c4 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doubleMassOscillator1c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doubleMassOscillator1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doubleMassOscillator1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for doubleMassOscillator1 (using wrong models):
  scoreConjectureCorrectModels=0.7,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nMassOscillator0: model ID9 / 35 (random ID0 / 2); time to go=5.77hours


 - Evaluation for nMassOscillator0c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for nMassOscillator0c2 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.6

 - Evaluation for nMassOscillator0c3 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for nMassOscillator0c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for nMassOscillator0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.6

 - Evaluation for nMassOscillator0c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for nMassOscillator0c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.0


Evaluation summary for nMassOscillator0 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.64286
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures nMassOscillator1: model ID9 / 35 (random ID1 / 2); time to go=5.76hours


 - Evaluation for nMassOscillator1c0 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for nMassOscillator1c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for nMassOscillator1c2 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for nMassOscillator1c3 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for nMassOscillator1c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for nMassOscillator1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for nMassOscillator1c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nMassOscillator1c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for nMassOscillator1 (using wrong models):
  scoreConjectureCorrectModels=0.85833,  scoreConjectureWrongModels=0.45
  multScoreConjectureCorrectModels=0.85715,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures singlePendulum0: model ID10 / 35 (random ID0 / 2); time to go=5.73hours


 - Evaluation for singlePendulum0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.6

 - Evaluation for singlePendulum0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.2

 - Evaluation for singlePendulum0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for singlePendulum0c3 (using wrong models): method=Check if planar motion, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for singlePendulum0c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulum0c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singlePendulum0c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for singlePendulum0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.8


Evaluation summary for singlePendulum0 (using wrong models):
  scoreConjectureCorrectModels=0.5,  scoreConjectureWrongModels=0.7
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.62817


***

EvaluateAllConjectures singlePendulum1: model ID10 / 35 (random ID1 / 2); time to go=5.66hours


 - Evaluation for singlePendulum1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulum1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulum1c3 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singlePendulum1c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singlePendulum1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulum1c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulum1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.2


Evaluation summary for singlePendulum1 (using wrong models):
  scoreConjectureCorrectModels=0.9,  scoreConjectureWrongModels=0.05
  multScoreConjectureCorrectModels=0.89628,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures doublePendulum0: model ID11 / 35 (random ID0 / 2); time to go=5.56hours


 - Evaluation for doublePendulum0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulum0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulum0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doublePendulum0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulum0c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum0c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for doublePendulum0 (using wrong models):
  scoreConjectureCorrectModels=0.54286,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulum1: model ID11 / 35 (random ID1 / 2); time to go=5.5hours


 - Evaluation for doublePendulum1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum1c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulum1c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.6


Evaluation summary for doublePendulum1 (using wrong models):
  scoreConjectureCorrectModels=0.23333,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nPendulum0: model ID12 / 35 (random ID0 / 2); time to go=5.36hours


 - Evaluation for nPendulum0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for nPendulum0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for nPendulum0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for nPendulum0 (using wrong models):
  scoreConjectureCorrectModels=0.3,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nPendulum1: model ID12 / 35 (random ID1 / 2); time to go=5.21hours


 - Evaluation for nPendulum1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for nPendulum1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for nPendulum1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for nPendulum1 (using wrong models):
  scoreConjectureCorrectModels=0.22857,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures fourBarMechanismPointMasses0: model ID13 / 35 (random ID0 / 2); time to go=5.08hours


 - Evaluation for fourBarMechanismPointMasses0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for fourBarMechanismPointMasses0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for fourBarMechanismPointMasses0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for fourBarMechanismPointMasses0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for fourBarMechanismPointMasses0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for fourBarMechanismPointMasses0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for fourBarMechanismPointMasses0c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for fourBarMechanismPointMasses0 (using wrong models):
  scoreConjectureCorrectModels=0.54286,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures fourBarMechanismPointMasses1: model ID13 / 35 (random ID1 / 2); time to go=4.94hours


 - Evaluation for fourBarMechanismPointMasses1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for fourBarMechanismPointMasses1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for fourBarMechanismPointMasses1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for fourBarMechanismPointMasses1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for fourBarMechanismPointMasses1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for fourBarMechanismPointMasses1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for fourBarMechanismPointMasses1 (using wrong models):
  scoreConjectureCorrectModels=0.875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.87138,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures springCoupledFlyingRigidBodies0: model ID14 / 35 (random ID0 / 2); time to go=4.79hours


 - Evaluation for springCoupledFlyingRigidBodies0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for springCoupledFlyingRigidBodies0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for springCoupledFlyingRigidBodies0c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for springCoupledFlyingRigidBodies0c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for springCoupledFlyingRigidBodies0c6 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for springCoupledFlyingRigidBodies0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for springCoupledFlyingRigidBodies0 (using wrong models):
  scoreConjectureCorrectModels=0.725,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures springCoupledFlyingRigidBodies1: model ID14 / 35 (random ID1 / 2); time to go=4.67hours


 - Evaluation for springCoupledFlyingRigidBodies1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for springCoupledFlyingRigidBodies1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for springCoupledFlyingRigidBodies1c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for springCoupledFlyingRigidBodies1c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for springCoupledFlyingRigidBodies1c4 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for springCoupledFlyingRigidBodies1c6 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for springCoupledFlyingRigidBodies1c7 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for springCoupledFlyingRigidBodies1 (using wrong models):
  scoreConjectureCorrectModels=0.81429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.80611,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures torsionalOscillator0: model ID15 / 35 (random ID0 / 2); time to go=4.58hours


 - Evaluation for torsionalOscillator0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator0c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator0c2 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator0c3 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator0c4 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator0c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for torsionalOscillator0c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.8


Evaluation summary for torsionalOscillator0 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.225
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures torsionalOscillator1: model ID15 / 35 (random ID1 / 2); time to go=4.49hours


 - Evaluation for torsionalOscillator1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.6

 - Evaluation for torsionalOscillator1c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator1c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator1c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator1c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0


Evaluation summary for torsionalOscillator1 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.08571
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures invertedSinglePendulum0: model ID16 / 35 (random ID0 / 2); time to go=4.4hours


 - Evaluation for invertedSinglePendulum0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for invertedSinglePendulum0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for invertedSinglePendulum0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for invertedSinglePendulum0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for invertedSinglePendulum0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for invertedSinglePendulum0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for invertedSinglePendulum0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for invertedSinglePendulum0c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for invertedSinglePendulum0 (using wrong models):
  scoreConjectureCorrectModels=0.7625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.69853,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures invertedSinglePendulum1: model ID16 / 35 (random ID1 / 2); time to go=4.3hours


 - Evaluation for invertedSinglePendulum1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for invertedSinglePendulum1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for invertedSinglePendulum1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.2

 - Evaluation for invertedSinglePendulum1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for invertedSinglePendulum1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for invertedSinglePendulum1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for invertedSinglePendulum1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for invertedSinglePendulum1 (using wrong models):
  scoreConjectureCorrectModels=0.78,  scoreConjectureWrongModels=0.55
  multScoreConjectureCorrectModels=0.77327,  multScoreConjectureWrongModels=0.42426


***

EvaluateAllConjectures discRollingOnGround0: model ID17 / 35 (random ID0 / 2); time to go=4.18hours


 - Evaluation for discRollingOnGround0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for discRollingOnGround0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for discRollingOnGround0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for discRollingOnGround0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for discRollingOnGround0c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround0c7 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.6


Evaluation summary for discRollingOnGround0 (using wrong models):
  scoreConjectureCorrectModels=0.4,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures discRollingOnGround1: model ID17 / 35 (random ID1 / 2); time to go=4.08hours


 - Evaluation for discRollingOnGround1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for discRollingOnGround1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround1c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.2


Evaluation summary for discRollingOnGround1 (using wrong models):
  scoreConjectureCorrectModels=0.25,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumElasticSpring0: model ID18 / 35 (random ID0 / 2); time to go=3.95hours


 - Evaluation for doublePendulumElasticSpring0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumElasticSpring0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumElasticSpring0c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.6

 - Evaluation for doublePendulumElasticSpring0c4 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumElasticSpring0c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doublePendulumElasticSpring0c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for doublePendulumElasticSpring0 (using wrong models):
  scoreConjectureCorrectModels=0.82,  scoreConjectureWrongModels=0.6
  multScoreConjectureCorrectModels=0.81907,  multScoreConjectureWrongModels=0.6


***

EvaluateAllConjectures doublePendulumElasticSpring1: model ID18 / 35 (random ID1 / 2); time to go=3.82hours


 - Evaluation for doublePendulumElasticSpring1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for doublePendulumElasticSpring1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumElasticSpring1c2 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=False, scoreValue=0.2

 - Evaluation for doublePendulumElasticSpring1c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for doublePendulumElasticSpring1c4 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumElasticSpring1c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumElasticSpring1c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for doublePendulumElasticSpring1 (using wrong models):
  scoreConjectureCorrectModels=0.8,  scoreConjectureWrongModels=0.06667
  multScoreConjectureCorrectModels=0.8,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures nPendulumElasticSpring0: model ID19 / 35 (random ID0 / 2); time to go=3.7hours


 - Evaluation for nPendulumElasticSpring0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulumElasticSpring0c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulumElasticSpring0c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for nPendulumElasticSpring0c4 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for nPendulumElasticSpring0c5 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for nPendulumElasticSpring0c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for nPendulumElasticSpring0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for nPendulumElasticSpring0 (using wrong models):
  scoreConjectureCorrectModels=0.57857,  scoreConjectureWrongModels=0.8
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.8


***

EvaluateAllConjectures nPendulumElasticSpring1: model ID19 / 35 (random ID1 / 2); time to go=3.59hours


 - Evaluation for nPendulumElasticSpring1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.4

 - Evaluation for nPendulumElasticSpring1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for nPendulumElasticSpring1c2 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for nPendulumElasticSpring1c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for nPendulumElasticSpring1c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for nPendulumElasticSpring1c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for nPendulumElasticSpring1c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for nPendulumElasticSpring1c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.8


Evaluation summary for nPendulumElasticSpring1 (using wrong models):
  scoreConjectureCorrectModels=0.72,  scoreConjectureWrongModels=0.83333
  multScoreConjectureCorrectModels=0.68751,  multScoreConjectureWrongModels=0.83203


***

EvaluateAllConjectures elasticChain0: model ID20 / 35 (random ID0 / 2); time to go=3.49hours


 - Evaluation for elasticChain0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for elasticChain0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for elasticChain0c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for elasticChain0c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for elasticChain0c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for elasticChain0c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for elasticChain0c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for elasticChain0 (using wrong models):
  scoreConjectureCorrectModels=0.52857,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures elasticChain1: model ID20 / 35 (random ID1 / 2); time to go=3.36hours


 - Evaluation for elasticChain1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for elasticChain1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for elasticChain1c2 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for elasticChain1c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for elasticChain1c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for elasticChain1c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for elasticChain1c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for elasticChain1c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for elasticChain1 (using wrong models):
  scoreConjectureCorrectModels=0.7875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumRigidBody0: model ID21 / 35 (random ID0 / 2); time to go=3.26hours


 - Evaluation for singlePendulumRigidBody0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulumRigidBody0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulumRigidBody0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody0c3 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulumRigidBody0c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody0c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singlePendulumRigidBody0c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulumRigidBody0c7 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for singlePendulumRigidBody0 (using wrong models):
  scoreConjectureCorrectModels=0.6375,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumRigidBody1: model ID21 / 35 (random ID1 / 2); time to go=3.16hours


 - Evaluation for singlePendulumRigidBody1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulumRigidBody1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulumRigidBody1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulumRigidBody1c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody1c4 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singlePendulumRigidBody1c5 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singlePendulumRigidBody1c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulumRigidBody1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for singlePendulumRigidBody1 (using wrong models):
  scoreConjectureCorrectModels=0.75,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringRigid0: model ID22 / 35 (random ID0 / 2); time to go=3.06hours


 - Evaluation for massPointOnStringRigid0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringRigid0c1 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for massPointOnStringRigid0c2 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid0c3 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringRigid0c4 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringRigid0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for massPointOnStringRigid0c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for massPointOnStringRigid0 (using wrong models):
  scoreConjectureCorrectModels=0.67857,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringRigid1: model ID22 / 35 (random ID1 / 2); time to go=2.95hours


 - Evaluation for massPointOnStringRigid1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringRigid1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringRigid1c2 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringRigid1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for massPointOnStringRigid1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringRigid1c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for massPointOnStringRigid1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringRigid1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for massPointOnStringRigid1 (using wrong models):
  scoreConjectureCorrectModels=0.3875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringElastic0: model ID23 / 35 (random ID0 / 2); time to go=2.84hours


 - Evaluation for massPointOnStringElastic0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringElastic0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringElastic0c2 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.4

 - Evaluation for massPointOnStringElastic0c3 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for massPointOnStringElastic0c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic0c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for massPointOnStringElastic0c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.8


Evaluation summary for massPointOnStringElastic0 (using wrong models):
  scoreConjectureCorrectModels=0.48333,  scoreConjectureWrongModels=0.8
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.8


***

EvaluateAllConjectures massPointOnStringElastic1: model ID23 / 35 (random ID1 / 2); time to go=2.73hours


 - Evaluation for massPointOnStringElastic1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringElastic1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringElastic1c2 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic1c3 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for massPointOnStringElastic1c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringElastic1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic1c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for massPointOnStringElastic1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for massPointOnStringElastic1 (using wrong models):
  scoreConjectureCorrectModels=0.64375,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures linkOnTwoPrismaticJoints0: model ID24 / 35 (random ID0 / 2); time to go=2.62hours


 - Evaluation for linkOnTwoPrismaticJoints0c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for linkOnTwoPrismaticJoints0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for linkOnTwoPrismaticJoints0c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for linkOnTwoPrismaticJoints0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for linkOnTwoPrismaticJoints0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for linkOnTwoPrismaticJoints0c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for linkOnTwoPrismaticJoints0 (using wrong models):
  scoreConjectureCorrectModels=0.81667,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.8088,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures linkOnTwoPrismaticJoints1: model ID24 / 35 (random ID1 / 2); time to go=2.5hours


 - Evaluation for linkOnTwoPrismaticJoints1c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for linkOnTwoPrismaticJoints1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for linkOnTwoPrismaticJoints1c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for linkOnTwoPrismaticJoints1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for linkOnTwoPrismaticJoints1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for linkOnTwoPrismaticJoints1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for linkOnTwoPrismaticJoints1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for linkOnTwoPrismaticJoints1 (using wrong models):
  scoreConjectureCorrectModels=0.24286,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingRigidBody0: model ID25 / 35 (random ID0 / 2); time to go=2.38hours


 - Evaluation for flyingRigidBody0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody0c2 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for flyingRigidBody0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for flyingRigidBody0c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody0c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for flyingRigidBody0 (using wrong models):
  scoreConjectureCorrectModels=0.2475,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingRigidBody1: model ID25 / 35 (random ID1 / 2); time to go=2.27hours


 - Evaluation for flyingRigidBody1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody1c2 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody1c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for flyingRigidBody1 (using wrong models):
  scoreConjectureCorrectModels=0.1,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures suspendedRigidBody0: model ID26 / 35 (random ID0 / 2); time to go=2.17hours


 - Evaluation for suspendedRigidBody0c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for suspendedRigidBody0c2 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for suspendedRigidBody0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for suspendedRigidBody0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for suspendedRigidBody0c5 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for suspendedRigidBody0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for suspendedRigidBody0c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for suspendedRigidBody0 (using wrong models):
  scoreConjectureCorrectModels=0.82857,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.82124,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures suspendedRigidBody1: model ID26 / 35 (random ID1 / 2); time to go=2.05hours


 - Evaluation for suspendedRigidBody1c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for suspendedRigidBody1c2 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for suspendedRigidBody1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for suspendedRigidBody1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for suspendedRigidBody1c5 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for suspendedRigidBody1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for suspendedRigidBody1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for suspendedRigidBody1 (using wrong models):
  scoreConjectureCorrectModels=0.78,  scoreConjectureWrongModels=0.9
  multScoreConjectureCorrectModels=0.76336,  multScoreConjectureWrongModels=0.9


***

EvaluateAllConjectures gyroscopeOnSphericalJoint0: model ID27 / 35 (random ID0 / 2); time to go=1.93hours


 - Evaluation for gyroscopeOnSphericalJoint0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for gyroscopeOnSphericalJoint0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for gyroscopeOnSphericalJoint0c2 (using wrong models): method=Check if spherical motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for gyroscopeOnSphericalJoint0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for gyroscopeOnSphericalJoint0c4 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.4

 - Evaluation for gyroscopeOnSphericalJoint0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for gyroscopeOnSphericalJoint0c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for gyroscopeOnSphericalJoint0 (using wrong models):
  scoreConjectureCorrectModels=0.9,  scoreConjectureWrongModels=0.3
  multScoreConjectureCorrectModels=0.89628,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures gyroscopeOnSphericalJoint1: model ID27 / 35 (random ID1 / 2); time to go=1.81hours


 - Evaluation for gyroscopeOnSphericalJoint1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for gyroscopeOnSphericalJoint1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for gyroscopeOnSphericalJoint1c2 (using wrong models): method=Check if spherical motion, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for gyroscopeOnSphericalJoint1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for gyroscopeOnSphericalJoint1c4 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for gyroscopeOnSphericalJoint1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for gyroscopeOnSphericalJoint1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=False, scoreValue=0.8


Evaluation summary for gyroscopeOnSphericalJoint1 (using wrong models):
  scoreConjectureCorrectModels=0.53333,  scoreConjectureWrongModels=0.65
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures prismaticJointSystem0: model ID28 / 35 (random ID0 / 2); time to go=1.69hours


 - Evaluation for prismaticJointSystem0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem0c2 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for prismaticJointSystem0 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures prismaticJointSystem1: model ID28 / 35 (random ID1 / 2); time to go=1.56hours


 - Evaluation for prismaticJointSystem1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem1c2 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for prismaticJointSystem1 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithSprings0: model ID29 / 35 (random ID0 / 2); time to go=1.44hours


 - Evaluation for twoMassPointsWithSprings0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for twoMassPointsWithSprings0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for twoMassPointsWithSprings0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for twoMassPointsWithSprings0c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for twoMassPointsWithSprings0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for twoMassPointsWithSprings0 (using wrong models):
  scoreConjectureCorrectModels=0.82,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.80856,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithSprings1: model ID29 / 35 (random ID1 / 2); time to go=1.32hours


 - Evaluation for twoMassPointsWithSprings1c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for twoMassPointsWithSprings1c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for twoMassPointsWithSprings1c4 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for twoMassPointsWithSprings1c6 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for twoMassPointsWithSprings1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for twoMassPointsWithSprings1 (using wrong models):
  scoreConjectureCorrectModels=0.66,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithDistances0: model ID30 / 35 (random ID0 / 2); time to go=1.19hours


 - Evaluation for twoMassPointsWithDistances0c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for twoMassPointsWithDistances0c2 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for twoMassPointsWithDistances0c3 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for twoMassPointsWithDistances0c5 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for twoMassPointsWithDistances0c6 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for twoMassPointsWithDistances0c7 (using wrong models): method=Perform a rough calculation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for twoMassPointsWithDistances0 (using wrong models):
  scoreConjectureCorrectModels=0.11667,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithDistances1: model ID30 / 35 (random ID1 / 2); time to go=1.07hours


 - Evaluation for twoMassPointsWithDistances1c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for twoMassPointsWithDistances1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for twoMassPointsWithDistances1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for twoMassPointsWithDistances1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for twoMassPointsWithDistances1 (using wrong models):
  scoreConjectureCorrectModels=0.625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.54216,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorSimplySupported0: model ID31 / 35 (random ID0 / 2); time to go=3404.36s


 - Evaluation for rigidRotorSimplySupported0c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for rigidRotorSimplySupported0c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for rigidRotorSimplySupported0c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for rigidRotorSimplySupported0 (using wrong models):
  scoreConjectureCorrectModels=0.9,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.9,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorSimplySupported1: model ID31 / 35 (random ID1 / 2); time to go=2952.04s


 - Evaluation for rigidRotorSimplySupported1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorSimplySupported1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorSimplySupported1c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for rigidRotorSimplySupported1c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for rigidRotorSimplySupported1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for rigidRotorSimplySupported1 (using wrong models):
  scoreConjectureCorrectModels=0.87,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.86792,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorUnbalanced0: model ID32 / 35 (random ID0 / 2); time to go=2517.41s


 - Evaluation for rigidRotorUnbalanced0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced0c2 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced0c3 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced0c4 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced0c5 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced0c6 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for rigidRotorUnbalanced0c7 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for rigidRotorUnbalanced0 (using wrong models):
  scoreConjectureCorrectModels=0.825,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.82391,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorUnbalanced1: model ID32 / 35 (random ID1 / 2); time to go=2101.65s


 - Evaluation for rigidRotorUnbalanced1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced1c2 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced1c3 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for rigidRotorUnbalanced1c4 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for rigidRotorUnbalanced1c5 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for rigidRotorUnbalanced1c6 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for rigidRotorUnbalanced1c7 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for rigidRotorUnbalanced1 (using wrong models):
  scoreConjectureCorrectModels=0.7,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumRigidBodies0: model ID33 / 35 (random ID0 / 2); time to go=1681.62s


 - Evaluation for doublePendulumRigidBodies0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumRigidBodies0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for doublePendulumRigidBodies0c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumRigidBodies0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumRigidBodies0c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.4

 - Evaluation for doublePendulumRigidBodies0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.2


Evaluation summary for doublePendulumRigidBodies0 (using wrong models):
  scoreConjectureCorrectModels=0.4,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumRigidBodies1: model ID33 / 35 (random ID1 / 2); time to go=1261.6s


 - Evaluation for doublePendulumRigidBodies1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumRigidBodies1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumRigidBodies1c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumRigidBodies1c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumRigidBodies1c4 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doublePendulumRigidBodies1c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for doublePendulumRigidBodies1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for doublePendulumRigidBodies1 (using wrong models):
  scoreConjectureCorrectModels=0.51429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankRigidBodies0: model ID34 / 35 (random ID0 / 2); time to go=842.5s


 - Evaluation for sliderCrankRigidBodies0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for sliderCrankRigidBodies0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for sliderCrankRigidBodies0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for sliderCrankRigidBodies0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for sliderCrankRigidBodies0c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for sliderCrankRigidBodies0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for sliderCrankRigidBodies0c7 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for sliderCrankRigidBodies0 (using wrong models):
  scoreConjectureCorrectModels=0.675,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankRigidBodies1: model ID34 / 35 (random ID1 / 2); time to go=421.44s


 - Evaluation for sliderCrankRigidBodies1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for sliderCrankRigidBodies1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for sliderCrankRigidBodies1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for sliderCrankRigidBodies1c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for sliderCrankRigidBodies1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for sliderCrankRigidBodies1c7 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for sliderCrankRigidBodies1 (using wrong models):
  scoreConjectureCorrectModels=0.81429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.73699,  multScoreConjectureWrongModels=-1


***

A total of:
  0 errors and
  0 warnings
were logged!

***

Summary of EvaluateAllConjectures (using wrong models)
 - useSimEvaluationOnly = True
 - sumScoreTotalConjectures = 241.33000000000067
 - nTotalConjectures = 480
 - sumScoreTotalConjectureCorrectModels = 212.63000000000045
 - sumScoreTotalConjectureWrongModels = 28.7
 - nTotalConjectureCorrectModels = 414
 - nTotalConjectureWrongModels = 66
 - sumMultScoreTotalConjectureCorrectModels = 16.352168174123474
 - sumMultScoreTotalConjectureWrongModels = 5.584464718922698
 - nTotalMultConjectureCorrectModels = 65
 - nTotalMultConjectureWrongModels = 18
 - numberOfRemovedTokensGlobal = 0
 - numberOfTokensGlobal = 331711
 - totalScoreConjectureCorrectModels = 0.5135990338164262
 - totalScoreConjectureWrongModels = 0.4348484848484848
 - totalMultScoreConjectureCorrectModels = 0.25157181806343804
 - totalMultScoreConjectureWrongModels = 0.3102480399401499
 - runTime = 29438.150640964508
 - loggerErrors = 0
 - loggerWarnings = 0


