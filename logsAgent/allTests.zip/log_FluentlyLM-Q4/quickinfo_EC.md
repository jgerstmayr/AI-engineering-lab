
***

Evaluate conjectures: nModels=70, nConjPerModel=8, LLM model=FluentlyLM-Prinum.Q4_K_M.gguf

***

EvaluateAllConjectures flyingMassPoint0: model ID0 / 35 (random ID0 / 2)


 - Evaluation for flyingMassPoint0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingMassPoint0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingMassPoint0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingMassPoint0c3: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingMassPoint0c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingMassPoint0c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingMassPoint0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingMassPoint0c7: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for flyingMassPoint0:
  scoreConjectureCorrectModels=0.8875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.8862,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingMassPoint1: model ID0 / 35 (random ID1 / 2); time to go=3.83hours


 - Evaluation for flyingMassPoint1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingMassPoint1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingMassPoint1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingMassPoint1c3: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingMassPoint1c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingMassPoint1c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingMassPoint1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingMassPoint1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for flyingMassPoint1:
  scoreConjectureCorrectModels=0.9125,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.91119,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures freeFallMassPoint0: model ID1 / 35 (random ID0 / 2); time to go=3.85hours


 - Evaluation for freeFallMassPoint0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for freeFallMassPoint0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for freeFallMassPoint0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for freeFallMassPoint0c3: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for freeFallMassPoint0c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for freeFallMassPoint0c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for freeFallMassPoint0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for freeFallMassPoint0:
  scoreConjectureCorrectModels=0.87143,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.8531,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures freeFallMassPoint1: model ID1 / 35 (random ID1 / 2); time to go=4.02hours


 - Evaluation for freeFallMassPoint1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for freeFallMassPoint1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for freeFallMassPoint1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for freeFallMassPoint1c3: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for freeFallMassPoint1c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for freeFallMassPoint1c5: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for freeFallMassPoint1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for freeFallMassPoint1:
  scoreConjectureCorrectModels=0.88333,  scoreConjectureWrongModels=0.5
  multScoreConjectureCorrectModels=0.88211,  multScoreConjectureWrongModels=0.5


***

EvaluateAllConjectures singleMassOscillator0: model ID2 / 35 (random ID0 / 2); time to go=3.72hours


 - Evaluation for singleMassOscillator0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator0c3: method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillator0c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator0c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator0c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator0c7: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for singleMassOscillator0:
  scoreConjectureCorrectModels=0.875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.87397,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillator1: model ID2 / 35 (random ID1 / 2); time to go=3.68hours


 - Evaluation for singleMassOscillator1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator1c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator1c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator1c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator1c7: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for singleMassOscillator1:
  scoreConjectureCorrectModels=0.86429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.86361,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorGravity0: model ID3 / 35 (random ID0 / 2); time to go=3.77hours


 - Evaluation for singleMassOscillatorGravity0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity0c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity0c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity0c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity0c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for singleMassOscillatorGravity0:
  scoreConjectureCorrectModels=0.8,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.78795,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorGravity1: model ID3 / 35 (random ID1 / 2); time to go=3.59hours


 - Evaluation for singleMassOscillatorGravity1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity1c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity1c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity1c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity1c7: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for singleMassOscillatorGravity1:
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankSimple0: model ID4 / 35 (random ID0 / 2); time to go=3.72hours



Evaluation summary for sliderCrankSimple0:
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankSimple1: model ID4 / 35 (random ID1 / 2); time to go=3.25hours


 - Evaluation for sliderCrankSimple1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for sliderCrankSimple1:
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumElasticSpring0: model ID5 / 35 (random ID0 / 2); time to go=2.91hours


 - Evaluation for singlePendulumElasticSpring0c0: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring0c1: method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring0c2: method=Check if planar motion, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring0c3: method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring0c4: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring0c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.25

 - Evaluation for singlePendulumElasticSpring0c6: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring0c7: method=Evaluate symmetry, modelIsCorrect=False, scoreValue=0.85


Evaluation summary for singlePendulumElasticSpring0:
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.775
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.72943


***

EvaluateAllConjectures singlePendulumElasticSpring1: model ID5 / 35 (random ID1 / 2); time to go=3.07hours


 - Evaluation for singlePendulumElasticSpring1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.58

 - Evaluation for singlePendulumElasticSpring1c6: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for singlePendulumElasticSpring1:
  scoreConjectureCorrectModels=0.81143,  scoreConjectureWrongModels=0.85
  multScoreConjectureCorrectModels=0.80483,  multScoreConjectureWrongModels=0.85


***

EvaluateAllConjectures singleMassOscillatorUserFunction0: model ID6 / 35 (random ID0 / 2); time to go=3.09hours


 - Evaluation for singleMassOscillatorUserFunction0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction0c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction0c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction0c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction0c7: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for singleMassOscillatorUserFunction0:
  scoreConjectureCorrectModels=0.86429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.86361,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorUserFunction1: model ID6 / 35 (random ID1 / 2); time to go=3.09hours


 - Evaluation for singleMassOscillatorUserFunction1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction1c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction1c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction1c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction1c7: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for singleMassOscillatorUserFunction1:
  scoreConjectureCorrectModels=0.86429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.86361,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures spinningDisc0: model ID7 / 35 (random ID0 / 2); time to go=3.07hours


 - Evaluation for spinningDisc0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for spinningDisc0c1: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for spinningDisc0c2: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for spinningDisc0c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for spinningDisc0c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for spinningDisc0c6: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for spinningDisc0c7: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for spinningDisc0:
  scoreConjectureCorrectModels=0.66429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.63773,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures spinningDisc1: model ID7 / 35 (random ID1 / 2); time to go=3.01hours


 - Evaluation for spinningDisc1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for spinningDisc1c1: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for spinningDisc1c2: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for spinningDisc1c3: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for spinningDisc1c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for spinningDisc1c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for spinningDisc1c6: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for spinningDisc1c7: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for spinningDisc1:
  scoreConjectureCorrectModels=0.6875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.66105,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doubleMassOscillator0: model ID8 / 35 (random ID0 / 2); time to go=3.01hours


 - Evaluation for doubleMassOscillator0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator0c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator0c4: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator0c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator0c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator0c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for doubleMassOscillator0:
  scoreConjectureCorrectModels=0.8,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.78795,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doubleMassOscillator1: model ID8 / 35 (random ID1 / 2); time to go=3.0hours


 - Evaluation for doubleMassOscillator1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator1c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator1c4: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator1c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator1c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator1c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for doubleMassOscillator1:
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nMassOscillator0: model ID9 / 35 (random ID0 / 2); time to go=3.02hours


 - Evaluation for nMassOscillator0c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nMassOscillator0c2: method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nMassOscillator0c3: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nMassOscillator0c4: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nMassOscillator0c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nMassOscillator0c6: method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nMassOscillator0c7: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.85


Evaluation summary for nMassOscillator0:
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.85
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.85


***

EvaluateAllConjectures nMassOscillator1: model ID9 / 35 (random ID1 / 2); time to go=3.02hours


 - Evaluation for nMassOscillator1c0: method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nMassOscillator1c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nMassOscillator1c2: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nMassOscillator1c3: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nMassOscillator1c4: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nMassOscillator1c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for nMassOscillator1c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nMassOscillator1c7: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for nMassOscillator1:
  scoreConjectureCorrectModels=0.86667,  scoreConjectureWrongModels=0.675
  multScoreConjectureCorrectModels=0.8659,  multScoreConjectureWrongModels=0.65192


***

EvaluateAllConjectures singlePendulum0: model ID10 / 35 (random ID0 / 2); time to go=3.0hours


 - Evaluation for singlePendulum0c0: method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulum0c1: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulum0c2: method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulum0c3: method=Check if planar motion, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for singlePendulum0c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulum0c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulum0c6: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulum0c7: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.5


Evaluation summary for singlePendulum0:
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.80833
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=0.79261


***

EvaluateAllConjectures singlePendulum1: model ID10 / 35 (random ID1 / 2); time to go=2.95hours


 - Evaluation for singlePendulum1c1: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.25

 - Evaluation for singlePendulum1c2: method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulum1c3: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulum1c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulum1c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulum1c6: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for singlePendulum1c7: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.85


Evaluation summary for singlePendulum1:
  scoreConjectureCorrectModels=0.88333,  scoreConjectureWrongModels=0.6125
  multScoreConjectureCorrectModels=0.88211,  multScoreConjectureWrongModels=0.5482


***

EvaluateAllConjectures doublePendulum0: model ID11 / 35 (random ID0 / 2); time to go=2.96hours


 - Evaluation for doublePendulum0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.25

 - Evaluation for doublePendulum0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum0c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.58

 - Evaluation for doublePendulum0c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for doublePendulum0:
  scoreConjectureCorrectModels=0.72571,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.67574,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulum1: model ID11 / 35 (random ID1 / 2); time to go=2.88hours


 - Evaluation for doublePendulum1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum1c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for doublePendulum1c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum1c6: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum1c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for doublePendulum1:
  scoreConjectureCorrectModels=0.73333,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.7122,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nPendulum0: model ID12 / 35 (random ID0 / 2); time to go=2.79hours


 - Evaluation for nPendulum0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulum0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulum0c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulum0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulum0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulum0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for nPendulum0:
  scoreConjectureCorrectModels=0.79167,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.77806,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nPendulum1: model ID12 / 35 (random ID1 / 2); time to go=2.71hours


 - Evaluation for nPendulum1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulum1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulum1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulum1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulum1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulum1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.25

 - Evaluation for nPendulum1c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for nPendulum1:
  scoreConjectureCorrectModels=0.76429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.71366,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures fourBarMechanismPointMasses0: model ID13 / 35 (random ID0 / 2); time to go=2.64hours


 - Evaluation for fourBarMechanismPointMasses0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for fourBarMechanismPointMasses0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for fourBarMechanismPointMasses0c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for fourBarMechanismPointMasses0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.25

 - Evaluation for fourBarMechanismPointMasses0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for fourBarMechanismPointMasses0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for fourBarMechanismPointMasses0c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for fourBarMechanismPointMasses0:
  scoreConjectureCorrectModels=0.77857,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.72509,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures fourBarMechanismPointMasses1: model ID13 / 35 (random ID1 / 2); time to go=2.64hours


 - Evaluation for fourBarMechanismPointMasses1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for fourBarMechanismPointMasses1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for fourBarMechanismPointMasses1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for fourBarMechanismPointMasses1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for fourBarMechanismPointMasses1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for fourBarMechanismPointMasses1c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for fourBarMechanismPointMasses1:
  scoreConjectureCorrectModels=0.86667,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.8659,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures springCoupledFlyingRigidBodies0: model ID14 / 35 (random ID0 / 2); time to go=2.56hours


 - Evaluation for springCoupledFlyingRigidBodies0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for springCoupledFlyingRigidBodies0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for springCoupledFlyingRigidBodies0c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for springCoupledFlyingRigidBodies0c3: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for springCoupledFlyingRigidBodies0c6: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for springCoupledFlyingRigidBodies0c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for springCoupledFlyingRigidBodies0:
  scoreConjectureCorrectModels=0.84167,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.84145,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures springCoupledFlyingRigidBodies1: model ID14 / 35 (random ID1 / 2); time to go=2.51hours


 - Evaluation for springCoupledFlyingRigidBodies1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for springCoupledFlyingRigidBodies1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for springCoupledFlyingRigidBodies1c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for springCoupledFlyingRigidBodies1c3: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for springCoupledFlyingRigidBodies1c4: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for springCoupledFlyingRigidBodies1c6: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for springCoupledFlyingRigidBodies1c7: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for springCoupledFlyingRigidBodies1:
  scoreConjectureCorrectModels=0.86429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.86361,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures torsionalOscillator0: model ID15 / 35 (random ID0 / 2); time to go=2.46hours


 - Evaluation for torsionalOscillator0c0: method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for torsionalOscillator0c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for torsionalOscillator0c2: method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for torsionalOscillator0c3: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for torsionalOscillator0c4: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.25

 - Evaluation for torsionalOscillator0c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for torsionalOscillator0c6: method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for torsionalOscillator0c7: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.85


Evaluation summary for torsionalOscillator0:
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.64375
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.59781


***

EvaluateAllConjectures torsionalOscillator1: model ID15 / 35 (random ID1 / 2); time to go=2.38hours


 - Evaluation for torsionalOscillator1c0: method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.05

 - Evaluation for torsionalOscillator1c1: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for torsionalOscillator1c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for torsionalOscillator1c3: method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for torsionalOscillator1c4: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.25

 - Evaluation for torsionalOscillator1c5: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for torsionalOscillator1c6: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.5


Evaluation summary for torsionalOscillator1:
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.6
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.44136


***

EvaluateAllConjectures invertedSinglePendulum0: model ID16 / 35 (random ID0 / 2); time to go=2.31hours


 - Evaluation for invertedSinglePendulum0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum0c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for invertedSinglePendulum0c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum0c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for invertedSinglePendulum0:
  scoreConjectureCorrectModels=0.80625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.79545,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures invertedSinglePendulum1: model ID16 / 35 (random ID1 / 2); time to go=2.29hours


 - Evaluation for invertedSinglePendulum1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum1c3: method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for invertedSinglePendulum1c4: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for invertedSinglePendulum1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.25

 - Evaluation for invertedSinglePendulum1c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for invertedSinglePendulum1:
  scoreConjectureCorrectModels=0.73,  scoreConjectureWrongModels=0.85
  multScoreConjectureCorrectModels=0.66546,  multScoreConjectureWrongModels=0.85


***

EvaluateAllConjectures discRollingOnGround0: model ID17 / 35 (random ID0 / 2); time to go=2.24hours


 - Evaluation for discRollingOnGround0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for discRollingOnGround0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for discRollingOnGround0c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for discRollingOnGround0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for discRollingOnGround0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for discRollingOnGround0c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for discRollingOnGround0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for discRollingOnGround0c7: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.25


Evaluation summary for discRollingOnGround0:
  scoreConjectureCorrectModels=0.8,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.75,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures discRollingOnGround1: model ID17 / 35 (random ID1 / 2); time to go=2.18hours


 - Evaluation for discRollingOnGround1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for discRollingOnGround1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for discRollingOnGround1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for discRollingOnGround1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for discRollingOnGround1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for discRollingOnGround1c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for discRollingOnGround1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for discRollingOnGround1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for discRollingOnGround1:
  scoreConjectureCorrectModels=0.81875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.80659,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumElasticSpring0: model ID18 / 35 (random ID0 / 2); time to go=2.16hours


 - Evaluation for doublePendulumElasticSpring0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumElasticSpring0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumElasticSpring0c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for doublePendulumElasticSpring0c4: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumElasticSpring0c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumElasticSpring0c7: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for doublePendulumElasticSpring0:
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.5
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=0.5


***

EvaluateAllConjectures doublePendulumElasticSpring1: model ID18 / 35 (random ID1 / 2); time to go=2.09hours


 - Evaluation for doublePendulumElasticSpring1c0: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for doublePendulumElasticSpring1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumElasticSpring1c2: method=Evaluate static equilibrium for damped systems, modelIsCorrect=False, scoreValue=0.25

 - Evaluation for doublePendulumElasticSpring1c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for doublePendulumElasticSpring1c4: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumElasticSpring1c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumElasticSpring1c7: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for doublePendulumElasticSpring1:
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.53333
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=0.47363


***

EvaluateAllConjectures nPendulumElasticSpring0: model ID19 / 35 (random ID0 / 2); time to go=2.02hours


 - Evaluation for nPendulumElasticSpring0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring0c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for nPendulumElasticSpring0c3: method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring0c4: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring0c5: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring0c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring0c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for nPendulumElasticSpring0:
  scoreConjectureCorrectModels=0.75,  scoreConjectureWrongModels=0.85
  multScoreConjectureCorrectModels=0.73043,  multScoreConjectureWrongModels=0.85


***

EvaluateAllConjectures nPendulumElasticSpring1: model ID19 / 35 (random ID1 / 2); time to go=1.98hours


 - Evaluation for nPendulumElasticSpring1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring1c2: method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for nPendulumElasticSpring1c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring1c4: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring1c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring1c6: method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring1c7: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.85


Evaluation summary for nPendulumElasticSpring1:
  scoreConjectureCorrectModels=0.78,  scoreConjectureWrongModels=0.85
  multScoreConjectureCorrectModels=0.76441,  multScoreConjectureWrongModels=0.85


***

EvaluateAllConjectures elasticChain0: model ID20 / 35 (random ID0 / 2); time to go=1.92hours


 - Evaluation for elasticChain0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain0c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain0c4: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain0c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for elasticChain0c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain0c7: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for elasticChain0:
  scoreConjectureCorrectModels=0.75,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.73043,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures elasticChain1: model ID20 / 35 (random ID1 / 2); time to go=1.87hours


 - Evaluation for elasticChain1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain1c2: method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for elasticChain1c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain1c4: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain1c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain1c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain1c7: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for elasticChain1:
  scoreConjectureCorrectModels=0.875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.87397,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumRigidBody0: model ID21 / 35 (random ID0 / 2); time to go=1.82hours


 - Evaluation for singlePendulumRigidBody0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody0c3: method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for singlePendulumRigidBody0c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for singlePendulumRigidBody0c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody0c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody0c7: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for singlePendulumRigidBody0:
  scoreConjectureCorrectModels=0.7625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.7444,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumRigidBody1: model ID21 / 35 (random ID1 / 2); time to go=1.75hours


 - Evaluation for singlePendulumRigidBody1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody1c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for singlePendulumRigidBody1c4: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody1c5: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody1c6: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody1c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for singlePendulumRigidBody1:
  scoreConjectureCorrectModels=0.7625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.7444,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringRigid0: model ID22 / 35 (random ID0 / 2); time to go=1.69hours


 - Evaluation for massPointOnStringRigid0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid0c1: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringRigid0c2: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid0c3: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid0c4: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid0c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for massPointOnStringRigid0:
  scoreConjectureCorrectModels=0.86429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.86361,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringRigid1: model ID22 / 35 (random ID1 / 2); time to go=1.64hours


 - Evaluation for massPointOnStringRigid1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid1c2: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid1c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for massPointOnStringRigid1:
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringElastic0: model ID23 / 35 (random ID0 / 2); time to go=1.58hours


 - Evaluation for massPointOnStringElastic0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic0c2: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic0c3: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic0c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic0c5: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for massPointOnStringElastic0c6: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic0c7: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.25


Evaluation summary for massPointOnStringElastic0:
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.55
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=0.46098


***

EvaluateAllConjectures massPointOnStringElastic1: model ID23 / 35 (random ID1 / 2); time to go=1.54hours


 - Evaluation for massPointOnStringElastic1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic1c2: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic1c3: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic1c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic1c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic1c6: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic1c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for massPointOnStringElastic1:
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures linkOnTwoPrismaticJoints0: model ID24 / 35 (random ID0 / 2); time to go=1.49hours


 - Evaluation for linkOnTwoPrismaticJoints0c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for linkOnTwoPrismaticJoints0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for linkOnTwoPrismaticJoints0c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for linkOnTwoPrismaticJoints0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for linkOnTwoPrismaticJoints0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for linkOnTwoPrismaticJoints0c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for linkOnTwoPrismaticJoints0:
  scoreConjectureCorrectModels=0.79167,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.77806,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures linkOnTwoPrismaticJoints1: model ID24 / 35 (random ID1 / 2); time to go=1.42hours


 - Evaluation for linkOnTwoPrismaticJoints1c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for linkOnTwoPrismaticJoints1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for linkOnTwoPrismaticJoints1c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for linkOnTwoPrismaticJoints1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for linkOnTwoPrismaticJoints1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for linkOnTwoPrismaticJoints1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for linkOnTwoPrismaticJoints1c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for linkOnTwoPrismaticJoints1:
  scoreConjectureCorrectModels=0.81429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.80057,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingRigidBody0: model ID25 / 35 (random ID0 / 2); time to go=1.37hours


 - Evaluation for flyingRigidBody0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingRigidBody0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingRigidBody0c2: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingRigidBody0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for flyingRigidBody0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.05

 - Evaluation for flyingRigidBody0c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for flyingRigidBody0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for flyingRigidBody0c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for flyingRigidBody0:
  scoreConjectureCorrectModels=0.63125,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.49572,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingRigidBody1: model ID25 / 35 (random ID1 / 2); time to go=1.3hours


 - Evaluation for flyingRigidBody1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingRigidBody1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingRigidBody1c2: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingRigidBody1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingRigidBody1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingRigidBody1c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingRigidBody1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingRigidBody1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for flyingRigidBody1:
  scoreConjectureCorrectModels=0.875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.87397,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures suspendedRigidBody0: model ID26 / 35 (random ID0 / 2); time to go=1.23hours


 - Evaluation for suspendedRigidBody0c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody0c2: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for suspendedRigidBody0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody0c5: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody0c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for suspendedRigidBody0:
  scoreConjectureCorrectModels=0.86429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.86361,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures suspendedRigidBody1: model ID26 / 35 (random ID1 / 2); time to go=1.16hours


 - Evaluation for suspendedRigidBody1c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody1c2: method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for suspendedRigidBody1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody1c4: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for suspendedRigidBody1c5: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for suspendedRigidBody1:
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.9
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=0.89861


***

EvaluateAllConjectures gyroscopeOnSphericalJoint0: model ID27 / 35 (random ID0 / 2); time to go=1.1hours


 - Evaluation for gyroscopeOnSphericalJoint0c0: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for gyroscopeOnSphericalJoint0c1: method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for gyroscopeOnSphericalJoint0c2: method=Check if spherical motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for gyroscopeOnSphericalJoint0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for gyroscopeOnSphericalJoint0c4: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for gyroscopeOnSphericalJoint0c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for gyroscopeOnSphericalJoint0c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for gyroscopeOnSphericalJoint0:
  scoreConjectureCorrectModels=0.88333,  scoreConjectureWrongModels=0.675
  multScoreConjectureCorrectModels=0.88211,  multScoreConjectureWrongModels=0.65192


***

EvaluateAllConjectures gyroscopeOnSphericalJoint1: model ID27 / 35 (random ID1 / 2); time to go=1.03hours


 - Evaluation for gyroscopeOnSphericalJoint1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for gyroscopeOnSphericalJoint1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for gyroscopeOnSphericalJoint1c2: method=Check if spherical motion, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for gyroscopeOnSphericalJoint1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for gyroscopeOnSphericalJoint1c4: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for gyroscopeOnSphericalJoint1c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for gyroscopeOnSphericalJoint1c6: method=Evaluate symmetry, modelIsCorrect=False, scoreValue=0.85


Evaluation summary for gyroscopeOnSphericalJoint1:
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.7
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=0.6703


***

EvaluateAllConjectures prismaticJointSystem0: model ID28 / 35 (random ID0 / 2); time to go=3498.34s


 - Evaluation for prismaticJointSystem0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for prismaticJointSystem0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for prismaticJointSystem0c2: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for prismaticJointSystem0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for prismaticJointSystem0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for prismaticJointSystem0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for prismaticJointSystem0:
  scoreConjectureCorrectModels=0.88333,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.88211,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures prismaticJointSystem1: model ID28 / 35 (random ID1 / 2); time to go=3231.21s


 - Evaluation for prismaticJointSystem1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for prismaticJointSystem1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for prismaticJointSystem1c2: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for prismaticJointSystem1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for prismaticJointSystem1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for prismaticJointSystem1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for prismaticJointSystem1c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for prismaticJointSystem1:
  scoreConjectureCorrectModels=0.92143,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.92028,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithSprings0: model ID29 / 35 (random ID0 / 2); time to go=2972.08s


 - Evaluation for twoMassPointsWithSprings0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithSprings0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithSprings0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithSprings0c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for twoMassPointsWithSprings0c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for twoMassPointsWithSprings0:
  scoreConjectureCorrectModels=0.91,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.90866,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithSprings1: model ID29 / 35 (random ID1 / 2); time to go=2727.3s


 - Evaluation for twoMassPointsWithSprings1c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for twoMassPointsWithSprings1c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for twoMassPointsWithSprings1c4: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithSprings1c6: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for twoMassPointsWithSprings1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for twoMassPointsWithSprings1:
  scoreConjectureCorrectModels=0.87,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.86912,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithDistances0: model ID30 / 35 (random ID0 / 2); time to go=2464.28s


 - Evaluation for twoMassPointsWithDistances0c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for twoMassPointsWithDistances0c2: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithDistances0c3: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for twoMassPointsWithDistances0c5: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.25

 - Evaluation for twoMassPointsWithDistances0c6: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for twoMassPointsWithDistances0c7: method=Perform a rough calculation, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for twoMassPointsWithDistances0:
  scoreConjectureCorrectModels=0.725,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.65846,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithDistances1: model ID30 / 35 (random ID1 / 2); time to go=2230.13s


 - Evaluation for twoMassPointsWithDistances1c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for twoMassPointsWithDistances1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for twoMassPointsWithDistances1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for twoMassPointsWithDistances1c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for twoMassPointsWithDistances1:
  scoreConjectureCorrectModels=0.7625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.7444,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorSimplySupported0: model ID31 / 35 (random ID0 / 2); time to go=1969.84s


 - Evaluation for rigidRotorSimplySupported0c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorSimplySupported0c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorSimplySupported0c3: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for rigidRotorSimplySupported0:
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorSimplySupported1: model ID31 / 35 (random ID1 / 2); time to go=1714.61s


 - Evaluation for rigidRotorSimplySupported1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorSimplySupported1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorSimplySupported1c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorSimplySupported1c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorSimplySupported1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for rigidRotorSimplySupported1:
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorUnbalanced0: model ID32 / 35 (random ID0 / 2); time to go=1475.64s


 - Evaluation for rigidRotorUnbalanced0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced0c2: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced0c3: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced0c4: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for rigidRotorUnbalanced0c5: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced0c6: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced0c7: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for rigidRotorUnbalanced0:
  scoreConjectureCorrectModels=0.80625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.79545,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorUnbalanced1: model ID32 / 35 (random ID1 / 2); time to go=1239.45s


 - Evaluation for rigidRotorUnbalanced1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced1c2: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced1c3: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced1c4: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for rigidRotorUnbalanced1c5: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced1c6: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced1c7: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for rigidRotorUnbalanced1:
  scoreConjectureCorrectModels=0.80625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.79545,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumRigidBodies0: model ID33 / 35 (random ID0 / 2); time to go=1001.58s


 - Evaluation for doublePendulumRigidBodies0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumRigidBodies0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumRigidBodies0c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for doublePendulumRigidBodies0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumRigidBodies0c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for doublePendulumRigidBodies0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for doublePendulumRigidBodies0:
  scoreConjectureCorrectModels=0.675,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.65192,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumRigidBodies1: model ID33 / 35 (random ID1 / 2); time to go=753.86s


 - Evaluation for doublePendulumRigidBodies1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumRigidBodies1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumRigidBodies1c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for doublePendulumRigidBodies1c3: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for doublePendulumRigidBodies1c4: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doublePendulumRigidBodies1c6: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for doublePendulumRigidBodies1c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for doublePendulumRigidBodies1:
  scoreConjectureCorrectModels=0.66429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.63773,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankRigidBodies0: model ID34 / 35 (random ID0 / 2); time to go=503.03s


 - Evaluation for sliderCrankRigidBodies0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for sliderCrankRigidBodies0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for sliderCrankRigidBodies0c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for sliderCrankRigidBodies0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for sliderCrankRigidBodies0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for sliderCrankRigidBodies0c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for sliderCrankRigidBodies0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for sliderCrankRigidBodies0c7: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for sliderCrankRigidBodies0:
  scoreConjectureCorrectModels=0.81875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.80659,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankRigidBodies1: model ID34 / 35 (random ID1 / 2); time to go=253.52s


 - Evaluation for sliderCrankRigidBodies1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for sliderCrankRigidBodies1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for sliderCrankRigidBodies1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for sliderCrankRigidBodies1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for sliderCrankRigidBodies1c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for sliderCrankRigidBodies1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for sliderCrankRigidBodies1c7: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for sliderCrankRigidBodies1:
  scoreConjectureCorrectModels=0.81429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.80057,  multScoreConjectureWrongModels=-1


***

A total of:
  0 errors and
  0 warnings
were logged!

***

Summary of EvaluateAllConjectures
 - useSimEvaluationOnly = True
 - sumScoreTotalConjectures = 384.4600000000012
 - nTotalConjectures = 480
 - sumScoreTotalConjectureCorrectModels = 337.3600000000003
 - sumScoreTotalConjectureWrongModels = 47.10000000000004
 - nTotalConjectureCorrectModels = 414
 - nTotalConjectureWrongModels = 66
 - sumMultScoreTotalConjectureCorrectModels = 52.28455947060555
 - sumMultScoreTotalConjectureWrongModels = 12.166780047454456
 - nTotalMultConjectureCorrectModels = 65
 - nTotalMultConjectureWrongModels = 18
 - numberOfRemovedTokensGlobal = 497
 - numberOfTokensGlobal = 489725
 - totalScoreConjectureCorrectModels = 0.8148792270531409
 - totalScoreConjectureWrongModels = 0.7136363636363642
 - totalMultScoreConjectureCorrectModels = 0.8043778380093162
 - totalMultScoreConjectureWrongModels = 0.6759322248585808
 - runTime = 17896.699152469635
 - loggerErrors = 0
 - loggerWarnings = 0



***

Evaluate conjectures (using wrong models): nModels=70, nConjPerModel=8, LLM model=FluentlyLM-Prinum.Q4_K_M.gguf

***

EvaluateAllConjectures flyingMassPoint0: model ID0 / 35 (random ID0 / 2)


 - Evaluation for flyingMassPoint0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingMassPoint0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingMassPoint0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingMassPoint0c3 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingMassPoint0c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingMassPoint0c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingMassPoint0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.25

 - Evaluation for flyingMassPoint0c7 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.25


Evaluation summary for flyingMassPoint0 (using wrong models):
  scoreConjectureCorrectModels=0.725,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.64361,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingMassPoint1: model ID0 / 35 (random ID1 / 2); time to go=4.32hours


 - Evaluation for flyingMassPoint1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingMassPoint1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingMassPoint1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingMassPoint1c3 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingMassPoint1c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for flyingMassPoint1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingMassPoint1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingMassPoint1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for flyingMassPoint1 (using wrong models):
  scoreConjectureCorrectModels=0.83125,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.81788,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures freeFallMassPoint0: model ID1 / 35 (random ID0 / 2); time to go=5.0hours


 - Evaluation for freeFallMassPoint0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for freeFallMassPoint0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for freeFallMassPoint0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for freeFallMassPoint0c3 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.25

 - Evaluation for freeFallMassPoint0c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for freeFallMassPoint0c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for freeFallMassPoint0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for freeFallMassPoint0 (using wrong models):
  scoreConjectureCorrectModels=0.70714,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.64321,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures freeFallMassPoint1: model ID1 / 35 (random ID1 / 2); time to go=4.44hours


 - Evaluation for freeFallMassPoint1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for freeFallMassPoint1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for freeFallMassPoint1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for freeFallMassPoint1c3 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for freeFallMassPoint1c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for freeFallMassPoint1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for freeFallMassPoint1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for freeFallMassPoint1 (using wrong models):
  scoreConjectureCorrectModels=0.86667,  scoreConjectureWrongModels=0.85
  multScoreConjectureCorrectModels=0.8659,  multScoreConjectureWrongModels=0.85


***

EvaluateAllConjectures singleMassOscillator0: model ID2 / 35 (random ID0 / 2); time to go=4.25hours


 - Evaluation for singleMassOscillator0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator0c3 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator0c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator0c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator0c7 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for singleMassOscillator0 (using wrong models):
  scoreConjectureCorrectModels=0.8625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.8619,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillator1: model ID2 / 35 (random ID1 / 2); time to go=3.94hours


 - Evaluation for singleMassOscillator1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator1c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator1c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator1c7 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for singleMassOscillator1 (using wrong models):
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorGravity0: model ID3 / 35 (random ID0 / 2); time to go=3.96hours


 - Evaluation for singleMassOscillatorGravity0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity0c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity0c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for singleMassOscillatorGravity0 (using wrong models):
  scoreConjectureCorrectModels=0.8,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.78795,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorGravity1: model ID3 / 35 (random ID1 / 2); time to go=4.17hours


 - Evaluation for singleMassOscillatorGravity1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity1c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity1c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity1c7 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for singleMassOscillatorGravity1 (using wrong models):
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankSimple0: model ID4 / 35 (random ID0 / 2); time to go=4.21hours



Evaluation summary for sliderCrankSimple0 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankSimple1: model ID4 / 35 (random ID1 / 2); time to go=3.68hours


 - Evaluation for sliderCrankSimple1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for sliderCrankSimple1 (using wrong models):
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumElasticSpring0: model ID5 / 35 (random ID0 / 2); time to go=3.29hours


 - Evaluation for singlePendulumElasticSpring0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.25

 - Evaluation for singlePendulumElasticSpring0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring0c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=False, scoreValue=0.85


Evaluation summary for singlePendulumElasticSpring0 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.775
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.72943


***

EvaluateAllConjectures singlePendulumElasticSpring1: model ID5 / 35 (random ID1 / 2); time to go=3.39hours


 - Evaluation for singlePendulumElasticSpring1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.58

 - Evaluation for singlePendulumElasticSpring1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for singlePendulumElasticSpring1 (using wrong models):
  scoreConjectureCorrectModels=0.81143,  scoreConjectureWrongModels=0.85
  multScoreConjectureCorrectModels=0.80483,  multScoreConjectureWrongModels=0.85


***

EvaluateAllConjectures singleMassOscillatorUserFunction0: model ID6 / 35 (random ID0 / 2); time to go=3.42hours


 - Evaluation for singleMassOscillatorUserFunction0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction0c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction0c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction0c7 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for singleMassOscillatorUserFunction0 (using wrong models):
  scoreConjectureCorrectModels=0.86429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.86361,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorUserFunction1: model ID6 / 35 (random ID1 / 2); time to go=3.46hours


 - Evaluation for singleMassOscillatorUserFunction1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction1c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction1c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction1c7 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for singleMassOscillatorUserFunction1 (using wrong models):
  scoreConjectureCorrectModels=0.86429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.86361,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures spinningDisc0: model ID7 / 35 (random ID0 / 2); time to go=3.38hours


 - Evaluation for spinningDisc0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for spinningDisc0c1 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for spinningDisc0c2 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for spinningDisc0c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for spinningDisc0c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for spinningDisc0c6 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for spinningDisc0c7 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for spinningDisc0 (using wrong models):
  scoreConjectureCorrectModels=0.65,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.62767,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures spinningDisc1: model ID7 / 35 (random ID1 / 2); time to go=3.25hours


 - Evaluation for spinningDisc1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for spinningDisc1c1 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for spinningDisc1c2 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for spinningDisc1c3 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for spinningDisc1c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for spinningDisc1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for spinningDisc1c6 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for spinningDisc1c7 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for spinningDisc1 (using wrong models):
  scoreConjectureCorrectModels=0.675,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.65192,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doubleMassOscillator0: model ID8 / 35 (random ID0 / 2); time to go=3.28hours


 - Evaluation for doubleMassOscillator0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator0c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator0c4 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator0c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for doubleMassOscillator0 (using wrong models):
  scoreConjectureCorrectModels=0.8,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.78795,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doubleMassOscillator1: model ID8 / 35 (random ID1 / 2); time to go=3.33hours


 - Evaluation for doubleMassOscillator1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator1c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator1c4 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator1c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for doubleMassOscillator1 (using wrong models):
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nMassOscillator0: model ID9 / 35 (random ID0 / 2); time to go=3.27hours


 - Evaluation for nMassOscillator0c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nMassOscillator0c2 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nMassOscillator0c3 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nMassOscillator0c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nMassOscillator0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for nMassOscillator0c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nMassOscillator0c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.85


Evaluation summary for nMassOscillator0 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.8
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.78795


***

EvaluateAllConjectures nMassOscillator1: model ID9 / 35 (random ID1 / 2); time to go=3.31hours


 - Evaluation for nMassOscillator1c0 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nMassOscillator1c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nMassOscillator1c2 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nMassOscillator1c3 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nMassOscillator1c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nMassOscillator1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for nMassOscillator1c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nMassOscillator1c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for nMassOscillator1 (using wrong models):
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.675
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=0.65192


***

EvaluateAllConjectures singlePendulum0: model ID10 / 35 (random ID0 / 2); time to go=3.2hours


 - Evaluation for singlePendulum0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulum0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulum0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulum0c3 (using wrong models): method=Check if planar motion, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for singlePendulum0c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulum0c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulum0c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulum0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.85


Evaluation summary for singlePendulum0 (using wrong models):
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.86667
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=0.8659


***

EvaluateAllConjectures singlePendulum1: model ID10 / 35 (random ID1 / 2); time to go=3.15hours


 - Evaluation for singlePendulum1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.25

 - Evaluation for singlePendulum1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulum1c3 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulum1c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulum1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulum1c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for singlePendulum1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.85


Evaluation summary for singlePendulum1 (using wrong models):
  scoreConjectureCorrectModels=0.88333,  scoreConjectureWrongModels=0.6125
  multScoreConjectureCorrectModels=0.88211,  multScoreConjectureWrongModels=0.5482


***

EvaluateAllConjectures doublePendulum0: model ID11 / 35 (random ID0 / 2); time to go=3.12hours


 - Evaluation for doublePendulum0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for doublePendulum0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum0c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for doublePendulum0c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for doublePendulum0 (using wrong models):
  scoreConjectureCorrectModels=0.75,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.73043,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulum1: model ID11 / 35 (random ID1 / 2); time to go=3.06hours


 - Evaluation for doublePendulum1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum1c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum1c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for doublePendulum1 (using wrong models):
  scoreConjectureCorrectModels=0.79167,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.77806,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nPendulum0: model ID12 / 35 (random ID0 / 2); time to go=3.01hours


 - Evaluation for nPendulum0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for nPendulum0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulum0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulum0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for nPendulum0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for nPendulum0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for nPendulum0 (using wrong models):
  scoreConjectureCorrectModels=0.61667,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.59674,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nPendulum1: model ID12 / 35 (random ID1 / 2); time to go=2.92hours


 - Evaluation for nPendulum1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for nPendulum1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for nPendulum1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulum1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulum1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for nPendulum1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.25

 - Evaluation for nPendulum1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.58


Evaluation summary for nPendulum1 (using wrong models):
  scoreConjectureCorrectModels=0.57571,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.53829,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures fourBarMechanismPointMasses0: model ID13 / 35 (random ID0 / 2); time to go=2.83hours


 - Evaluation for fourBarMechanismPointMasses0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for fourBarMechanismPointMasses0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for fourBarMechanismPointMasses0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for fourBarMechanismPointMasses0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.25

 - Evaluation for fourBarMechanismPointMasses0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for fourBarMechanismPointMasses0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for fourBarMechanismPointMasses0c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for fourBarMechanismPointMasses0 (using wrong models):
  scoreConjectureCorrectModels=0.77857,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.72509,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures fourBarMechanismPointMasses1: model ID13 / 35 (random ID1 / 2); time to go=2.8hours


 - Evaluation for fourBarMechanismPointMasses1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for fourBarMechanismPointMasses1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for fourBarMechanismPointMasses1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for fourBarMechanismPointMasses1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for fourBarMechanismPointMasses1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for fourBarMechanismPointMasses1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for fourBarMechanismPointMasses1 (using wrong models):
  scoreConjectureCorrectModels=0.86667,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.8659,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures springCoupledFlyingRigidBodies0: model ID14 / 35 (random ID0 / 2); time to go=2.73hours


 - Evaluation for springCoupledFlyingRigidBodies0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for springCoupledFlyingRigidBodies0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for springCoupledFlyingRigidBodies0c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for springCoupledFlyingRigidBodies0c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for springCoupledFlyingRigidBodies0c6 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for springCoupledFlyingRigidBodies0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for springCoupledFlyingRigidBodies0 (using wrong models):
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures springCoupledFlyingRigidBodies1: model ID14 / 35 (random ID1 / 2); time to go=2.68hours


 - Evaluation for springCoupledFlyingRigidBodies1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for springCoupledFlyingRigidBodies1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for springCoupledFlyingRigidBodies1c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for springCoupledFlyingRigidBodies1c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for springCoupledFlyingRigidBodies1c4 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for springCoupledFlyingRigidBodies1c6 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for springCoupledFlyingRigidBodies1c7 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for springCoupledFlyingRigidBodies1 (using wrong models):
  scoreConjectureCorrectModels=0.87143,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.86997,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures torsionalOscillator0: model ID15 / 35 (random ID0 / 2); time to go=2.64hours


 - Evaluation for torsionalOscillator0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.05

 - Evaluation for torsionalOscillator0c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for torsionalOscillator0c2 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for torsionalOscillator0c3 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.05

 - Evaluation for torsionalOscillator0c4 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.25

 - Evaluation for torsionalOscillator0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for torsionalOscillator0c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for torsionalOscillator0c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.5


Evaluation summary for torsionalOscillator0 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.44375
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.29441


***

EvaluateAllConjectures torsionalOscillator1: model ID15 / 35 (random ID1 / 2); time to go=2.57hours


 - Evaluation for torsionalOscillator1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.25

 - Evaluation for torsionalOscillator1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for torsionalOscillator1c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for torsionalOscillator1c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for torsionalOscillator1c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.25

 - Evaluation for torsionalOscillator1c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.05

 - Evaluation for torsionalOscillator1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.5


Evaluation summary for torsionalOscillator1 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.51429
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.37057


***

EvaluateAllConjectures invertedSinglePendulum0: model ID16 / 35 (random ID0 / 2); time to go=2.51hours


 - Evaluation for invertedSinglePendulum0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.25

 - Evaluation for invertedSinglePendulum0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum0c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for invertedSinglePendulum0 (using wrong models):
  scoreConjectureCorrectModels=0.775,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.72943,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures invertedSinglePendulum1: model ID16 / 35 (random ID1 / 2); time to go=2.47hours


 - Evaluation for invertedSinglePendulum1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for invertedSinglePendulum1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for invertedSinglePendulum1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.25

 - Evaluation for invertedSinglePendulum1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for invertedSinglePendulum1 (using wrong models):
  scoreConjectureCorrectModels=0.73,  scoreConjectureWrongModels=0.85
  multScoreConjectureCorrectModels=0.66546,  multScoreConjectureWrongModels=0.85


***

EvaluateAllConjectures discRollingOnGround0: model ID17 / 35 (random ID0 / 2); time to go=2.39hours


 - Evaluation for discRollingOnGround0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for discRollingOnGround0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.25

 - Evaluation for discRollingOnGround0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for discRollingOnGround0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for discRollingOnGround0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for discRollingOnGround0c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for discRollingOnGround0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for discRollingOnGround0c7 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.25


Evaluation summary for discRollingOnGround0 (using wrong models):
  scoreConjectureCorrectModels=0.7125,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.63473,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures discRollingOnGround1: model ID17 / 35 (random ID1 / 2); time to go=2.35hours


 - Evaluation for discRollingOnGround1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for discRollingOnGround1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for discRollingOnGround1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for discRollingOnGround1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for discRollingOnGround1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for discRollingOnGround1c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for discRollingOnGround1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for discRollingOnGround1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for discRollingOnGround1 (using wrong models):
  scoreConjectureCorrectModels=0.775,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.75482,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumElasticSpring0: model ID18 / 35 (random ID0 / 2); time to go=2.34hours


 - Evaluation for doublePendulumElasticSpring0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumElasticSpring0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumElasticSpring0c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for doublePendulumElasticSpring0c4 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumElasticSpring0c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumElasticSpring0c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for doublePendulumElasticSpring0 (using wrong models):
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.5
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=0.5


***

EvaluateAllConjectures doublePendulumElasticSpring1: model ID18 / 35 (random ID1 / 2); time to go=2.24hours


 - Evaluation for doublePendulumElasticSpring1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for doublePendulumElasticSpring1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumElasticSpring1c2 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=False, scoreValue=0.25

 - Evaluation for doublePendulumElasticSpring1c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for doublePendulumElasticSpring1c4 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumElasticSpring1c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumElasticSpring1c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for doublePendulumElasticSpring1 (using wrong models):
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.53333
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=0.47363


***

EvaluateAllConjectures nPendulumElasticSpring0: model ID19 / 35 (random ID0 / 2); time to go=2.19hours


 - Evaluation for nPendulumElasticSpring0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring0c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for nPendulumElasticSpring0c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring0c4 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring0c5 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring0c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for nPendulumElasticSpring0 (using wrong models):
  scoreConjectureCorrectModels=0.75,  scoreConjectureWrongModels=0.85
  multScoreConjectureCorrectModels=0.73043,  multScoreConjectureWrongModels=0.85


***

EvaluateAllConjectures nPendulumElasticSpring1: model ID19 / 35 (random ID1 / 2); time to go=2.15hours


 - Evaluation for nPendulumElasticSpring1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring1c2 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for nPendulumElasticSpring1c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring1c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring1c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring1c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring1c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.85


Evaluation summary for nPendulumElasticSpring1 (using wrong models):
  scoreConjectureCorrectModels=0.78,  scoreConjectureWrongModels=0.85
  multScoreConjectureCorrectModels=0.76441,  multScoreConjectureWrongModels=0.85


***

EvaluateAllConjectures elasticChain0: model ID20 / 35 (random ID0 / 2); time to go=2.09hours


 - Evaluation for elasticChain0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain0c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain0c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain0c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for elasticChain0c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for elasticChain0c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for elasticChain0 (using wrong models):
  scoreConjectureCorrectModels=0.7,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.6771,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures elasticChain1: model ID20 / 35 (random ID1 / 2); time to go=2.01hours


 - Evaluation for elasticChain1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain1c2 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for elasticChain1c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain1c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain1c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain1c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain1c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for elasticChain1 (using wrong models):
  scoreConjectureCorrectModels=0.875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.87397,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumRigidBody0: model ID21 / 35 (random ID0 / 2); time to go=1.95hours


 - Evaluation for singlePendulumRigidBody0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody0c3 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody0c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for singlePendulumRigidBody0c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody0c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody0c7 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for singlePendulumRigidBody0 (using wrong models):
  scoreConjectureCorrectModels=0.80625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.79545,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumRigidBody1: model ID21 / 35 (random ID1 / 2); time to go=1.87hours


 - Evaluation for singlePendulumRigidBody1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody1c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for singlePendulumRigidBody1c4 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody1c5 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody1c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for singlePendulumRigidBody1 (using wrong models):
  scoreConjectureCorrectModels=0.7625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.7444,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringRigid0: model ID22 / 35 (random ID0 / 2); time to go=1.8hours


 - Evaluation for massPointOnStringRigid0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid0c1 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid0c2 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid0c3 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid0c4 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid0c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for massPointOnStringRigid0 (using wrong models):
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringRigid1: model ID22 / 35 (random ID1 / 2); time to go=1.74hours


 - Evaluation for massPointOnStringRigid1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.25

 - Evaluation for massPointOnStringRigid1c2 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.25

 - Evaluation for massPointOnStringRigid1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid1c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.25


Evaluation summary for massPointOnStringRigid1 (using wrong models):
  scoreConjectureCorrectModels=0.625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.53717,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringElastic0: model ID23 / 35 (random ID0 / 2); time to go=1.68hours


 - Evaluation for massPointOnStringElastic0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic0c2 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic0c3 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.25

 - Evaluation for massPointOnStringElastic0c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic0c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for massPointOnStringElastic0c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.25


Evaluation summary for massPointOnStringElastic0 (using wrong models):
  scoreConjectureCorrectModels=0.75,  scoreConjectureWrongModels=0.55
  multScoreConjectureCorrectModels=0.69317,  multScoreConjectureWrongModels=0.46098


***

EvaluateAllConjectures massPointOnStringElastic1: model ID23 / 35 (random ID1 / 2); time to go=1.61hours


 - Evaluation for massPointOnStringElastic1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.58

 - Evaluation for massPointOnStringElastic1c2 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic1c3 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.25

 - Evaluation for massPointOnStringElastic1c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic1c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for massPointOnStringElastic1 (using wrong models):
  scoreConjectureCorrectModels=0.74125,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.6954,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures linkOnTwoPrismaticJoints0: model ID24 / 35 (random ID0 / 2); time to go=1.55hours


 - Evaluation for linkOnTwoPrismaticJoints0c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for linkOnTwoPrismaticJoints0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for linkOnTwoPrismaticJoints0c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for linkOnTwoPrismaticJoints0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for linkOnTwoPrismaticJoints0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for linkOnTwoPrismaticJoints0c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for linkOnTwoPrismaticJoints0 (using wrong models):
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures linkOnTwoPrismaticJoints1: model ID24 / 35 (random ID1 / 2); time to go=1.48hours


 - Evaluation for linkOnTwoPrismaticJoints1c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for linkOnTwoPrismaticJoints1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for linkOnTwoPrismaticJoints1c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for linkOnTwoPrismaticJoints1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for linkOnTwoPrismaticJoints1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for linkOnTwoPrismaticJoints1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for linkOnTwoPrismaticJoints1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for linkOnTwoPrismaticJoints1 (using wrong models):
  scoreConjectureCorrectModels=0.75,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.73043,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingRigidBody0: model ID25 / 35 (random ID0 / 2); time to go=1.4hours


 - Evaluation for flyingRigidBody0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingRigidBody0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.25

 - Evaluation for flyingRigidBody0c2 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingRigidBody0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.25

 - Evaluation for flyingRigidBody0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody0c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for flyingRigidBody0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.25

 - Evaluation for flyingRigidBody0c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for flyingRigidBody0 (using wrong models):
  scoreConjectureCorrectModels=0.44375,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingRigidBody1: model ID25 / 35 (random ID1 / 2); time to go=1.34hours


 - Evaluation for flyingRigidBody1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingRigidBody1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingRigidBody1c2 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingRigidBody1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for flyingRigidBody1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for flyingRigidBody1c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for flyingRigidBody1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.65

 - Evaluation for flyingRigidBody1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for flyingRigidBody1 (using wrong models):
  scoreConjectureCorrectModels=0.75,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.72993,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures suspendedRigidBody0: model ID26 / 35 (random ID0 / 2); time to go=1.28hours


 - Evaluation for suspendedRigidBody0c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody0c2 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for suspendedRigidBody0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody0c5 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody0c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for suspendedRigidBody0 (using wrong models):
  scoreConjectureCorrectModels=0.86429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.86361,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures suspendedRigidBody1: model ID26 / 35 (random ID1 / 2); time to go=1.2hours


 - Evaluation for suspendedRigidBody1c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody1c2 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for suspendedRigidBody1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for suspendedRigidBody1c5 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for suspendedRigidBody1 (using wrong models):
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.925
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=0.92195


***

EvaluateAllConjectures gyroscopeOnSphericalJoint0: model ID27 / 35 (random ID0 / 2); time to go=1.12hours


 - Evaluation for gyroscopeOnSphericalJoint0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for gyroscopeOnSphericalJoint0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for gyroscopeOnSphericalJoint0c2 (using wrong models): method=Check if spherical motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for gyroscopeOnSphericalJoint0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for gyroscopeOnSphericalJoint0c4 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for gyroscopeOnSphericalJoint0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for gyroscopeOnSphericalJoint0c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for gyroscopeOnSphericalJoint0 (using wrong models):
  scoreConjectureCorrectModels=0.88333,  scoreConjectureWrongModels=0.55
  multScoreConjectureCorrectModels=0.88211,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures gyroscopeOnSphericalJoint1: model ID27 / 35 (random ID1 / 2); time to go=1.05hours


 - Evaluation for gyroscopeOnSphericalJoint1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for gyroscopeOnSphericalJoint1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for gyroscopeOnSphericalJoint1c2 (using wrong models): method=Check if spherical motion, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for gyroscopeOnSphericalJoint1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for gyroscopeOnSphericalJoint1c4 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for gyroscopeOnSphericalJoint1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for gyroscopeOnSphericalJoint1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=False, scoreValue=0.85


Evaluation summary for gyroscopeOnSphericalJoint1 (using wrong models):
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.7
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=0.6703


***

EvaluateAllConjectures prismaticJointSystem0: model ID28 / 35 (random ID0 / 2); time to go=3513.7s


 - Evaluation for prismaticJointSystem0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for prismaticJointSystem0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem0c2 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for prismaticJointSystem0 (using wrong models):
  scoreConjectureCorrectModels=0.14167,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures prismaticJointSystem1: model ID28 / 35 (random ID1 / 2); time to go=3263.48s


 - Evaluation for prismaticJointSystem1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for prismaticJointSystem1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem1c2 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.05

 - Evaluation for prismaticJointSystem1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for prismaticJointSystem1 (using wrong models):
  scoreConjectureCorrectModels=0.12857,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithSprings0: model ID29 / 35 (random ID0 / 2); time to go=3025.61s


 - Evaluation for twoMassPointsWithSprings0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithSprings0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for twoMassPointsWithSprings0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for twoMassPointsWithSprings0c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for twoMassPointsWithSprings0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for twoMassPointsWithSprings0 (using wrong models):
  scoreConjectureCorrectModels=0.87,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.86912,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithSprings1: model ID29 / 35 (random ID1 / 2); time to go=2745.28s


 - Evaluation for twoMassPointsWithSprings1c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for twoMassPointsWithSprings1c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for twoMassPointsWithSprings1c4 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for twoMassPointsWithSprings1c6 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for twoMassPointsWithSprings1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for twoMassPointsWithSprings1 (using wrong models):
  scoreConjectureCorrectModels=0.78,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.76441,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithDistances0: model ID30 / 35 (random ID0 / 2); time to go=2487.12s


 - Evaluation for twoMassPointsWithDistances0c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.25

 - Evaluation for twoMassPointsWithDistances0c2 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for twoMassPointsWithDistances0c3 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for twoMassPointsWithDistances0c5 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.25

 - Evaluation for twoMassPointsWithDistances0c6 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for twoMassPointsWithDistances0c7 (using wrong models): method=Perform a rough calculation, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for twoMassPointsWithDistances0 (using wrong models):
  scoreConjectureCorrectModels=0.55,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.4825,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithDistances1: model ID30 / 35 (random ID1 / 2); time to go=2249.83s


 - Evaluation for twoMassPointsWithDistances1c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for twoMassPointsWithDistances1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for twoMassPointsWithDistances1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for twoMassPointsWithDistances1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.25


Evaluation summary for twoMassPointsWithDistances1 (using wrong models):
  scoreConjectureCorrectModels=0.4375,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.42045,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorSimplySupported0: model ID31 / 35 (random ID0 / 2); time to go=1990.15s


 - Evaluation for rigidRotorSimplySupported0c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorSimplySupported0c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorSimplySupported0c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for rigidRotorSimplySupported0 (using wrong models):
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorSimplySupported1: model ID31 / 35 (random ID1 / 2); time to go=1721.05s


 - Evaluation for rigidRotorSimplySupported1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorSimplySupported1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorSimplySupported1c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorSimplySupported1c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorSimplySupported1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for rigidRotorSimplySupported1 (using wrong models):
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.85,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorUnbalanced0: model ID32 / 35 (random ID0 / 2); time to go=1472.57s


 - Evaluation for rigidRotorUnbalanced0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced0c2 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced0c3 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced0c4 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for rigidRotorUnbalanced0c5 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced0c6 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced0c7 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for rigidRotorUnbalanced0 (using wrong models):
  scoreConjectureCorrectModels=0.80625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.79545,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorUnbalanced1: model ID32 / 35 (random ID1 / 2); time to go=1240.76s


 - Evaluation for rigidRotorUnbalanced1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced1c2 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced1c3 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced1c4 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for rigidRotorUnbalanced1c5 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced1c6 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced1c7 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for rigidRotorUnbalanced1 (using wrong models):
  scoreConjectureCorrectModels=0.80625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.79545,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumRigidBodies0: model ID33 / 35 (random ID0 / 2); time to go=999.32s


 - Evaluation for doublePendulumRigidBodies0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumRigidBodies0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumRigidBodies0c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for doublePendulumRigidBodies0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumRigidBodies0c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for doublePendulumRigidBodies0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for doublePendulumRigidBodies0 (using wrong models):
  scoreConjectureCorrectModels=0.675,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.65192,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumRigidBodies1: model ID33 / 35 (random ID1 / 2); time to go=750.86s


 - Evaluation for doublePendulumRigidBodies1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumRigidBodies1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumRigidBodies1c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for doublePendulumRigidBodies1c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for doublePendulumRigidBodies1c4 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumRigidBodies1c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for doublePendulumRigidBodies1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for doublePendulumRigidBodies1 (using wrong models):
  scoreConjectureCorrectModels=0.65,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.62767,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankRigidBodies0: model ID34 / 35 (random ID0 / 2); time to go=501.19s


 - Evaluation for sliderCrankRigidBodies0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for sliderCrankRigidBodies0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for sliderCrankRigidBodies0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for sliderCrankRigidBodies0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for sliderCrankRigidBodies0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for sliderCrankRigidBodies0c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for sliderCrankRigidBodies0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for sliderCrankRigidBodies0c7 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for sliderCrankRigidBodies0 (using wrong models):
  scoreConjectureCorrectModels=0.81875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.80659,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankRigidBodies1: model ID34 / 35 (random ID1 / 2); time to go=253.9s


 - Evaluation for sliderCrankRigidBodies1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for sliderCrankRigidBodies1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for sliderCrankRigidBodies1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for sliderCrankRigidBodies1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.05

 - Evaluation for sliderCrankRigidBodies1c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for sliderCrankRigidBodies1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for sliderCrankRigidBodies1c7 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for sliderCrankRigidBodies1 (using wrong models):
  scoreConjectureCorrectModels=0.75,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.57616,  multScoreConjectureWrongModels=-1


***

A total of:
  0 errors and
  0 warnings
were logged!

***

Summary of EvaluateAllConjectures (using wrong models)
 - useSimEvaluationOnly = True
 - sumScoreTotalConjectures = 355.89000000000095
 - nTotalConjectures = 480
 - sumScoreTotalConjectureCorrectModels = 311.0900000000001
 - sumScoreTotalConjectureWrongModels = 44.80000000000003
 - nTotalConjectureCorrectModels = 414
 - nTotalConjectureWrongModels = 66
 - sumMultScoreTotalConjectureCorrectModels = 47.248380726102035
 - sumMultScoreTotalConjectureWrongModels = 11.52524723546518
 - nTotalMultConjectureCorrectModels = 65
 - nTotalMultConjectureWrongModels = 18
 - numberOfRemovedTokensGlobal = 455
 - numberOfTokensGlobal = 486330
 - totalScoreConjectureCorrectModels = 0.7514251207729471
 - totalScoreConjectureWrongModels = 0.6787878787878793
 - totalMultScoreConjectureCorrectModels = 0.7268981650169544
 - totalMultScoreConjectureWrongModels = 0.6402915130813989
 - runTime = 17824.004549741745
 - loggerErrors = 0
 - loggerWarnings = 0


