
***

Evaluate conjectures: nModels=70, nConjPerModel=8, LLM model=meta-llama/Llama-3.1-70B-Instruct

***

EvaluateAllConjectures flyingMassPoint0: model ID0 / 35 (random ID0 / 2)


 - Evaluation for flyingMassPoint0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.99

 - Evaluation for flyingMassPoint0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint0c3: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint0c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint0c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint0c7: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for flyingMassPoint0:
  scoreConjectureCorrectModels=0.87375,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingMassPoint1: model ID0 / 35 (random ID1 / 2); time to go=7.51hours


 - Evaluation for flyingMassPoint1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for flyingMassPoint1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.99

 - Evaluation for flyingMassPoint1c3: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint1c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint1c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for flyingMassPoint1:
  scoreConjectureCorrectModels=0.87125,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures freeFallMassPoint0: model ID1 / 35 (random ID0 / 2); time to go=6.88hours


 - Evaluation for freeFallMassPoint0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for freeFallMassPoint0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for freeFallMassPoint0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for freeFallMassPoint0c3: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for freeFallMassPoint0c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for freeFallMassPoint0c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for freeFallMassPoint0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for freeFallMassPoint0:
  scoreConjectureCorrectModels=1.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=1.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures freeFallMassPoint1: model ID1 / 35 (random ID1 / 2); time to go=6.39hours


 - Evaluation for freeFallMassPoint1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for freeFallMassPoint1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.99

 - Evaluation for freeFallMassPoint1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for freeFallMassPoint1c3: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for freeFallMassPoint1c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for freeFallMassPoint1c5: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for freeFallMassPoint1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for freeFallMassPoint1:
  scoreConjectureCorrectModels=0.995,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.99497,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures singleMassOscillator0: model ID2 / 35 (random ID0 / 2); time to go=6.2hours


 - Evaluation for singleMassOscillator0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.99

 - Evaluation for singleMassOscillator0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillator0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillator0c3: method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillator0c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillator0c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillator0c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillator0c7: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for singleMassOscillator0:
  scoreConjectureCorrectModels=0.98,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.97938,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillator1: model ID2 / 35 (random ID1 / 2); time to go=5.91hours


 - Evaluation for singleMassOscillator1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillator1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillator1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillator1c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillator1c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillator1c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.4

 - Evaluation for singleMassOscillator1c7: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for singleMassOscillator1:
  scoreConjectureCorrectModels=0.87857,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.84541,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorGravity0: model ID3 / 35 (random ID0 / 2); time to go=5.63hours


 - Evaluation for singleMassOscillatorGravity0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity0c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillatorGravity0c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillatorGravity0c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity0c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for singleMassOscillatorGravity0:
  scoreConjectureCorrectModels=0.28571,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorGravity1: model ID3 / 35 (random ID1 / 2); time to go=5.21hours


 - Evaluation for singleMassOscillatorGravity1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity1c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillatorGravity1c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillatorGravity1c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity1c7: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for singleMassOscillatorGravity1:
  scoreConjectureCorrectModels=0.41429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankSimple0: model ID4 / 35 (random ID0 / 2); time to go=5.0hours



Evaluation summary for sliderCrankSimple0:
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankSimple1: model ID4 / 35 (random ID1 / 2); time to go=4.37hours


 - Evaluation for sliderCrankSimple1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for sliderCrankSimple1:
  scoreConjectureCorrectModels=1.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=1.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumElasticSpring0: model ID5 / 35 (random ID0 / 2); time to go=3.91hours


 - Evaluation for singlePendulumElasticSpring0c0: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for singlePendulumElasticSpring0c1: method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulumElasticSpring0c2: method=Check if planar motion, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for singlePendulumElasticSpring0c3: method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for singlePendulumElasticSpring0c4: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulumElasticSpring0c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for singlePendulumElasticSpring0c6: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for singlePendulumElasticSpring0c7: method=Evaluate symmetry, modelIsCorrect=False, scoreValue=0.95


Evaluation summary for singlePendulumElasticSpring0:
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.66875
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures singlePendulumElasticSpring1: model ID5 / 35 (random ID1 / 2); time to go=4.04hours


 - Evaluation for singlePendulumElasticSpring1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulumElasticSpring1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulumElasticSpring1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumElasticSpring1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singlePendulumElasticSpring1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulumElasticSpring1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulumElasticSpring1c6: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulumElasticSpring1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for singlePendulumElasticSpring1:
  scoreConjectureCorrectModels=0.83571,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.8338,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures singleMassOscillatorUserFunction0: model ID6 / 35 (random ID0 / 2); time to go=4.14hours


 - Evaluation for singleMassOscillatorUserFunction0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillatorUserFunction0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorUserFunction0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for singleMassOscillatorUserFunction0c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillatorUserFunction0c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillatorUserFunction0c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillatorUserFunction0c7: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for singleMassOscillatorUserFunction0:
  scoreConjectureCorrectModels=0.77143,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorUserFunction1: model ID6 / 35 (random ID1 / 2); time to go=4.1hours


 - Evaluation for singleMassOscillatorUserFunction1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singleMassOscillatorUserFunction1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorUserFunction1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillatorUserFunction1c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillatorUserFunction1c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for singleMassOscillatorUserFunction1c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singleMassOscillatorUserFunction1c7: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for singleMassOscillatorUserFunction1:
  scoreConjectureCorrectModels=0.78286,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures spinningDisc0: model ID7 / 35 (random ID0 / 2); time to go=4.09hours


 - Evaluation for spinningDisc0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc0c1: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.99

 - Evaluation for spinningDisc0c2: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc0c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc0c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc0c6: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc0c7: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for spinningDisc0:
  scoreConjectureCorrectModels=0.42714,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures spinningDisc1: model ID7 / 35 (random ID1 / 2); time to go=3.96hours


 - Evaluation for spinningDisc1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc1c1: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc1c2: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc1c3: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc1c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc1c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc1c6: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc1c7: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for spinningDisc1:
  scoreConjectureCorrectModels=0.625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doubleMassOscillator0: model ID8 / 35 (random ID0 / 2); time to go=3.89hours


 - Evaluation for doubleMassOscillator0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doubleMassOscillator0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doubleMassOscillator0c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doubleMassOscillator0c4: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doubleMassOscillator0c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doubleMassOscillator0c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doubleMassOscillator0c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for doubleMassOscillator0:
  scoreConjectureCorrectModels=0.94286,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.93823,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doubleMassOscillator1: model ID8 / 35 (random ID1 / 2); time to go=3.88hours


 - Evaluation for doubleMassOscillator1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doubleMassOscillator1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doubleMassOscillator1c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doubleMassOscillator1c4: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doubleMassOscillator1c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doubleMassOscillator1c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doubleMassOscillator1c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for doubleMassOscillator1:
  scoreConjectureCorrectModels=0.71429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nMassOscillator0: model ID9 / 35 (random ID0 / 2); time to go=3.91hours


 - Evaluation for nMassOscillator0c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for nMassOscillator0c2: method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for nMassOscillator0c3: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for nMassOscillator0c4: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for nMassOscillator0c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for nMassOscillator0c6: method=Evaluate motion space, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for nMassOscillator0c7: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=1.0


Evaluation summary for nMassOscillator0:
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.4
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures nMassOscillator1: model ID9 / 35 (random ID1 / 2); time to go=3.77hours


 - Evaluation for nMassOscillator1c0: method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nMassOscillator1c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for nMassOscillator1c2: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for nMassOscillator1c3: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for nMassOscillator1c4: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for nMassOscillator1c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for nMassOscillator1c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for nMassOscillator1c7: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for nMassOscillator1:
  scoreConjectureCorrectModels=0.63333,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures singlePendulum0: model ID10 / 35 (random ID0 / 2); time to go=3.73hours


 - Evaluation for singlePendulum0c0: method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for singlePendulum0c1: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for singlePendulum0c2: method=Evaluate initial position, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for singlePendulum0c3: method=Check if planar motion, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for singlePendulum0c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singlePendulum0c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for singlePendulum0c6: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulum0c7: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.8


Evaluation summary for singlePendulum0:
  scoreConjectureCorrectModels=0.8,  scoreConjectureWrongModels=0.73333
  multScoreConjectureCorrectModels=0.7746,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures singlePendulum1: model ID10 / 35 (random ID1 / 2); time to go=3.74hours


 - Evaluation for singlePendulum1c1: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulum1c2: method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for singlePendulum1c3: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulum1c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for singlePendulum1c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singlePendulum1c6: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulum1c7: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.9


Evaluation summary for singlePendulum1:
  scoreConjectureCorrectModels=0.94333,  scoreConjectureWrongModels=0.45
  multScoreConjectureCorrectModels=0.94275,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures doublePendulum0: model ID11 / 35 (random ID0 / 2); time to go=3.72hours


 - Evaluation for doublePendulum0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulum0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulum0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulum0c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum0c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for doublePendulum0:
  scoreConjectureCorrectModels=0.34286,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulum1: model ID11 / 35 (random ID1 / 2); time to go=3.65hours


 - Evaluation for doublePendulum1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum1c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum1c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulum1c6: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum1c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for doublePendulum1:
  scoreConjectureCorrectModels=0.13333,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nPendulum0: model ID12 / 35 (random ID0 / 2); time to go=3.57hours


 - Evaluation for nPendulum0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum0c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for nPendulum0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for nPendulum0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for nPendulum0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.2


Evaluation summary for nPendulum0:
  scoreConjectureCorrectModels=0.51667,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nPendulum1: model ID12 / 35 (random ID1 / 2); time to go=3.5hours


 - Evaluation for nPendulum1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for nPendulum1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for nPendulum1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for nPendulum1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum1c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for nPendulum1:
  scoreConjectureCorrectModels=0.4,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures fourBarMechanismPointMasses0: model ID13 / 35 (random ID0 / 2); time to go=3.38hours


 - Evaluation for fourBarMechanismPointMasses0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for fourBarMechanismPointMasses0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for fourBarMechanismPointMasses0c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for fourBarMechanismPointMasses0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for fourBarMechanismPointMasses0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for fourBarMechanismPointMasses0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for fourBarMechanismPointMasses0c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for fourBarMechanismPointMasses0:
  scoreConjectureCorrectModels=0.6,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures fourBarMechanismPointMasses1: model ID13 / 35 (random ID1 / 2); time to go=3.3hours


 - Evaluation for fourBarMechanismPointMasses1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for fourBarMechanismPointMasses1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for fourBarMechanismPointMasses1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for fourBarMechanismPointMasses1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for fourBarMechanismPointMasses1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for fourBarMechanismPointMasses1c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for fourBarMechanismPointMasses1:
  scoreConjectureCorrectModels=0.90833,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.90439,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures springCoupledFlyingRigidBodies0: model ID14 / 35 (random ID0 / 2); time to go=3.19hours


 - Evaluation for springCoupledFlyingRigidBodies0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for springCoupledFlyingRigidBodies0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for springCoupledFlyingRigidBodies0c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for springCoupledFlyingRigidBodies0c3: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for springCoupledFlyingRigidBodies0c6: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for springCoupledFlyingRigidBodies0c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for springCoupledFlyingRigidBodies0:
  scoreConjectureCorrectModels=0.65,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures springCoupledFlyingRigidBodies1: model ID14 / 35 (random ID1 / 2); time to go=3.1hours


 - Evaluation for springCoupledFlyingRigidBodies1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for springCoupledFlyingRigidBodies1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for springCoupledFlyingRigidBodies1c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for springCoupledFlyingRigidBodies1c3: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for springCoupledFlyingRigidBodies1c4: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for springCoupledFlyingRigidBodies1c6: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for springCoupledFlyingRigidBodies1c7: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for springCoupledFlyingRigidBodies1:
  scoreConjectureCorrectModels=0.55714,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures torsionalOscillator0: model ID15 / 35 (random ID0 / 2); time to go=3.0hours


 - Evaluation for torsionalOscillator0c0: method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for torsionalOscillator0c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.98

 - Evaluation for torsionalOscillator0c2: method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for torsionalOscillator0c3: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for torsionalOscillator0c4: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator0c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator0c6: method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator0c7: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.95


Evaluation summary for torsionalOscillator0:
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.55375
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures torsionalOscillator1: model ID15 / 35 (random ID1 / 2); time to go=2.94hours


 - Evaluation for torsionalOscillator1c0: method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for torsionalOscillator1c1: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator1c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for torsionalOscillator1c3: method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.98

 - Evaluation for torsionalOscillator1c4: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for torsionalOscillator1c5: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator1c6: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0


Evaluation summary for torsionalOscillator1:
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.54
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures invertedSinglePendulum0: model ID16 / 35 (random ID0 / 2); time to go=2.87hours


 - Evaluation for invertedSinglePendulum0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for invertedSinglePendulum0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for invertedSinglePendulum0c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for invertedSinglePendulum0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for invertedSinglePendulum0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for invertedSinglePendulum0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for invertedSinglePendulum0c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for invertedSinglePendulum0c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for invertedSinglePendulum0:
  scoreConjectureCorrectModels=0.4375,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures invertedSinglePendulum1: model ID16 / 35 (random ID1 / 2); time to go=2.79hours


 - Evaluation for invertedSinglePendulum1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for invertedSinglePendulum1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for invertedSinglePendulum1c3: method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for invertedSinglePendulum1c4: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.99

 - Evaluation for invertedSinglePendulum1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for invertedSinglePendulum1c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for invertedSinglePendulum1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for invertedSinglePendulum1:
  scoreConjectureCorrectModels=0.5,  scoreConjectureWrongModels=0.895
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.88994


***

EvaluateAllConjectures discRollingOnGround0: model ID17 / 35 (random ID0 / 2); time to go=2.71hours


 - Evaluation for discRollingOnGround0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround0c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for discRollingOnGround0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround0c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround0c7: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.2


Evaluation summary for discRollingOnGround0:
  scoreConjectureCorrectModels=0.89375,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.81254,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures discRollingOnGround1: model ID17 / 35 (random ID1 / 2); time to go=2.63hours


 - Evaluation for discRollingOnGround1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for discRollingOnGround1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for discRollingOnGround1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround1c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for discRollingOnGround1:
  scoreConjectureCorrectModels=0.60625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumElasticSpring0: model ID18 / 35 (random ID0 / 2); time to go=2.55hours


 - Evaluation for doublePendulumElasticSpring0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumElasticSpring0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for doublePendulumElasticSpring0c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for doublePendulumElasticSpring0c4: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumElasticSpring0c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doublePendulumElasticSpring0c7: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for doublePendulumElasticSpring0:
  scoreConjectureCorrectModels=0.78,  scoreConjectureWrongModels=0.9
  multScoreConjectureCorrectModels=0.77327,  multScoreConjectureWrongModels=0.9


***

EvaluateAllConjectures doublePendulumElasticSpring1: model ID18 / 35 (random ID1 / 2); time to go=2.46hours


 - Evaluation for doublePendulumElasticSpring1c0: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for doublePendulumElasticSpring1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumElasticSpring1c2: method=Evaluate static equilibrium for damped systems, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for doublePendulumElasticSpring1c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for doublePendulumElasticSpring1c4: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumElasticSpring1c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doublePendulumElasticSpring1c7: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for doublePendulumElasticSpring1:
  scoreConjectureCorrectModels=0.6375,  scoreConjectureWrongModels=0.26667
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures nPendulumElasticSpring0: model ID19 / 35 (random ID0 / 2); time to go=2.37hours


 - Evaluation for nPendulumElasticSpring0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for nPendulumElasticSpring0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulumElasticSpring0c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulumElasticSpring0c3: method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for nPendulumElasticSpring0c4: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulumElasticSpring0c5: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for nPendulumElasticSpring0c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulumElasticSpring0c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for nPendulumElasticSpring0:
  scoreConjectureCorrectModels=0.36429,  scoreConjectureWrongModels=1.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=1.0


***

EvaluateAllConjectures nPendulumElasticSpring1: model ID19 / 35 (random ID1 / 2); time to go=2.29hours


 - Evaluation for nPendulumElasticSpring1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for nPendulumElasticSpring1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for nPendulumElasticSpring1c2: method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulumElasticSpring1c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulumElasticSpring1c4: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for nPendulumElasticSpring1c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulumElasticSpring1c6: method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for nPendulumElasticSpring1c7: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=1.0


Evaluation summary for nPendulumElasticSpring1:
  scoreConjectureCorrectModels=0.55,  scoreConjectureWrongModels=0.91667
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.91258


***

EvaluateAllConjectures elasticChain0: model ID20 / 35 (random ID0 / 2); time to go=2.21hours


 - Evaluation for elasticChain0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for elasticChain0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for elasticChain0c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for elasticChain0c4: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for elasticChain0c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for elasticChain0c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for elasticChain0c7: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for elasticChain0:
  scoreConjectureCorrectModels=0.37143,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures elasticChain1: model ID20 / 35 (random ID1 / 2); time to go=2.12hours


 - Evaluation for elasticChain1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for elasticChain1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for elasticChain1c2: method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for elasticChain1c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for elasticChain1c4: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for elasticChain1c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for elasticChain1c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for elasticChain1c7: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for elasticChain1:
  scoreConjectureCorrectModels=0.7,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumRigidBody0: model ID21 / 35 (random ID0 / 2); time to go=2.04hours


 - Evaluation for singlePendulumRigidBody0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumRigidBody0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumRigidBody0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulumRigidBody0c3: method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulumRigidBody0c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody0c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singlePendulumRigidBody0c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singlePendulumRigidBody0c7: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for singlePendulumRigidBody0:
  scoreConjectureCorrectModels=0.775,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumRigidBody1: model ID21 / 35 (random ID1 / 2); time to go=1.98hours


 - Evaluation for singlePendulumRigidBody1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for singlePendulumRigidBody1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singlePendulumRigidBody1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody1c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody1c4: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singlePendulumRigidBody1c5: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody1c6: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for singlePendulumRigidBody1c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for singlePendulumRigidBody1:
  scoreConjectureCorrectModels=0.35,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringRigid0: model ID22 / 35 (random ID0 / 2); time to go=1.93hours


 - Evaluation for massPointOnStringRigid0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringRigid0c1: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringRigid0c2: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringRigid0c3: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for massPointOnStringRigid0c4: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringRigid0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for massPointOnStringRigid0c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for massPointOnStringRigid0:
  scoreConjectureCorrectModels=0.78571,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringRigid1: model ID22 / 35 (random ID1 / 2); time to go=1.86hours


 - Evaluation for massPointOnStringRigid1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringRigid1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringRigid1c2: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringRigid1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for massPointOnStringRigid1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for massPointOnStringRigid1c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringRigid1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringRigid1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for massPointOnStringRigid1:
  scoreConjectureCorrectModels=0.83875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringElastic0: model ID23 / 35 (random ID0 / 2); time to go=1.81hours


 - Evaluation for massPointOnStringElastic0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic0c2: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic0c3: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic0c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic0c5: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for massPointOnStringElastic0c6: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.97

 - Evaluation for massPointOnStringElastic0c7: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0


Evaluation summary for massPointOnStringElastic0:
  scoreConjectureCorrectModels=0.82833,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.82611,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures massPointOnStringElastic1: model ID23 / 35 (random ID1 / 2); time to go=1.74hours


 - Evaluation for massPointOnStringElastic1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic1c2: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic1c3: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringElastic1c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringElastic1c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for massPointOnStringElastic1c6: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for massPointOnStringElastic1c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for massPointOnStringElastic1:
  scoreConjectureCorrectModels=0.7725,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures linkOnTwoPrismaticJoints0: model ID24 / 35 (random ID0 / 2); time to go=1.67hours


 - Evaluation for linkOnTwoPrismaticJoints0c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for linkOnTwoPrismaticJoints0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for linkOnTwoPrismaticJoints0c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for linkOnTwoPrismaticJoints0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for linkOnTwoPrismaticJoints0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for linkOnTwoPrismaticJoints0c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for linkOnTwoPrismaticJoints0:
  scoreConjectureCorrectModels=0.45833,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures linkOnTwoPrismaticJoints1: model ID24 / 35 (random ID1 / 2); time to go=1.58hours


 - Evaluation for linkOnTwoPrismaticJoints1c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for linkOnTwoPrismaticJoints1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for linkOnTwoPrismaticJoints1c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for linkOnTwoPrismaticJoints1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for linkOnTwoPrismaticJoints1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for linkOnTwoPrismaticJoints1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for linkOnTwoPrismaticJoints1c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for linkOnTwoPrismaticJoints1:
  scoreConjectureCorrectModels=0.85714,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingRigidBody0: model ID25 / 35 (random ID0 / 2); time to go=1.5hours


 - Evaluation for flyingRigidBody0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingRigidBody0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingRigidBody0c2: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingRigidBody0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for flyingRigidBody0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for flyingRigidBody0c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for flyingRigidBody0c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.99


Evaluation summary for flyingRigidBody0:
  scoreConjectureCorrectModels=0.83375,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingRigidBody1: model ID25 / 35 (random ID1 / 2); time to go=1.44hours


 - Evaluation for flyingRigidBody1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for flyingRigidBody1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for flyingRigidBody1c2: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingRigidBody1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingRigidBody1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingRigidBody1c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.99

 - Evaluation for flyingRigidBody1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for flyingRigidBody1:
  scoreConjectureCorrectModels=0.72375,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures suspendedRigidBody0: model ID26 / 35 (random ID0 / 2); time to go=1.38hours


 - Evaluation for suspendedRigidBody0c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for suspendedRigidBody0c2: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for suspendedRigidBody0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for suspendedRigidBody0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for suspendedRigidBody0c5: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for suspendedRigidBody0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for suspendedRigidBody0c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for suspendedRigidBody0:
  scoreConjectureCorrectModels=0.81429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures suspendedRigidBody1: model ID26 / 35 (random ID1 / 2); time to go=1.3hours


 - Evaluation for suspendedRigidBody1c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for suspendedRigidBody1c2: method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for suspendedRigidBody1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for suspendedRigidBody1c4: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for suspendedRigidBody1c5: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for suspendedRigidBody1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for suspendedRigidBody1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for suspendedRigidBody1:
  scoreConjectureCorrectModels=0.83,  scoreConjectureWrongModels=1.0
  multScoreConjectureCorrectModels=0.80687,  multScoreConjectureWrongModels=1.0


***

EvaluateAllConjectures gyroscopeOnSphericalJoint0: model ID27 / 35 (random ID0 / 2); time to go=1.23hours


 - Evaluation for gyroscopeOnSphericalJoint0c0: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for gyroscopeOnSphericalJoint0c1: method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for gyroscopeOnSphericalJoint0c2: method=Check if spherical motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for gyroscopeOnSphericalJoint0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for gyroscopeOnSphericalJoint0c4: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for gyroscopeOnSphericalJoint0c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for gyroscopeOnSphericalJoint0c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for gyroscopeOnSphericalJoint0:
  scoreConjectureCorrectModels=0.65,  scoreConjectureWrongModels=0.375
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures gyroscopeOnSphericalJoint1: model ID27 / 35 (random ID1 / 2); time to go=1.16hours


 - Evaluation for gyroscopeOnSphericalJoint1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for gyroscopeOnSphericalJoint1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for gyroscopeOnSphericalJoint1c2: method=Check if spherical motion, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for gyroscopeOnSphericalJoint1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for gyroscopeOnSphericalJoint1c4: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.2

 - Evaluation for gyroscopeOnSphericalJoint1c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for gyroscopeOnSphericalJoint1c6: method=Evaluate symmetry, modelIsCorrect=False, scoreValue=0.8


Evaluation summary for gyroscopeOnSphericalJoint1:
  scoreConjectureCorrectModels=0.61667,  scoreConjectureWrongModels=0.5
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures prismaticJointSystem0: model ID28 / 35 (random ID0 / 2); time to go=1.08hours


 - Evaluation for prismaticJointSystem0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem0c2: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for prismaticJointSystem0:
  scoreConjectureCorrectModels=0.83333,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures prismaticJointSystem1: model ID28 / 35 (random ID1 / 2); time to go=3593.97s


 - Evaluation for prismaticJointSystem1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem1c2: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem1c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for prismaticJointSystem1:
  scoreConjectureCorrectModels=1.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=1.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithSprings0: model ID29 / 35 (random ID0 / 2); time to go=3329.32s


 - Evaluation for twoMassPointsWithSprings0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for twoMassPointsWithSprings0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for twoMassPointsWithSprings0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for twoMassPointsWithSprings0c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithSprings0c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for twoMassPointsWithSprings0:
  scoreConjectureCorrectModels=0.99,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.98979,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithSprings1: model ID29 / 35 (random ID1 / 2); time to go=3040.2s


 - Evaluation for twoMassPointsWithSprings1c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for twoMassPointsWithSprings1c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for twoMassPointsWithSprings1c4: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for twoMassPointsWithSprings1c6: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithSprings1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for twoMassPointsWithSprings1:
  scoreConjectureCorrectModels=0.99,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.98979,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithDistances0: model ID30 / 35 (random ID0 / 2); time to go=2748.47s


 - Evaluation for twoMassPointsWithDistances0c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for twoMassPointsWithDistances0c2: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for twoMassPointsWithDistances0c3: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for twoMassPointsWithDistances0c5: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for twoMassPointsWithDistances0c6: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for twoMassPointsWithDistances0c7: method=Perform a rough calculation, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for twoMassPointsWithDistances0:
  scoreConjectureCorrectModels=0.77167,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithDistances1: model ID30 / 35 (random ID1 / 2); time to go=2474.47s


 - Evaluation for twoMassPointsWithDistances1c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for twoMassPointsWithDistances1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for twoMassPointsWithDistances1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithDistances1c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for twoMassPointsWithDistances1:
  scoreConjectureCorrectModels=0.6375,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorSimplySupported0: model ID31 / 35 (random ID0 / 2); time to go=2187.27s


 - Evaluation for rigidRotorSimplySupported0c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for rigidRotorSimplySupported0c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for rigidRotorSimplySupported0c3: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for rigidRotorSimplySupported0:
  scoreConjectureCorrectModels=1.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=1.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorSimplySupported1: model ID31 / 35 (random ID1 / 2); time to go=1893.09s


 - Evaluation for rigidRotorSimplySupported1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for rigidRotorSimplySupported1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for rigidRotorSimplySupported1c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for rigidRotorSimplySupported1c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for rigidRotorSimplySupported1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for rigidRotorSimplySupported1:
  scoreConjectureCorrectModels=1.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=1.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorUnbalanced0: model ID32 / 35 (random ID0 / 2); time to go=1612.21s


 - Evaluation for rigidRotorUnbalanced0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for rigidRotorUnbalanced0c2: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced0c3: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for rigidRotorUnbalanced0c4: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for rigidRotorUnbalanced0c5: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for rigidRotorUnbalanced0c6: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced0c7: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for rigidRotorUnbalanced0:
  scoreConjectureCorrectModels=0.425,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorUnbalanced1: model ID32 / 35 (random ID1 / 2); time to go=1338.88s


 - Evaluation for rigidRotorUnbalanced1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced1c2: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced1c3: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for rigidRotorUnbalanced1c4: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for rigidRotorUnbalanced1c5: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced1c6: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced1c7: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for rigidRotorUnbalanced1:
  scoreConjectureCorrectModels=0.625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumRigidBodies0: model ID33 / 35 (random ID0 / 2); time to go=1068.08s


 - Evaluation for doublePendulumRigidBodies0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumRigidBodies0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumRigidBodies0c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumRigidBodies0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doublePendulumRigidBodies0c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumRigidBodies0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for doublePendulumRigidBodies0:
  scoreConjectureCorrectModels=0.38333,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumRigidBodies1: model ID33 / 35 (random ID1 / 2); time to go=799.67s


 - Evaluation for doublePendulumRigidBodies1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doublePendulumRigidBodies1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumRigidBodies1c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumRigidBodies1c3: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumRigidBodies1c4: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doublePendulumRigidBodies1c6: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumRigidBodies1c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for doublePendulumRigidBodies1:
  scoreConjectureCorrectModels=0.28571,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankRigidBodies0: model ID34 / 35 (random ID0 / 2); time to go=532.16s


 - Evaluation for sliderCrankRigidBodies0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies0c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for sliderCrankRigidBodies0c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for sliderCrankRigidBodies0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies0c7: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for sliderCrankRigidBodies0:
  scoreConjectureCorrectModels=0.75,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankRigidBodies1: model ID34 / 35 (random ID1 / 2); time to go=265.22s


 - Evaluation for sliderCrankRigidBodies1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for sliderCrankRigidBodies1c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for sliderCrankRigidBodies1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for sliderCrankRigidBodies1c7: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for sliderCrankRigidBodies1:
  scoreConjectureCorrectModels=0.57143,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

A total of:
  0 errors and
  0 warnings
were logged!

***

Summary of EvaluateAllConjectures
 - useSimEvaluationOnly = True
 - sumScoreTotalConjectures = 318.17000000000024
 - nTotalConjectures = 480
 - sumScoreTotalConjectureCorrectModels = 282.8700000000002
 - sumScoreTotalConjectureWrongModels = 35.3
 - nTotalConjectureCorrectModels = 414
 - nTotalConjectureWrongModels = 66
 - sumMultScoreTotalConjectureCorrectModels = 17.411911604468052
 - sumMultScoreTotalConjectureWrongModels = 4.702524345528873
 - nTotalMultConjectureCorrectModels = 65
 - nTotalMultConjectureWrongModels = 18
 - numberOfRemovedTokensGlobal = 0
 - numberOfTokensGlobal = 186229
 - totalScoreConjectureCorrectModels = 0.6832608695652178
 - totalScoreConjectureWrongModels = 0.5348484848484848
 - totalMultScoreConjectureCorrectModels = 0.26787556314566235
 - totalMultScoreConjectureWrongModels = 0.26125135252938186
 - runTime = 18474.651330947876
 - loggerErrors = 0
 - loggerWarnings = 0



***

Evaluate conjectures (using wrong models): nModels=70, nConjPerModel=8, LLM model=meta-llama/Llama-3.1-70B-Instruct

***

EvaluateAllConjectures flyingMassPoint0: model ID0 / 35 (random ID0 / 2)


 - Evaluation for flyingMassPoint0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for flyingMassPoint0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for flyingMassPoint0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for flyingMassPoint0c3 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingMassPoint0c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint0c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for flyingMassPoint0c7 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for flyingMassPoint0 (using wrong models):
  scoreConjectureCorrectModels=0.53875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingMassPoint1: model ID0 / 35 (random ID1 / 2); time to go=8.18hours


 - Evaluation for flyingMassPoint1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint1c3 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint1c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for flyingMassPoint1 (using wrong models):
  scoreConjectureCorrectModels=0.225,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures freeFallMassPoint0: model ID1 / 35 (random ID0 / 2); time to go=7.62hours


 - Evaluation for freeFallMassPoint0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for freeFallMassPoint0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint0c3 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint0c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint0c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for freeFallMassPoint0 (using wrong models):
  scoreConjectureCorrectModels=0.25,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures freeFallMassPoint1: model ID1 / 35 (random ID1 / 2); time to go=6.83hours


 - Evaluation for freeFallMassPoint1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint1c3 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint1c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for freeFallMassPoint1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for freeFallMassPoint1 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures singleMassOscillator0: model ID2 / 35 (random ID0 / 2); time to go=6.14hours


 - Evaluation for singleMassOscillator0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for singleMassOscillator0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillator0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillator0c3 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillator0c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillator0c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.4

 - Evaluation for singleMassOscillator0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for singleMassOscillator0c7 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for singleMassOscillator0 (using wrong models):
  scoreConjectureCorrectModels=0.4375,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillator1: model ID2 / 35 (random ID1 / 2); time to go=6.09hours


 - Evaluation for singleMassOscillator1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillator1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for singleMassOscillator1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for singleMassOscillator1c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillator1c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillator1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for singleMassOscillator1c7 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for singleMassOscillator1 (using wrong models):
  scoreConjectureCorrectModels=0.50429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorGravity0: model ID3 / 35 (random ID0 / 2); time to go=6.04hours


 - Evaluation for singleMassOscillatorGravity0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity0c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillatorGravity0c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.91

 - Evaluation for singleMassOscillatorGravity0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for singleMassOscillatorGravity0 (using wrong models):
  scoreConjectureCorrectModels=0.27286,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorGravity1: model ID3 / 35 (random ID1 / 2); time to go=5.53hours


 - Evaluation for singleMassOscillatorGravity1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity1c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for singleMassOscillatorGravity1c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillatorGravity1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singleMassOscillatorGravity1c7 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for singleMassOscillatorGravity1 (using wrong models):
  scoreConjectureCorrectModels=0.52571,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankSimple0: model ID4 / 35 (random ID0 / 2); time to go=5.27hours



Evaluation summary for sliderCrankSimple0 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankSimple1: model ID4 / 35 (random ID1 / 2); time to go=4.6hours


 - Evaluation for sliderCrankSimple1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for sliderCrankSimple1 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumElasticSpring0: model ID5 / 35 (random ID0 / 2); time to go=4.1hours


 - Evaluation for singlePendulumElasticSpring0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.8


***

*****
ERROR:** 

```
EvaluateConjecture: score is invalid: ERROR in ExtractXMLtaggedString: received 0 start tags and 0 end tags!
***
```

 - Evaluation for singlePendulumElasticSpring0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=False, scoreValue=-3

 - Evaluation for singlePendulumElasticSpring0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for singlePendulumElasticSpring0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for singlePendulumElasticSpring0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for singlePendulumElasticSpring0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for singlePendulumElasticSpring0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for singlePendulumElasticSpring0c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=False, scoreValue=0.8


Evaluation summary for singlePendulumElasticSpring0 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.73125
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.85296


***

EvaluateAllConjectures singlePendulumElasticSpring1: model ID5 / 35 (random ID1 / 2); time to go=4.47hours


 - Evaluation for singlePendulumElasticSpring1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulumElasticSpring1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumElasticSpring1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumElasticSpring1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.4

 - Evaluation for singlePendulumElasticSpring1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulumElasticSpring1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulumElasticSpring1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulumElasticSpring1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for singlePendulumElasticSpring1 (using wrong models):
  scoreConjectureCorrectModels=0.67143,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures singleMassOscillatorUserFunction0: model ID6 / 35 (random ID0 / 2); time to go=4.56hours


 - Evaluation for singleMassOscillatorUserFunction0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillatorUserFunction0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillatorUserFunction0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorUserFunction0c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillatorUserFunction0c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for singleMassOscillatorUserFunction0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillatorUserFunction0c7 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for singleMassOscillatorUserFunction0 (using wrong models):
  scoreConjectureCorrectModels=0.71429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorUserFunction1: model ID6 / 35 (random ID1 / 2); time to go=4.46hours


 - Evaluation for singleMassOscillatorUserFunction1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillatorUserFunction1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillatorUserFunction1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorUserFunction1c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillatorUserFunction1c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillatorUserFunction1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singleMassOscillatorUserFunction1c7 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for singleMassOscillatorUserFunction1 (using wrong models):
  scoreConjectureCorrectModels=0.79286,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures spinningDisc0: model ID7 / 35 (random ID0 / 2); time to go=4.35hours


 - Evaluation for spinningDisc0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for spinningDisc0c1 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for spinningDisc0c2 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc0c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc0c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for spinningDisc0c6 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc0c7 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for spinningDisc0 (using wrong models):
  scoreConjectureCorrectModels=0.44286,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures spinningDisc1: model ID7 / 35 (random ID1 / 2); time to go=4.26hours


 - Evaluation for spinningDisc1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc1c1 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc1c2 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc1c3 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc1c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc1c6 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc1c7 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for spinningDisc1 (using wrong models):
  scoreConjectureCorrectModels=0.125,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doubleMassOscillator0: model ID8 / 35 (random ID0 / 2); time to go=4.14hours


 - Evaluation for doubleMassOscillator0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doubleMassOscillator0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doubleMassOscillator0c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doubleMassOscillator0c4 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doubleMassOscillator0c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doubleMassOscillator0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for doubleMassOscillator0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.6


Evaluation summary for doubleMassOscillator0 (using wrong models):
  scoreConjectureCorrectModels=0.74286,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doubleMassOscillator1: model ID8 / 35 (random ID1 / 2); time to go=4.09hours


 - Evaluation for doubleMassOscillator1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doubleMassOscillator1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doubleMassOscillator1c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doubleMassOscillator1c4 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doubleMassOscillator1c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doubleMassOscillator1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doubleMassOscillator1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for doubleMassOscillator1 (using wrong models):
  scoreConjectureCorrectModels=0.96429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.96155,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nMassOscillator0: model ID9 / 35 (random ID0 / 2); time to go=4.09hours


 - Evaluation for nMassOscillator0c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for nMassOscillator0c2 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for nMassOscillator0c3 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for nMassOscillator0c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for nMassOscillator0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for nMassOscillator0c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for nMassOscillator0c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.0


Evaluation summary for nMassOscillator0 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.37143
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures nMassOscillator1: model ID9 / 35 (random ID1 / 2); time to go=3.98hours


 - Evaluation for nMassOscillator1c0 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nMassOscillator1c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for nMassOscillator1c2 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for nMassOscillator1c3 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for nMassOscillator1c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for nMassOscillator1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for nMassOscillator1c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nMassOscillator1c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for nMassOscillator1 (using wrong models):
  scoreConjectureCorrectModels=0.4,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures singlePendulum0: model ID10 / 35 (random ID0 / 2); time to go=3.9hours


 - Evaluation for singlePendulum0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for singlePendulum0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulum0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulum0c3 (using wrong models): method=Check if planar motion, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for singlePendulum0c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulum0c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singlePendulum0c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulum0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.8


Evaluation summary for singlePendulum0 (using wrong models):
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.43333
  multScoreConjectureCorrectModels=0.84853,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures singlePendulum1: model ID10 / 35 (random ID1 / 2); time to go=3.89hours


 - Evaluation for singlePendulum1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulum1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for singlePendulum1c3 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulum1c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singlePendulum1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singlePendulum1c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulum1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.8


Evaluation summary for singlePendulum1 (using wrong models):
  scoreConjectureCorrectModels=0.95,  scoreConjectureWrongModels=0.4375
  multScoreConjectureCorrectModels=0.94912,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures doublePendulum0: model ID11 / 35 (random ID0 / 2); time to go=3.84hours


 - Evaluation for doublePendulum0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for doublePendulum0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulum0c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for doublePendulum0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum0c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for doublePendulum0 (using wrong models):
  scoreConjectureCorrectModels=0.27143,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulum1: model ID11 / 35 (random ID1 / 2); time to go=3.78hours


 - Evaluation for doublePendulum1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum1c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulum1c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doublePendulum1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.6


Evaluation summary for doublePendulum1 (using wrong models):
  scoreConjectureCorrectModels=0.4,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nPendulum0: model ID12 / 35 (random ID0 / 2); time to go=3.7hours


 - Evaluation for nPendulum0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulum0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for nPendulum0 (using wrong models):
  scoreConjectureCorrectModels=0.15833,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nPendulum1: model ID12 / 35 (random ID1 / 2); time to go=3.54hours


 - Evaluation for nPendulum1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for nPendulum1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for nPendulum1 (using wrong models):
  scoreConjectureCorrectModels=0.14286,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures fourBarMechanismPointMasses0: model ID13 / 35 (random ID0 / 2); time to go=3.42hours


 - Evaluation for fourBarMechanismPointMasses0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for fourBarMechanismPointMasses0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for fourBarMechanismPointMasses0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for fourBarMechanismPointMasses0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for fourBarMechanismPointMasses0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for fourBarMechanismPointMasses0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for fourBarMechanismPointMasses0c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for fourBarMechanismPointMasses0 (using wrong models):
  scoreConjectureCorrectModels=0.37143,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures fourBarMechanismPointMasses1: model ID13 / 35 (random ID1 / 2); time to go=3.32hours


 - Evaluation for fourBarMechanismPointMasses1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for fourBarMechanismPointMasses1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for fourBarMechanismPointMasses1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for fourBarMechanismPointMasses1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for fourBarMechanismPointMasses1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for fourBarMechanismPointMasses1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for fourBarMechanismPointMasses1 (using wrong models):
  scoreConjectureCorrectModels=0.71667,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures springCoupledFlyingRigidBodies0: model ID14 / 35 (random ID0 / 2); time to go=3.29hours


 - Evaluation for springCoupledFlyingRigidBodies0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for springCoupledFlyingRigidBodies0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for springCoupledFlyingRigidBodies0c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for springCoupledFlyingRigidBodies0c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for springCoupledFlyingRigidBodies0c6 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for springCoupledFlyingRigidBodies0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for springCoupledFlyingRigidBodies0 (using wrong models):
  scoreConjectureCorrectModels=0.625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures springCoupledFlyingRigidBodies1: model ID14 / 35 (random ID1 / 2); time to go=3.18hours


 - Evaluation for springCoupledFlyingRigidBodies1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for springCoupledFlyingRigidBodies1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for springCoupledFlyingRigidBodies1c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for springCoupledFlyingRigidBodies1c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for springCoupledFlyingRigidBodies1c4 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for springCoupledFlyingRigidBodies1c6 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for springCoupledFlyingRigidBodies1c7 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for springCoupledFlyingRigidBodies1 (using wrong models):
  scoreConjectureCorrectModels=0.82857,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures torsionalOscillator0: model ID15 / 35 (random ID0 / 2); time to go=3.08hours


 - Evaluation for torsionalOscillator0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator0c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for torsionalOscillator0c2 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for torsionalOscillator0c3 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator0c4 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator0c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator0c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.0


Evaluation summary for torsionalOscillator0 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.225
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures torsionalOscillator1: model ID15 / 35 (random ID1 / 2); time to go=3.02hours


 - Evaluation for torsionalOscillator1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator1c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for torsionalOscillator1c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for torsionalOscillator1c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator1c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0


Evaluation summary for torsionalOscillator1 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.27143
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures invertedSinglePendulum0: model ID16 / 35 (random ID0 / 2); time to go=2.92hours


 - Evaluation for invertedSinglePendulum0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for invertedSinglePendulum0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for invertedSinglePendulum0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for invertedSinglePendulum0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for invertedSinglePendulum0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for invertedSinglePendulum0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for invertedSinglePendulum0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for invertedSinglePendulum0c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.2


Evaluation summary for invertedSinglePendulum0 (using wrong models):
  scoreConjectureCorrectModels=0.5875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures invertedSinglePendulum1: model ID16 / 35 (random ID1 / 2); time to go=2.86hours


 - Evaluation for invertedSinglePendulum1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for invertedSinglePendulum1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for invertedSinglePendulum1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for invertedSinglePendulum1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for invertedSinglePendulum1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for invertedSinglePendulum1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for invertedSinglePendulum1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for invertedSinglePendulum1 (using wrong models):
  scoreConjectureCorrectModels=0.39,  scoreConjectureWrongModels=0.8
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.8


***

EvaluateAllConjectures discRollingOnGround0: model ID17 / 35 (random ID0 / 2); time to go=2.77hours


 - Evaluation for discRollingOnGround0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for discRollingOnGround0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for discRollingOnGround0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.4

 - Evaluation for discRollingOnGround0c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround0c7 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.2


Evaluation summary for discRollingOnGround0 (using wrong models):
  scoreConjectureCorrectModels=0.55625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures discRollingOnGround1: model ID17 / 35 (random ID1 / 2); time to go=2.69hours


 - Evaluation for discRollingOnGround1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for discRollingOnGround1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround1c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for discRollingOnGround1 (using wrong models):
  scoreConjectureCorrectModels=0.36875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumElasticSpring0: model ID18 / 35 (random ID0 / 2); time to go=2.6hours


 - Evaluation for doublePendulumElasticSpring0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumElasticSpring0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumElasticSpring0c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.5

 - Evaluation for doublePendulumElasticSpring0c4 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumElasticSpring0c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doublePendulumElasticSpring0c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for doublePendulumElasticSpring0 (using wrong models):
  scoreConjectureCorrectModels=0.67,  scoreConjectureWrongModels=0.5
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.5


***

EvaluateAllConjectures doublePendulumElasticSpring1: model ID18 / 35 (random ID1 / 2); time to go=2.5hours


 - Evaluation for doublePendulumElasticSpring1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for doublePendulumElasticSpring1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumElasticSpring1c2 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for doublePendulumElasticSpring1c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for doublePendulumElasticSpring1c4 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumElasticSpring1c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumElasticSpring1c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for doublePendulumElasticSpring1 (using wrong models):
  scoreConjectureCorrectModels=0.6,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures nPendulumElasticSpring0: model ID19 / 35 (random ID0 / 2); time to go=2.41hours


 - Evaluation for nPendulumElasticSpring0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for nPendulumElasticSpring0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulumElasticSpring0c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulumElasticSpring0c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for nPendulumElasticSpring0c4 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for nPendulumElasticSpring0c5 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for nPendulumElasticSpring0c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulumElasticSpring0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for nPendulumElasticSpring0 (using wrong models):
  scoreConjectureCorrectModels=0.37143,  scoreConjectureWrongModels=1.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=1.0


***

EvaluateAllConjectures nPendulumElasticSpring1: model ID19 / 35 (random ID1 / 2); time to go=2.32hours


 - Evaluation for nPendulumElasticSpring1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulumElasticSpring1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulumElasticSpring1c2 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulumElasticSpring1c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulumElasticSpring1c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.8

 - Evaluation for nPendulumElasticSpring1c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulumElasticSpring1c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for nPendulumElasticSpring1c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.0


Evaluation summary for nPendulumElasticSpring1 (using wrong models):
  scoreConjectureCorrectModels=0.19,  scoreConjectureWrongModels=0.26667
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures elasticChain0: model ID20 / 35 (random ID0 / 2); time to go=2.23hours


 - Evaluation for elasticChain0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for elasticChain0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for elasticChain0c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for elasticChain0c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for elasticChain0c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for elasticChain0c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for elasticChain0c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for elasticChain0 (using wrong models):
  scoreConjectureCorrectModels=0.25714,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures elasticChain1: model ID20 / 35 (random ID1 / 2); time to go=2.14hours


 - Evaluation for elasticChain1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for elasticChain1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for elasticChain1c2 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for elasticChain1c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for elasticChain1c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for elasticChain1c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for elasticChain1c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for elasticChain1c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for elasticChain1 (using wrong models):
  scoreConjectureCorrectModels=0.7875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumRigidBody0: model ID21 / 35 (random ID0 / 2); time to go=2.07hours


 - Evaluation for singlePendulumRigidBody0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumRigidBody0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singlePendulumRigidBody0c3 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody0c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for singlePendulumRigidBody0c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singlePendulumRigidBody0c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumRigidBody0c7 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for singlePendulumRigidBody0 (using wrong models):
  scoreConjectureCorrectModels=0.6625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumRigidBody1: model ID21 / 35 (random ID1 / 2); time to go=2.01hours


 - Evaluation for singlePendulumRigidBody1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumRigidBody1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singlePendulumRigidBody1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody1c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody1c4 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singlePendulumRigidBody1c5 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for singlePendulumRigidBody1c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for singlePendulumRigidBody1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for singlePendulumRigidBody1 (using wrong models):
  scoreConjectureCorrectModels=0.66875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringRigid0: model ID22 / 35 (random ID0 / 2); time to go=1.96hours


 - Evaluation for massPointOnStringRigid0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringRigid0c1 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for massPointOnStringRigid0c2 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for massPointOnStringRigid0c3 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for massPointOnStringRigid0c4 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringRigid0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringRigid0c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for massPointOnStringRigid0 (using wrong models):
  scoreConjectureCorrectModels=0.56143,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringRigid1: model ID22 / 35 (random ID1 / 2); time to go=1.89hours


 - Evaluation for massPointOnStringRigid1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for massPointOnStringRigid1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringRigid1c2 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for massPointOnStringRigid1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringRigid1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for massPointOnStringRigid1c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for massPointOnStringRigid1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringRigid1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for massPointOnStringRigid1 (using wrong models):
  scoreConjectureCorrectModels=0.50625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringElastic0: model ID23 / 35 (random ID0 / 2); time to go=1.82hours


 - Evaluation for massPointOnStringElastic0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringElastic0c2 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic0c3 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic0c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringElastic0c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for massPointOnStringElastic0c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.4

 - Evaluation for massPointOnStringElastic0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0


Evaluation summary for massPointOnStringElastic0 (using wrong models):
  scoreConjectureCorrectModels=0.625,  scoreConjectureWrongModels=0.5
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures massPointOnStringElastic1: model ID23 / 35 (random ID1 / 2); time to go=1.74hours


 - Evaluation for massPointOnStringElastic1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringElastic1c2 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic1c3 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic1c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringElastic1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for massPointOnStringElastic1c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for massPointOnStringElastic1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.5


Evaluation summary for massPointOnStringElastic1 (using wrong models):
  scoreConjectureCorrectModels=0.585,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures linkOnTwoPrismaticJoints0: model ID24 / 35 (random ID0 / 2); time to go=1.67hours


 - Evaluation for linkOnTwoPrismaticJoints0c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for linkOnTwoPrismaticJoints0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for linkOnTwoPrismaticJoints0c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for linkOnTwoPrismaticJoints0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for linkOnTwoPrismaticJoints0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for linkOnTwoPrismaticJoints0c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for linkOnTwoPrismaticJoints0 (using wrong models):
  scoreConjectureCorrectModels=0.725,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures linkOnTwoPrismaticJoints1: model ID24 / 35 (random ID1 / 2); time to go=1.59hours


 - Evaluation for linkOnTwoPrismaticJoints1c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for linkOnTwoPrismaticJoints1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for linkOnTwoPrismaticJoints1c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for linkOnTwoPrismaticJoints1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for linkOnTwoPrismaticJoints1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for linkOnTwoPrismaticJoints1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for linkOnTwoPrismaticJoints1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for linkOnTwoPrismaticJoints1 (using wrong models):
  scoreConjectureCorrectModels=0.71429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingRigidBody0: model ID25 / 35 (random ID0 / 2); time to go=1.5hours


 - Evaluation for flyingRigidBody0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody0c2 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingRigidBody0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody0c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for flyingRigidBody0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody0c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for flyingRigidBody0 (using wrong models):
  scoreConjectureCorrectModels=0.25,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingRigidBody1: model ID25 / 35 (random ID1 / 2); time to go=1.46hours


 - Evaluation for flyingRigidBody1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody1c2 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for flyingRigidBody1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for flyingRigidBody1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody1c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingRigidBody1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for flyingRigidBody1 (using wrong models):
  scoreConjectureCorrectModels=0.46,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures suspendedRigidBody0: model ID26 / 35 (random ID0 / 2); time to go=1.39hours


 - Evaluation for suspendedRigidBody0c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for suspendedRigidBody0c2 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for suspendedRigidBody0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for suspendedRigidBody0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for suspendedRigidBody0c5 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for suspendedRigidBody0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for suspendedRigidBody0c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for suspendedRigidBody0 (using wrong models):
  scoreConjectureCorrectModels=0.95714,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.95415,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures suspendedRigidBody1: model ID26 / 35 (random ID1 / 2); time to go=1.32hours


 - Evaluation for suspendedRigidBody1c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for suspendedRigidBody1c2 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for suspendedRigidBody1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for suspendedRigidBody1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for suspendedRigidBody1c5 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for suspendedRigidBody1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for suspendedRigidBody1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.8


Evaluation summary for suspendedRigidBody1 (using wrong models):
  scoreConjectureCorrectModels=0.48,  scoreConjectureWrongModels=1.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=1.0


***

EvaluateAllConjectures gyroscopeOnSphericalJoint0: model ID27 / 35 (random ID0 / 2); time to go=1.24hours


 - Evaluation for gyroscopeOnSphericalJoint0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for gyroscopeOnSphericalJoint0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for gyroscopeOnSphericalJoint0c2 (using wrong models): method=Check if spherical motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for gyroscopeOnSphericalJoint0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for gyroscopeOnSphericalJoint0c4 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for gyroscopeOnSphericalJoint0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for gyroscopeOnSphericalJoint0c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for gyroscopeOnSphericalJoint0 (using wrong models):
  scoreConjectureCorrectModels=0.63333,  scoreConjectureWrongModels=0.25
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures gyroscopeOnSphericalJoint1: model ID27 / 35 (random ID1 / 2); time to go=1.17hours


 - Evaluation for gyroscopeOnSphericalJoint1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for gyroscopeOnSphericalJoint1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for gyroscopeOnSphericalJoint1c2 (using wrong models): method=Check if spherical motion, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for gyroscopeOnSphericalJoint1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for gyroscopeOnSphericalJoint1c4 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for gyroscopeOnSphericalJoint1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.6

 - Evaluation for gyroscopeOnSphericalJoint1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=False, scoreValue=0.8


Evaluation summary for gyroscopeOnSphericalJoint1 (using wrong models):
  scoreConjectureCorrectModels=0.66,  scoreConjectureWrongModels=0.825
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.81072


***

EvaluateAllConjectures prismaticJointSystem0: model ID28 / 35 (random ID0 / 2); time to go=1.1hours


 - Evaluation for prismaticJointSystem0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem0c2 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.4

 - Evaluation for prismaticJointSystem0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for prismaticJointSystem0 (using wrong models):
  scoreConjectureCorrectModels=0.06667,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures prismaticJointSystem1: model ID28 / 35 (random ID1 / 2); time to go=1.01hours


 - Evaluation for prismaticJointSystem1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem1c2 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.98


Evaluation summary for prismaticJointSystem1 (using wrong models):
  scoreConjectureCorrectModels=0.14,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithSprings0: model ID29 / 35 (random ID0 / 2); time to go=3356.24s


 - Evaluation for twoMassPointsWithSprings0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for twoMassPointsWithSprings0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for twoMassPointsWithSprings0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for twoMassPointsWithSprings0c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for twoMassPointsWithSprings0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for twoMassPointsWithSprings0 (using wrong models):
  scoreConjectureCorrectModels=0.976,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.9752,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithSprings1: model ID29 / 35 (random ID1 / 2); time to go=3054.26s


 - Evaluation for twoMassPointsWithSprings1c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for twoMassPointsWithSprings1c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.99

 - Evaluation for twoMassPointsWithSprings1c4 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.4

 - Evaluation for twoMassPointsWithSprings1c6 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithSprings1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for twoMassPointsWithSprings1 (using wrong models):
  scoreConjectureCorrectModels=0.668,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithDistances0: model ID30 / 35 (random ID0 / 2); time to go=2762.47s


 - Evaluation for twoMassPointsWithDistances0c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for twoMassPointsWithDistances0c2 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for twoMassPointsWithDistances0c3 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for twoMassPointsWithDistances0c5 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for twoMassPointsWithDistances0c6 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for twoMassPointsWithDistances0c7 (using wrong models): method=Perform a rough calculation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for twoMassPointsWithDistances0 (using wrong models):
  scoreConjectureCorrectModels=0.43333,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithDistances1: model ID30 / 35 (random ID1 / 2); time to go=2481.53s


 - Evaluation for twoMassPointsWithDistances1c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for twoMassPointsWithDistances1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for twoMassPointsWithDistances1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for twoMassPointsWithDistances1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for twoMassPointsWithDistances1 (using wrong models):
  scoreConjectureCorrectModels=0.575,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorSimplySupported0: model ID31 / 35 (random ID0 / 2); time to go=2200.99s


 - Evaluation for rigidRotorSimplySupported0c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for rigidRotorSimplySupported0c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for rigidRotorSimplySupported0c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for rigidRotorSimplySupported0 (using wrong models):
  scoreConjectureCorrectModels=1.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=1.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorSimplySupported1: model ID31 / 35 (random ID1 / 2); time to go=1905.46s


 - Evaluation for rigidRotorSimplySupported1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for rigidRotorSimplySupported1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for rigidRotorSimplySupported1c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for rigidRotorSimplySupported1c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for rigidRotorSimplySupported1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for rigidRotorSimplySupported1 (using wrong models):
  scoreConjectureCorrectModels=0.97,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.96915,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorUnbalanced0: model ID32 / 35 (random ID0 / 2); time to go=1623.69s


 - Evaluation for rigidRotorUnbalanced0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for rigidRotorUnbalanced0c2 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced0c3 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for rigidRotorUnbalanced0c4 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for rigidRotorUnbalanced0c5 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for rigidRotorUnbalanced0c6 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced0c7 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for rigidRotorUnbalanced0 (using wrong models):
  scoreConjectureCorrectModels=0.425,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorUnbalanced1: model ID32 / 35 (random ID1 / 2); time to go=1349.02s


 - Evaluation for rigidRotorUnbalanced1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced1c2 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced1c3 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for rigidRotorUnbalanced1c4 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for rigidRotorUnbalanced1c5 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced1c6 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for rigidRotorUnbalanced1c7 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for rigidRotorUnbalanced1 (using wrong models):
  scoreConjectureCorrectModels=0.625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumRigidBodies0: model ID33 / 35 (random ID0 / 2); time to go=1077.22s


 - Evaluation for doublePendulumRigidBodies0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doublePendulumRigidBodies0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumRigidBodies0c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumRigidBodies0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doublePendulumRigidBodies0c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.8

 - Evaluation for doublePendulumRigidBodies0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for doublePendulumRigidBodies0 (using wrong models):
  scoreConjectureCorrectModels=0.46667,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumRigidBodies1: model ID33 / 35 (random ID1 / 2); time to go=806.02s


 - Evaluation for doublePendulumRigidBodies1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doublePendulumRigidBodies1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumRigidBodies1c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumRigidBodies1c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumRigidBodies1c4 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doublePendulumRigidBodies1c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumRigidBodies1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for doublePendulumRigidBodies1 (using wrong models):
  scoreConjectureCorrectModels=0.42857,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankRigidBodies0: model ID34 / 35 (random ID0 / 2); time to go=537.95s


 - Evaluation for sliderCrankRigidBodies0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for sliderCrankRigidBodies0c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for sliderCrankRigidBodies0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies0c7 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for sliderCrankRigidBodies0 (using wrong models):
  scoreConjectureCorrectModels=0.75,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankRigidBodies1: model ID34 / 35 (random ID1 / 2); time to go=268.6s


 - Evaluation for sliderCrankRigidBodies1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for sliderCrankRigidBodies1c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for sliderCrankRigidBodies1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for sliderCrankRigidBodies1c7 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for sliderCrankRigidBodies1 (using wrong models):
  scoreConjectureCorrectModels=0.57143,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

A total of:
  1 errors and
  0 warnings
were logged!

***

Summary of EvaluateAllConjectures (using wrong models)
 - useSimEvaluationOnly = True
 - sumScoreTotalConjectures = 242.2000000000002
 - nTotalConjectures = 480
 - sumScoreTotalConjectureCorrectModels = 214.50000000000023
 - sumScoreTotalConjectureWrongModels = 27.700000000000003
 - nTotalConjectureCorrectModels = 414
 - nTotalConjectureWrongModels = 66
 - sumMultScoreTotalConjectureCorrectModels = 6.657713460154173
 - sumMultScoreTotalConjectureWrongModels = 4.96367683465202
 - nTotalMultConjectureCorrectModels = 65
 - nTotalMultConjectureWrongModels = 18
 - numberOfRemovedTokensGlobal = 0
 - numberOfTokensGlobal = 187400
 - totalScoreConjectureCorrectModels = 0.518115942028986
 - totalScoreConjectureWrongModels = 0.41969696969696973
 - totalMultScoreConjectureCorrectModels = 0.10242636092544881
 - totalMultScoreConjectureWrongModels = 0.27575982414733446
 - runTime = 18704.38623356819
 - loggerErrors = 1
 - loggerWarnings = 0


