
***

Evaluate conjectures: nModels=70, nConjPerModel=8, LLM model=phi-4-Q4_0.gguf

***

EvaluateAllConjectures flyingMassPoint0: model ID0 / 35 (random ID0 / 2)


 - Evaluation for flyingMassPoint0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for flyingMassPoint0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingMassPoint0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for flyingMassPoint0c3: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for flyingMassPoint0c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for flyingMassPoint0c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingMassPoint0c7: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for flyingMassPoint0:
  scoreConjectureCorrectModels=0.97125,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.97109,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingMassPoint1: model ID0 / 35 (random ID1 / 2); time to go=1.71hours


 - Evaluation for flyingMassPoint1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for flyingMassPoint1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint1c3: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for flyingMassPoint1c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for flyingMassPoint1c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingMassPoint1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for flyingMassPoint1:
  scoreConjectureCorrectModels=0.9925,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.99245,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures freeFallMassPoint0: model ID1 / 35 (random ID0 / 2); time to go=1.68hours


 - Evaluation for freeFallMassPoint0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for freeFallMassPoint0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for freeFallMassPoint0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for freeFallMassPoint0c3: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for freeFallMassPoint0c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for freeFallMassPoint0c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for freeFallMassPoint0:
  scoreConjectureCorrectModels=0.84429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures freeFallMassPoint1: model ID1 / 35 (random ID1 / 2); time to go=1.65hours


 - Evaluation for freeFallMassPoint1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.7

 - Evaluation for freeFallMassPoint1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for freeFallMassPoint1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.65

 - Evaluation for freeFallMassPoint1c3: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for freeFallMassPoint1c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for freeFallMassPoint1c5: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for freeFallMassPoint1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for freeFallMassPoint1:
  scoreConjectureCorrectModels=0.755,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.66841,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures singleMassOscillator0: model ID2 / 35 (random ID0 / 2); time to go=1.67hours


 - Evaluation for singleMassOscillator0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillator0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillator0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator0c3: method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillator0c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillator0c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillator0c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillator0c7: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for singleMassOscillator0:
  scoreConjectureCorrectModels=0.7125,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillator1: model ID2 / 35 (random ID1 / 2); time to go=1.6hours


 - Evaluation for singleMassOscillator1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillator1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.4

 - Evaluation for singleMassOscillator1c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillator1c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillator1c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singleMassOscillator1c7: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for singleMassOscillator1:
  scoreConjectureCorrectModels=0.85714,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.82601,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorGravity0: model ID3 / 35 (random ID0 / 2); time to go=1.5hours


 - Evaluation for singleMassOscillatorGravity0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singleMassOscillatorGravity0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillatorGravity0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity0c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillatorGravity0c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillatorGravity0c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillatorGravity0c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for singleMassOscillatorGravity0:
  scoreConjectureCorrectModels=0.92857,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.92669,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorGravity1: model ID3 / 35 (random ID1 / 2); time to go=1.43hours


 - Evaluation for singleMassOscillatorGravity1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillatorGravity1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillatorGravity1c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillatorGravity1c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillatorGravity1c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity1c7: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for singleMassOscillatorGravity1:
  scoreConjectureCorrectModels=0.92143,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.92028,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankSimple0: model ID4 / 35 (random ID0 / 2); time to go=1.37hours



Evaluation summary for sliderCrankSimple0:
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankSimple1: model ID4 / 35 (random ID1 / 2); time to go=1.2hours


 - Evaluation for sliderCrankSimple1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for sliderCrankSimple1:
  scoreConjectureCorrectModels=0.95,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.95,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumElasticSpring0: model ID5 / 35 (random ID0 / 2); time to go=1.08hours


 - Evaluation for singlePendulumElasticSpring0c0: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for singlePendulumElasticSpring0c1: method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for singlePendulumElasticSpring0c2: method=Check if planar motion, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for singlePendulumElasticSpring0c3: method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for singlePendulumElasticSpring0c4: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring0c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulumElasticSpring0c6: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for singlePendulumElasticSpring0c7: method=Evaluate symmetry, modelIsCorrect=False, scoreValue=0.95


Evaluation summary for singlePendulumElasticSpring0:
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.81875
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures singlePendulumElasticSpring1: model ID5 / 35 (random ID1 / 2); time to go=1.05hours


 - Evaluation for singlePendulumElasticSpring1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumElasticSpring1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumElasticSpring1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumElasticSpring1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumElasticSpring1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singlePendulumElasticSpring1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for singlePendulumElasticSpring1c6: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for singlePendulumElasticSpring1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for singlePendulumElasticSpring1:
  scoreConjectureCorrectModels=0.83571,  scoreConjectureWrongModels=0.95
  multScoreConjectureCorrectModels=0.75457,  multScoreConjectureWrongModels=0.95


***

EvaluateAllConjectures singleMassOscillatorUserFunction0: model ID6 / 35 (random ID0 / 2); time to go=1.04hours


 - Evaluation for singleMassOscillatorUserFunction0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorUserFunction0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillatorUserFunction0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillatorUserFunction0c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillatorUserFunction0c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillatorUserFunction0c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorUserFunction0c7: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for singleMassOscillatorUserFunction0:
  scoreConjectureCorrectModels=0.69286,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorUserFunction1: model ID6 / 35 (random ID1 / 2); time to go=1.02hours


 - Evaluation for singleMassOscillatorUserFunction1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singleMassOscillatorUserFunction1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for singleMassOscillatorUserFunction1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillatorUserFunction1c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singleMassOscillatorUserFunction1c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillatorUserFunction1c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction1c7: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for singleMassOscillatorUserFunction1:
  scoreConjectureCorrectModels=0.92857,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.92746,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures spinningDisc0: model ID7 / 35 (random ID0 / 2); time to go=3589.18s


 - Evaluation for spinningDisc0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for spinningDisc0c1: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for spinningDisc0c2: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for spinningDisc0c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for spinningDisc0c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc0c6: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for spinningDisc0c7: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for spinningDisc0:
  scoreConjectureCorrectModels=0.95714,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.95699,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures spinningDisc1: model ID7 / 35 (random ID1 / 2); time to go=3549.86s


 - Evaluation for spinningDisc1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for spinningDisc1c1: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for spinningDisc1c2: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for spinningDisc1c3: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for spinningDisc1c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for spinningDisc1c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc1c6: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for spinningDisc1c7: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for spinningDisc1:
  scoreConjectureCorrectModels=0.785,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doubleMassOscillator0: model ID8 / 35 (random ID0 / 2); time to go=3523.41s


 - Evaluation for doubleMassOscillator0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doubleMassOscillator0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator0c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator0c4: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doubleMassOscillator0c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doubleMassOscillator0c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator0c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for doubleMassOscillator0:
  scoreConjectureCorrectModels=0.89286,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.8915,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doubleMassOscillator1: model ID8 / 35 (random ID1 / 2); time to go=3451.4s


 - Evaluation for doubleMassOscillator1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doubleMassOscillator1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doubleMassOscillator1c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator1c4: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doubleMassOscillator1c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doubleMassOscillator1c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doubleMassOscillator1c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for doubleMassOscillator1:
  scoreConjectureCorrectModels=0.91429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.9132,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nMassOscillator0: model ID9 / 35 (random ID0 / 2); time to go=3376.21s


 - Evaluation for nMassOscillator0c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for nMassOscillator0c2: method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.75

 - Evaluation for nMassOscillator0c3: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nMassOscillator0c4: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for nMassOscillator0c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for nMassOscillator0c6: method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for nMassOscillator0c7: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.85


Evaluation summary for nMassOscillator0:
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.87857
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.87609


***

EvaluateAllConjectures nMassOscillator1: model ID9 / 35 (random ID1 / 2); time to go=3288.03s


 - Evaluation for nMassOscillator1c0: method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nMassOscillator1c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for nMassOscillator1c2: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nMassOscillator1c3: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nMassOscillator1c4: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nMassOscillator1c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nMassOscillator1c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nMassOscillator1c7: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for nMassOscillator1:
  scoreConjectureCorrectModels=0.78333,  scoreConjectureWrongModels=0.9
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.89861


***

EvaluateAllConjectures singlePendulum0: model ID10 / 35 (random ID0 / 2); time to go=3242.18s


 - Evaluation for singlePendulum0c0: method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for singlePendulum0c1: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for singlePendulum0c2: method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for singlePendulum0c3: method=Check if planar motion, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for singlePendulum0c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singlePendulum0c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulum0c6: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulum0c7: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.85


Evaluation summary for singlePendulum0:
  scoreConjectureCorrectModels=0.925,  scoreConjectureWrongModels=0.91667
  multScoreConjectureCorrectModels=0.92195,  multScoreConjectureWrongModels=0.91542


***

EvaluateAllConjectures singlePendulum1: model ID10 / 35 (random ID1 / 2); time to go=3208.55s


 - Evaluation for singlePendulum1c1: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulum1c2: method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for singlePendulum1c3: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulum1c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulum1c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for singlePendulum1c6: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for singlePendulum1c7: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.85


Evaluation summary for singlePendulum1:
  scoreConjectureCorrectModels=0.7,  scoreConjectureWrongModels=0.6875
  multScoreConjectureCorrectModels=0.56514,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures doublePendulum0: model ID11 / 35 (random ID0 / 2); time to go=3114.59s


 - Evaluation for doublePendulum0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.7

 - Evaluation for doublePendulum0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doublePendulum0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doublePendulum0c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum0c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for doublePendulum0:
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.84688,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulum1: model ID11 / 35 (random ID1 / 2); time to go=3049.51s


 - Evaluation for doublePendulum1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doublePendulum1c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum1c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for doublePendulum1c6: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85


***

*****
ERROR:** 

```
EvaluateConjecture: score is invalid: ERROR in ExtractXMLtaggedString: received 0 start tags and 0 end tags!
***
```

 - Evaluation for doublePendulum1c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=-3


Evaluation summary for doublePendulum1:
  scoreConjectureCorrectModels=0.4,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nPendulum0: model ID12 / 35 (random ID0 / 2); time to go=3015.43s


 - Evaluation for nPendulum0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulum0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulum0c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulum0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulum0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for nPendulum0:
  scoreConjectureCorrectModels=0.775,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nPendulum1: model ID12 / 35 (random ID1 / 2); time to go=2938.04s


 - Evaluation for nPendulum1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for nPendulum1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulum1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulum1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulum1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum1c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for nPendulum1:
  scoreConjectureCorrectModels=0.67143,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures fourBarMechanismPointMasses0: model ID13 / 35 (random ID0 / 2); time to go=2882.86s


 - Evaluation for fourBarMechanismPointMasses0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for fourBarMechanismPointMasses0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for fourBarMechanismPointMasses0c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for fourBarMechanismPointMasses0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for fourBarMechanismPointMasses0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for fourBarMechanismPointMasses0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for fourBarMechanismPointMasses0c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for fourBarMechanismPointMasses0:
  scoreConjectureCorrectModels=0.79286,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures fourBarMechanismPointMasses1: model ID13 / 35 (random ID1 / 2); time to go=2800.74s


 - Evaluation for fourBarMechanismPointMasses1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for fourBarMechanismPointMasses1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for fourBarMechanismPointMasses1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for fourBarMechanismPointMasses1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for fourBarMechanismPointMasses1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for fourBarMechanismPointMasses1c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for fourBarMechanismPointMasses1:
  scoreConjectureCorrectModels=0.94167,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.94148,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures springCoupledFlyingRigidBodies0: model ID14 / 35 (random ID0 / 2); time to go=2700.93s


 - Evaluation for springCoupledFlyingRigidBodies0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for springCoupledFlyingRigidBodies0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for springCoupledFlyingRigidBodies0c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for springCoupledFlyingRigidBodies0c3: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for springCoupledFlyingRigidBodies0c6: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for springCoupledFlyingRigidBodies0c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for springCoupledFlyingRigidBodies0:
  scoreConjectureCorrectModels=0.95833,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.95816,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures springCoupledFlyingRigidBodies1: model ID14 / 35 (random ID1 / 2); time to go=2631.53s


 - Evaluation for springCoupledFlyingRigidBodies1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for springCoupledFlyingRigidBodies1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for springCoupledFlyingRigidBodies1c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for springCoupledFlyingRigidBodies1c3: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for springCoupledFlyingRigidBodies1c4: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for springCoupledFlyingRigidBodies1c6: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for springCoupledFlyingRigidBodies1c7: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for springCoupledFlyingRigidBodies1:
  scoreConjectureCorrectModels=0.92857,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.92705,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures torsionalOscillator0: model ID15 / 35 (random ID0 / 2); time to go=2549.02s


 - Evaluation for torsionalOscillator0c0: method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for torsionalOscillator0c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator0c2: method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator0c3: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for torsionalOscillator0c4: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for torsionalOscillator0c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for torsionalOscillator0c6: method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator0c7: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.95


Evaluation summary for torsionalOscillator0:
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.58125
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures torsionalOscillator1: model ID15 / 35 (random ID1 / 2); time to go=2489.25s


 - Evaluation for torsionalOscillator1c0: method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for torsionalOscillator1c1: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for torsionalOscillator1c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator1c3: method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator1c4: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for torsionalOscillator1c5: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for torsionalOscillator1c6: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.95


Evaluation summary for torsionalOscillator1:
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.65
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures invertedSinglePendulum0: model ID16 / 35 (random ID0 / 2); time to go=2425.55s


 - Evaluation for invertedSinglePendulum0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for invertedSinglePendulum0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for invertedSinglePendulum0c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for invertedSinglePendulum0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for invertedSinglePendulum0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for invertedSinglePendulum0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum0c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for invertedSinglePendulum0c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for invertedSinglePendulum0:
  scoreConjectureCorrectModels=0.925,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.92395,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures invertedSinglePendulum1: model ID16 / 35 (random ID1 / 2); time to go=2363.16s


 - Evaluation for invertedSinglePendulum1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for invertedSinglePendulum1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for invertedSinglePendulum1c3: method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for invertedSinglePendulum1c4: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for invertedSinglePendulum1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.75

 - Evaluation for invertedSinglePendulum1c6: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for invertedSinglePendulum1:
  scoreConjectureCorrectModels=0.89,  scoreConjectureWrongModels=0.925
  multScoreConjectureCorrectModels=0.8862,  multScoreConjectureWrongModels=0.92466


***

EvaluateAllConjectures discRollingOnGround0: model ID17 / 35 (random ID0 / 2); time to go=2291.96s


 - Evaluation for discRollingOnGround0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for discRollingOnGround0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround0c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for discRollingOnGround0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for discRollingOnGround0c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround0c7: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for discRollingOnGround0:
  scoreConjectureCorrectModels=0.97,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.96872,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures discRollingOnGround1: model ID17 / 35 (random ID1 / 2); time to go=2233.94s


 - Evaluation for discRollingOnGround1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for discRollingOnGround1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for discRollingOnGround1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround1c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for discRollingOnGround1:
  scoreConjectureCorrectModels=0.985,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.98477,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumElasticSpring0: model ID18 / 35 (random ID0 / 2); time to go=2167.94s


 - Evaluation for doublePendulumElasticSpring0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumElasticSpring0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doublePendulumElasticSpring0c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.2

 - Evaluation for doublePendulumElasticSpring0c4: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doublePendulumElasticSpring0c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doublePendulumElasticSpring0c7: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for doublePendulumElasticSpring0:
  scoreConjectureCorrectModels=0.92,  scoreConjectureWrongModels=0.2
  multScoreConjectureCorrectModels=0.91911,  multScoreConjectureWrongModels=0.2


***

EvaluateAllConjectures doublePendulumElasticSpring1: model ID18 / 35 (random ID1 / 2); time to go=2084.72s


 - Evaluation for doublePendulumElasticSpring1c0: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for doublePendulumElasticSpring1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doublePendulumElasticSpring1c2: method=Evaluate static equilibrium for damped systems, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for doublePendulumElasticSpring1c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for doublePendulumElasticSpring1c4: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumElasticSpring1c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doublePendulumElasticSpring1c7: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for doublePendulumElasticSpring1:
  scoreConjectureCorrectModels=0.6625,  scoreConjectureWrongModels=0.56667
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures nPendulumElasticSpring0: model ID19 / 35 (random ID0 / 2); time to go=2006.21s


 - Evaluation for nPendulumElasticSpring0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulumElasticSpring0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for nPendulumElasticSpring0c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulumElasticSpring0c3: method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for nPendulumElasticSpring0c4: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulumElasticSpring0c5: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulumElasticSpring0c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulumElasticSpring0c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for nPendulumElasticSpring0:
  scoreConjectureCorrectModels=0.92857,  scoreConjectureWrongModels=0.95
  multScoreConjectureCorrectModels=0.92783,  multScoreConjectureWrongModels=0.95


***

EvaluateAllConjectures nPendulumElasticSpring1: model ID19 / 35 (random ID1 / 2); time to go=1941.31s


 - Evaluation for nPendulumElasticSpring1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulumElasticSpring1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulumElasticSpring1c2: method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring1c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for nPendulumElasticSpring1c4: method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for nPendulumElasticSpring1c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for nPendulumElasticSpring1c6: method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for nPendulumElasticSpring1c7: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.9


Evaluation summary for nPendulumElasticSpring1:
  scoreConjectureCorrectModels=0.93,  scoreConjectureWrongModels=0.91667
  multScoreConjectureCorrectModels=0.92859,  multScoreConjectureWrongModels=0.91637


***

EvaluateAllConjectures elasticChain0: model ID20 / 35 (random ID0 / 2); time to go=1874.24s


 - Evaluation for elasticChain0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for elasticChain0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for elasticChain0c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain0c4: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain0c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for elasticChain0c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for elasticChain0c7: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for elasticChain0:
  scoreConjectureCorrectModels=0.52143,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures elasticChain1: model ID20 / 35 (random ID1 / 2); time to go=1802.32s


 - Evaluation for elasticChain1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for elasticChain1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for elasticChain1c2: method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for elasticChain1c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for elasticChain1c4: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for elasticChain1c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for elasticChain1c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for elasticChain1c7: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for elasticChain1:
  scoreConjectureCorrectModels=0.9125,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.90274,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumRigidBody0: model ID21 / 35 (random ID0 / 2); time to go=1737.09s


 - Evaluation for singlePendulumRigidBody0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumRigidBody0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumRigidBody0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumRigidBody0c3: method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody0c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.1

 - Evaluation for singlePendulumRigidBody0c5: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumRigidBody0c6: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody0c7: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for singlePendulumRigidBody0:
  scoreConjectureCorrectModels=0.60625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumRigidBody1: model ID21 / 35 (random ID1 / 2); time to go=1676.63s


 - Evaluation for singlePendulumRigidBody1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.75

 - Evaluation for singlePendulumRigidBody1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumRigidBody1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumRigidBody1c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for singlePendulumRigidBody1c4: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumRigidBody1c5: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody1c6: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody1c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.75


Evaluation summary for singlePendulumRigidBody1:
  scoreConjectureCorrectModels=0.725,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringRigid0: model ID22 / 35 (random ID0 / 2); time to go=1618.96s


 - Evaluation for massPointOnStringRigid0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringRigid0c1: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for massPointOnStringRigid0c2: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringRigid0c3: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for massPointOnStringRigid0c4: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.75

 - Evaluation for massPointOnStringRigid0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringRigid0c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for massPointOnStringRigid0:
  scoreConjectureCorrectModels=0.93286,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.92933,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringRigid1: model ID22 / 35 (random ID1 / 2); time to go=1562.02s


 - Evaluation for massPointOnStringRigid1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringRigid1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringRigid1c2: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for massPointOnStringRigid1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringRigid1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringRigid1c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringRigid1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringRigid1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for massPointOnStringRigid1:
  scoreConjectureCorrectModels=0.82875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringElastic0: model ID23 / 35 (random ID0 / 2); time to go=1505.61s


 - Evaluation for massPointOnStringElastic0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringElastic0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringElastic0c2: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringElastic0c3: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic0c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringElastic0c5: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for massPointOnStringElastic0c6: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringElastic0c7: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.85


Evaluation summary for massPointOnStringElastic0:
  scoreConjectureCorrectModels=0.93333,  scoreConjectureWrongModels=0.9
  multScoreConjectureCorrectModels=0.93255,  multScoreConjectureWrongModels=0.89861


***

EvaluateAllConjectures massPointOnStringElastic1: model ID23 / 35 (random ID1 / 2); time to go=1442.39s


 - Evaluation for massPointOnStringElastic1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringElastic1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringElastic1c2: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringElastic1c3: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringElastic1c4: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic1c5: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringElastic1c6: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic1c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for massPointOnStringElastic1:
  scoreConjectureCorrectModels=0.91875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.91772,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures linkOnTwoPrismaticJoints0: model ID24 / 35 (random ID0 / 2); time to go=1381.57s


 - Evaluation for linkOnTwoPrismaticJoints0c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for linkOnTwoPrismaticJoints0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for linkOnTwoPrismaticJoints0c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for linkOnTwoPrismaticJoints0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for linkOnTwoPrismaticJoints0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for linkOnTwoPrismaticJoints0c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for linkOnTwoPrismaticJoints0:
  scoreConjectureCorrectModels=0.91667,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.91542,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures linkOnTwoPrismaticJoints1: model ID24 / 35 (random ID1 / 2); time to go=1314.93s


 - Evaluation for linkOnTwoPrismaticJoints1c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for linkOnTwoPrismaticJoints1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for linkOnTwoPrismaticJoints1c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for linkOnTwoPrismaticJoints1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for linkOnTwoPrismaticJoints1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for linkOnTwoPrismaticJoints1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for linkOnTwoPrismaticJoints1c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for linkOnTwoPrismaticJoints1:
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.76571,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingRigidBody0: model ID25 / 35 (random ID0 / 2); time to go=1249.16s


 - Evaluation for flyingRigidBody0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingRigidBody0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingRigidBody0c2: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingRigidBody0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingRigidBody0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingRigidBody0c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.3

 - Evaluation for flyingRigidBody0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingRigidBody0c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for flyingRigidBody0:
  scoreConjectureCorrectModels=0.8875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.8385,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingRigidBody1: model ID25 / 35 (random ID1 / 2); time to go=1207.78s


 - Evaluation for flyingRigidBody1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for flyingRigidBody1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingRigidBody1c2: method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for flyingRigidBody1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for flyingRigidBody1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingRigidBody1c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for flyingRigidBody1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for flyingRigidBody1:
  scoreConjectureCorrectModels=0.8325,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures suspendedRigidBody0: model ID26 / 35 (random ID0 / 2); time to go=1159.34s


 - Evaluation for suspendedRigidBody0c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for suspendedRigidBody0c2: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for suspendedRigidBody0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for suspendedRigidBody0c5: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for suspendedRigidBody0c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for suspendedRigidBody0:
  scoreConjectureCorrectModels=0.78571,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures suspendedRigidBody1: model ID26 / 35 (random ID1 / 2); time to go=1093.13s


 - Evaluation for suspendedRigidBody1c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for suspendedRigidBody1c2: method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for suspendedRigidBody1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for suspendedRigidBody1c4: method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for suspendedRigidBody1c5: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for suspendedRigidBody1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for suspendedRigidBody1:
  scoreConjectureCorrectModels=0.74,  scoreConjectureWrongModels=0.475
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures gyroscopeOnSphericalJoint0: model ID27 / 35 (random ID0 / 2); time to go=1027.3s


 - Evaluation for gyroscopeOnSphericalJoint0c0: method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for gyroscopeOnSphericalJoint0c1: method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for gyroscopeOnSphericalJoint0c2: method=Check if spherical motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for gyroscopeOnSphericalJoint0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for gyroscopeOnSphericalJoint0c4: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for gyroscopeOnSphericalJoint0c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.2

 - Evaluation for gyroscopeOnSphericalJoint0c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for gyroscopeOnSphericalJoint0:
  scoreConjectureCorrectModels=0.96667,  scoreConjectureWrongModels=0.725
  multScoreConjectureCorrectModels=0.96638,  multScoreConjectureWrongModels=0.61745


***

EvaluateAllConjectures gyroscopeOnSphericalJoint1: model ID27 / 35 (random ID1 / 2); time to go=961.69s


 - Evaluation for gyroscopeOnSphericalJoint1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for gyroscopeOnSphericalJoint1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for gyroscopeOnSphericalJoint1c2: method=Check if spherical motion, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for gyroscopeOnSphericalJoint1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for gyroscopeOnSphericalJoint1c4: method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for gyroscopeOnSphericalJoint1c5: method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for gyroscopeOnSphericalJoint1c6: method=Evaluate symmetry, modelIsCorrect=False, scoreValue=0.95


Evaluation summary for gyroscopeOnSphericalJoint1:
  scoreConjectureCorrectModels=0.95,  scoreConjectureWrongModels=0.725
  multScoreConjectureCorrectModels=0.95,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures prismaticJointSystem0: model ID28 / 35 (random ID0 / 2); time to go=895.46s


 - Evaluation for prismaticJointSystem0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem0c2: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem0c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for prismaticJointSystem0:
  scoreConjectureCorrectModels=1.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=1.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures prismaticJointSystem1: model ID28 / 35 (random ID1 / 2); time to go=829.87s


 - Evaluation for prismaticJointSystem1c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem1c2: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for prismaticJointSystem1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for prismaticJointSystem1c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for prismaticJointSystem1:
  scoreConjectureCorrectModels=0.99286,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.9927,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithSprings0: model ID29 / 35 (random ID0 / 2); time to go=767.87s


 - Evaluation for twoMassPointsWithSprings0c0: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithSprings0c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithSprings0c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithSprings0c3: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithSprings0c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for twoMassPointsWithSprings0:
  scoreConjectureCorrectModels=0.96,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.9598,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithSprings1: model ID29 / 35 (random ID1 / 2); time to go=703.69s


 - Evaluation for twoMassPointsWithSprings1c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithSprings1c1: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for twoMassPointsWithSprings1c4: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for twoMassPointsWithSprings1c6: method=Check if circular motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithSprings1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for twoMassPointsWithSprings1:
  scoreConjectureCorrectModels=0.97,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.96969,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithDistances0: model ID30 / 35 (random ID0 / 2); time to go=638.25s


 - Evaluation for twoMassPointsWithDistances0c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithDistances0c2: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithDistances0c3: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for twoMassPointsWithDistances0c5: method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.1

 - Evaluation for twoMassPointsWithDistances0c6: method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithDistances0c7: method=Perform a rough calculation, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for twoMassPointsWithDistances0:
  scoreConjectureCorrectModels=0.81667,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.65839,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithDistances1: model ID30 / 35 (random ID1 / 2); time to go=573.3s


 - Evaluation for twoMassPointsWithDistances1c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithDistances1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithDistances1c5: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for twoMassPointsWithDistances1c6: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for twoMassPointsWithDistances1:
  scoreConjectureCorrectModels=0.7125,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorSimplySupported0: model ID31 / 35 (random ID0 / 2); time to go=507.73s


 - Evaluation for rigidRotorSimplySupported0c0: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorSimplySupported0c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorSimplySupported0c3: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.75


Evaluation summary for rigidRotorSimplySupported0:
  scoreConjectureCorrectModels=0.88333,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.87802,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorSimplySupported1: model ID31 / 35 (random ID1 / 2); time to go=439.54s


 - Evaluation for rigidRotorSimplySupported1c1: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorSimplySupported1c2: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorSimplySupported1c4: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorSimplySupported1c5: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorSimplySupported1c7: method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for rigidRotorSimplySupported1:
  scoreConjectureCorrectModels=0.95,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.95,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorUnbalanced0: model ID32 / 35 (random ID0 / 2); time to go=374.51s


 - Evaluation for rigidRotorUnbalanced0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorUnbalanced0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorUnbalanced0c2: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorUnbalanced0c3: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorUnbalanced0c4: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced0c5: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced0c6: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced0c7: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for rigidRotorUnbalanced0:
  scoreConjectureCorrectModels=0.9,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.89861,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorUnbalanced1: model ID32 / 35 (random ID1 / 2); time to go=312.2s


 - Evaluation for rigidRotorUnbalanced1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorUnbalanced1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorUnbalanced1c2: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorUnbalanced1c3: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorUnbalanced1c4: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced1c5: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for rigidRotorUnbalanced1c6: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced1c7: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for rigidRotorUnbalanced1:
  scoreConjectureCorrectModels=0.83125,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.76043,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumRigidBodies0: model ID33 / 35 (random ID0 / 2); time to go=249.59s


 - Evaluation for doublePendulumRigidBodies0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doublePendulumRigidBodies0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumRigidBodies0c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumRigidBodies0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doublePendulumRigidBodies0c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for doublePendulumRigidBodies0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for doublePendulumRigidBodies0:
  scoreConjectureCorrectModels=0.55833,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumRigidBodies1: model ID33 / 35 (random ID1 / 2); time to go=186.37s


 - Evaluation for doublePendulumRigidBodies1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumRigidBodies1c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doublePendulumRigidBodies1c2: method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doublePendulumRigidBodies1c3: method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumRigidBodies1c4: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doublePendulumRigidBodies1c6: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.75

 - Evaluation for doublePendulumRigidBodies1c7: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for doublePendulumRigidBodies1:
  scoreConjectureCorrectModels=0.75,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankRigidBodies0: model ID34 / 35 (random ID0 / 2); time to go=124.13s


 - Evaluation for sliderCrankRigidBodies0c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for sliderCrankRigidBodies0c1: method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for sliderCrankRigidBodies0c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for sliderCrankRigidBodies0c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.3

 - Evaluation for sliderCrankRigidBodies0c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for sliderCrankRigidBodies0c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for sliderCrankRigidBodies0c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for sliderCrankRigidBodies0c7: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for sliderCrankRigidBodies0:
  scoreConjectureCorrectModels=0.8725,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.82573,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankRigidBodies1: model ID34 / 35 (random ID1 / 2); time to go=62.03s


 - Evaluation for sliderCrankRigidBodies1c0: method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for sliderCrankRigidBodies1c2: method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies1c3: method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.45

 - Evaluation for sliderCrankRigidBodies1c4: method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for sliderCrankRigidBodies1c5: method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for sliderCrankRigidBodies1c6: method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for sliderCrankRigidBodies1c7: method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for sliderCrankRigidBodies1:
  scoreConjectureCorrectModels=0.87143,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.84654,  multScoreConjectureWrongModels=-1


***

A total of:
  1 errors and
  0 warnings
were logged!

***

Summary of EvaluateAllConjectures
 - useSimEvaluationOnly = True
 - sumScoreTotalConjectures = 400.3199999999985
 - nTotalConjectures = 480
 - sumScoreTotalConjectureCorrectModels = 351.4199999999988
 - sumScoreTotalConjectureWrongModels = 48.90000000000003
 - nTotalConjectureCorrectModels = 414
 - nTotalConjectureWrongModels = 66
 - sumMultScoreTotalConjectureCorrectModels = 40.25672971598744
 - sumMultScoreTotalConjectureWrongModels = 8.147212854935708
 - nTotalMultConjectureCorrectModels = 65
 - nTotalMultConjectureWrongModels = 18
 - numberOfRemovedTokensGlobal = 1322
 - numberOfTokensGlobal = 275996
 - totalScoreConjectureCorrectModels = 0.848840579710142
 - totalScoreConjectureWrongModels = 0.7409090909090913
 - totalMultScoreConjectureCorrectModels = 0.6193343033228836
 - totalMultScoreConjectureWrongModels = 0.4526229363853171
 - runTime = 4332.399403095245
 - loggerErrors = 1
 - loggerWarnings = 0



***

Evaluate conjectures (using wrong models): nModels=70, nConjPerModel=8, LLM model=phi-4-Q4_0.gguf

***

EvaluateAllConjectures flyingMassPoint0: model ID0 / 35 (random ID0 / 2)


 - Evaluation for flyingMassPoint0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.1

 - Evaluation for flyingMassPoint0c3 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint0c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint0c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.1

 - Evaluation for flyingMassPoint0c7 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for flyingMassPoint0 (using wrong models):
  scoreConjectureCorrectModels=0.025,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingMassPoint1: model ID0 / 35 (random ID1 / 2); time to go=1.81hours


 - Evaluation for flyingMassPoint1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for flyingMassPoint1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.4

 - Evaluation for flyingMassPoint1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint1c3 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.3

 - Evaluation for flyingMassPoint1c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingMassPoint1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for flyingMassPoint1 (using wrong models):
  scoreConjectureCorrectModels=0.1125,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures freeFallMassPoint0: model ID1 / 35 (random ID0 / 2); time to go=2.0hours


 - Evaluation for freeFallMassPoint0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for freeFallMassPoint0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint0c3 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.3

 - Evaluation for freeFallMassPoint0c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint0c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for freeFallMassPoint0 (using wrong models):
  scoreConjectureCorrectModels=0.16429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures freeFallMassPoint1: model ID1 / 35 (random ID1 / 2); time to go=1.89hours


 - Evaluation for freeFallMassPoint1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint1c3 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint1c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for freeFallMassPoint1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for freeFallMassPoint1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for freeFallMassPoint1 (using wrong models):
  scoreConjectureCorrectModels=0.15833,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures singleMassOscillator0: model ID2 / 35 (random ID0 / 2); time to go=1.81hours


 - Evaluation for singleMassOscillator0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillator0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillator0c3 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillator0c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillator0c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillator0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for singleMassOscillator0c7 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for singleMassOscillator0 (using wrong models):
  scoreConjectureCorrectModels=0.25,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillator1: model ID2 / 35 (random ID1 / 2); time to go=1.7hours


 - Evaluation for singleMassOscillator1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.45

 - Evaluation for singleMassOscillator1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillator1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillator1c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.75

 - Evaluation for singleMassOscillator1c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillator1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillator1c7 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for singleMassOscillator1 (using wrong models):
  scoreConjectureCorrectModels=0.56429,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorGravity0: model ID3 / 35 (random ID0 / 2); time to go=1.6hours


 - Evaluation for singleMassOscillatorGravity0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.45

 - Evaluation for singleMassOscillatorGravity0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.3

 - Evaluation for singleMassOscillatorGravity0c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for singleMassOscillatorGravity0c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for singleMassOscillatorGravity0 (using wrong models):
  scoreConjectureCorrectModels=0.5,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorGravity1: model ID3 / 35 (random ID1 / 2); time to go=1.52hours


 - Evaluation for singleMassOscillatorGravity1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for singleMassOscillatorGravity1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity1c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorGravity1c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorGravity1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.75

 - Evaluation for singleMassOscillatorGravity1c7 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for singleMassOscillatorGravity1 (using wrong models):
  scoreConjectureCorrectModels=0.57143,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankSimple0: model ID4 / 35 (random ID0 / 2); time to go=1.47hours



Evaluation summary for sliderCrankSimple0 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankSimple1: model ID4 / 35 (random ID1 / 2); time to go=1.28hours


 - Evaluation for sliderCrankSimple1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for sliderCrankSimple1 (using wrong models):
  scoreConjectureCorrectModels=0.95,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.95,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumElasticSpring0: model ID5 / 35 (random ID0 / 2); time to go=1.15hours


 - Evaluation for singlePendulumElasticSpring0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for singlePendulumElasticSpring0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulumElasticSpring0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for singlePendulumElasticSpring0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulumElasticSpring0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for singlePendulumElasticSpring0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulumElasticSpring0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for singlePendulumElasticSpring0c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=False, scoreValue=0.9


Evaluation summary for singlePendulumElasticSpring0 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.575
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures singlePendulumElasticSpring1: model ID5 / 35 (random ID1 / 2); time to go=1.14hours


 - Evaluation for singlePendulumElasticSpring1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumElasticSpring1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumElasticSpring1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumElasticSpring1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.4

 - Evaluation for singlePendulumElasticSpring1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumElasticSpring1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumElasticSpring1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulumElasticSpring1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for singlePendulumElasticSpring1 (using wrong models):
  scoreConjectureCorrectModels=0.45714,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures singleMassOscillatorUserFunction0: model ID6 / 35 (random ID0 / 2); time to go=1.12hours


 - Evaluation for singleMassOscillatorUserFunction0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillatorUserFunction0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorUserFunction0c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorUserFunction0c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorUserFunction0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillatorUserFunction0c7 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for singleMassOscillatorUserFunction0 (using wrong models):
  scoreConjectureCorrectModels=0.52857,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singleMassOscillatorUserFunction1: model ID6 / 35 (random ID1 / 2); time to go=1.09hours


 - Evaluation for singleMassOscillatorUserFunction1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singleMassOscillatorUserFunction1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillatorUserFunction1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillatorUserFunction1c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singleMassOscillatorUserFunction1c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.3

 - Evaluation for singleMassOscillatorUserFunction1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singleMassOscillatorUserFunction1c7 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for singleMassOscillatorUserFunction1 (using wrong models):
  scoreConjectureCorrectModels=0.70714,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures spinningDisc0: model ID7 / 35 (random ID0 / 2); time to go=1.07hours


 - Evaluation for spinningDisc0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc0c1 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc0c2 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc0c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for spinningDisc0c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc0c6 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.75

 - Evaluation for spinningDisc0c7 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for spinningDisc0 (using wrong models):
  scoreConjectureCorrectModels=0.38571,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures spinningDisc1: model ID7 / 35 (random ID1 / 2); time to go=1.04hours


 - Evaluation for spinningDisc1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc1c1 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc1c2 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for spinningDisc1c3 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.75

 - Evaluation for spinningDisc1c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for spinningDisc1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for spinningDisc1c6 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for spinningDisc1c7 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for spinningDisc1 (using wrong models):
  scoreConjectureCorrectModels=0.44375,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doubleMassOscillator0: model ID8 / 35 (random ID0 / 2); time to go=1.02hours


 - Evaluation for doubleMassOscillator0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doubleMassOscillator0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doubleMassOscillator0c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doubleMassOscillator0c4 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doubleMassOscillator0c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doubleMassOscillator0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doubleMassOscillator0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for doubleMassOscillator0 (using wrong models):
  scoreConjectureCorrectModels=0.92143,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.92028,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doubleMassOscillator1: model ID8 / 35 (random ID1 / 2); time to go=1.01hours


 - Evaluation for doubleMassOscillator1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doubleMassOscillator1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doubleMassOscillator1c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for doubleMassOscillator1c4 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doubleMassOscillator1c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doubleMassOscillator1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.7

 - Evaluation for doubleMassOscillator1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for doubleMassOscillator1 (using wrong models):
  scoreConjectureCorrectModels=0.7,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nMassOscillator0: model ID9 / 35 (random ID0 / 2); time to go=1.01hours


 - Evaluation for nMassOscillator0c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for nMassOscillator0c2 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nMassOscillator0c3 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for nMassOscillator0c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nMassOscillator0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for nMassOscillator0c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for nMassOscillator0c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.0


Evaluation summary for nMassOscillator0 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.65
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures nMassOscillator1: model ID9 / 35 (random ID1 / 2); time to go=3508.25s


 - Evaluation for nMassOscillator1c0 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nMassOscillator1c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for nMassOscillator1c2 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nMassOscillator1c3 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for nMassOscillator1c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nMassOscillator1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nMassOscillator1c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nMassOscillator1c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for nMassOscillator1 (using wrong models):
  scoreConjectureCorrectModels=0.78333,  scoreConjectureWrongModels=0.9
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.89861


***

EvaluateAllConjectures singlePendulum0: model ID10 / 35 (random ID0 / 2); time to go=3429.15s


 - Evaluation for singlePendulum0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulum0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.2

 - Evaluation for singlePendulum0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulum0c3 (using wrong models): method=Check if planar motion, modelIsCorrect=False, scoreValue=1.0

 - Evaluation for singlePendulum0c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.3

 - Evaluation for singlePendulum0c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulum0c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for singlePendulum0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.85


Evaluation summary for singlePendulum0 (using wrong models):
  scoreConjectureCorrectModels=0.625,  scoreConjectureWrongModels=0.5
  multScoreConjectureCorrectModels=0.53385,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures singlePendulum1: model ID10 / 35 (random ID1 / 2); time to go=3349.48s


 - Evaluation for singlePendulum1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulum1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulum1c3 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulum1c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulum1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulum1c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for singlePendulum1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.95


Evaluation summary for singlePendulum1 (using wrong models):
  scoreConjectureCorrectModels=0.95,  scoreConjectureWrongModels=0.2375
  multScoreConjectureCorrectModels=0.95,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures doublePendulum0: model ID11 / 35 (random ID0 / 2); time to go=3247.69s


 - Evaluation for doublePendulum0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for doublePendulum0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doublePendulum0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.3

 - Evaluation for doublePendulum0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doublePendulum0c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85


***

*****
ERROR:** 

```
EvaluateConjecture: score is invalid: ERROR in ExtractXMLtaggedString: received 0 start tags and 0 end tags!
***
```

 - Evaluation for doublePendulum0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=-3

 - Evaluation for doublePendulum0c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for doublePendulum0 (using wrong models):
  scoreConjectureCorrectModels=0.57857,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.62455,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulum1: model ID11 / 35 (random ID1 / 2); time to go=3198.72s


 - Evaluation for doublePendulum1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum1c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulum1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum1c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulum1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for doublePendulum1 (using wrong models):
  scoreConjectureCorrectModels=0.56667,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nPendulum0: model ID12 / 35 (random ID0 / 2); time to go=3131.53s


 - Evaluation for nPendulum0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulum0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulum0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for nPendulum0 (using wrong models):
  scoreConjectureCorrectModels=0.31667,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures nPendulum1: model ID12 / 35 (random ID1 / 2); time to go=3030.57s


 - Evaluation for nPendulum1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulum1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulum1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulum1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulum1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for nPendulum1 (using wrong models):
  scoreConjectureCorrectModels=0.54286,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures fourBarMechanismPointMasses0: model ID13 / 35 (random ID0 / 2); time to go=2946.93s


 - Evaluation for fourBarMechanismPointMasses0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for fourBarMechanismPointMasses0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for fourBarMechanismPointMasses0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for fourBarMechanismPointMasses0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for fourBarMechanismPointMasses0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for fourBarMechanismPointMasses0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for fourBarMechanismPointMasses0c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for fourBarMechanismPointMasses0 (using wrong models):
  scoreConjectureCorrectModels=0.67143,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures fourBarMechanismPointMasses1: model ID13 / 35 (random ID1 / 2); time to go=2861.85s


 - Evaluation for fourBarMechanismPointMasses1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for fourBarMechanismPointMasses1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for fourBarMechanismPointMasses1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for fourBarMechanismPointMasses1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for fourBarMechanismPointMasses1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for fourBarMechanismPointMasses1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for fourBarMechanismPointMasses1 (using wrong models):
  scoreConjectureCorrectModels=0.78333,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures springCoupledFlyingRigidBodies0: model ID14 / 35 (random ID0 / 2); time to go=2767.08s


 - Evaluation for springCoupledFlyingRigidBodies0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for springCoupledFlyingRigidBodies0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for springCoupledFlyingRigidBodies0c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for springCoupledFlyingRigidBodies0c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for springCoupledFlyingRigidBodies0c6 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for springCoupledFlyingRigidBodies0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0


Evaluation summary for springCoupledFlyingRigidBodies0 (using wrong models):
  scoreConjectureCorrectModels=0.95,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.94956,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures springCoupledFlyingRigidBodies1: model ID14 / 35 (random ID1 / 2); time to go=2695.93s


 - Evaluation for springCoupledFlyingRigidBodies1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for springCoupledFlyingRigidBodies1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for springCoupledFlyingRigidBodies1c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for springCoupledFlyingRigidBodies1c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for springCoupledFlyingRigidBodies1c4 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for springCoupledFlyingRigidBodies1c6 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for springCoupledFlyingRigidBodies1c7 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for springCoupledFlyingRigidBodies1 (using wrong models):
  scoreConjectureCorrectModels=0.88571,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.87527,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures torsionalOscillator0: model ID15 / 35 (random ID0 / 2); time to go=2615.04s


 - Evaluation for torsionalOscillator0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator0c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.4

 - Evaluation for torsionalOscillator0c2 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.7

 - Evaluation for torsionalOscillator0c3 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.3

 - Evaluation for torsionalOscillator0c4 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.2

 - Evaluation for torsionalOscillator0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for torsionalOscillator0c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator0c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.85


Evaluation summary for torsionalOscillator0 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.4125
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures torsionalOscillator1: model ID15 / 35 (random ID1 / 2); time to go=2554.96s


 - Evaluation for torsionalOscillator1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for torsionalOscillator1c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator1c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator1c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator1c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for torsionalOscillator1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=1.0


Evaluation summary for torsionalOscillator1 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.26429
  multScoreConjectureCorrectModels=-1,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures invertedSinglePendulum0: model ID16 / 35 (random ID0 / 2); time to go=2479.97s


 - Evaluation for invertedSinglePendulum0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for invertedSinglePendulum0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for invertedSinglePendulum0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for invertedSinglePendulum0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum0c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum0c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for invertedSinglePendulum0 (using wrong models):
  scoreConjectureCorrectModels=0.8875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.8862,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures invertedSinglePendulum1: model ID16 / 35 (random ID1 / 2); time to go=2410.74s


 - Evaluation for invertedSinglePendulum1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for invertedSinglePendulum1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for invertedSinglePendulum1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for invertedSinglePendulum1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for invertedSinglePendulum1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for invertedSinglePendulum1c6 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for invertedSinglePendulum1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for invertedSinglePendulum1 (using wrong models):
  scoreConjectureCorrectModels=0.76,  scoreConjectureWrongModels=0.95
  multScoreConjectureCorrectModels=0.66537,  multScoreConjectureWrongModels=0.95


***

EvaluateAllConjectures discRollingOnGround0: model ID17 / 35 (random ID0 / 2); time to go=2336.39s


 - Evaluation for discRollingOnGround0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.1

 - Evaluation for discRollingOnGround0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for discRollingOnGround0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for discRollingOnGround0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.1

 - Evaluation for discRollingOnGround0c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for discRollingOnGround0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround0c7 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for discRollingOnGround0 (using wrong models):
  scoreConjectureCorrectModels=0.43125,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures discRollingOnGround1: model ID17 / 35 (random ID1 / 2); time to go=2270.67s


 - Evaluation for discRollingOnGround1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for discRollingOnGround1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for discRollingOnGround1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround1c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.1

 - Evaluation for discRollingOnGround1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for discRollingOnGround1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for discRollingOnGround1 (using wrong models):
  scoreConjectureCorrectModels=0.26875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumElasticSpring0: model ID18 / 35 (random ID0 / 2); time to go=2208.4s


 - Evaluation for doublePendulumElasticSpring0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumElasticSpring0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumElasticSpring0c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for doublePendulumElasticSpring0c4 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumElasticSpring0c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for doublePendulumElasticSpring0c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for doublePendulumElasticSpring0 (using wrong models):
  scoreConjectureCorrectModels=0.7,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures doublePendulumElasticSpring1: model ID18 / 35 (random ID1 / 2); time to go=2122.82s


 - Evaluation for doublePendulumElasticSpring1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for doublePendulumElasticSpring1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumElasticSpring1c2 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for doublePendulumElasticSpring1c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for doublePendulumElasticSpring1c4 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doublePendulumElasticSpring1c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doublePendulumElasticSpring1c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for doublePendulumElasticSpring1 (using wrong models):
  scoreConjectureCorrectModels=0.6875,  scoreConjectureWrongModels=0.6
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures nPendulumElasticSpring0: model ID19 / 35 (random ID0 / 2); time to go=2043.57s


 - Evaluation for nPendulumElasticSpring0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulumElasticSpring0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulumElasticSpring0c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for nPendulumElasticSpring0c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring0c4 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulumElasticSpring0c5 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.65

 - Evaluation for nPendulumElasticSpring0c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.75


Evaluation summary for nPendulumElasticSpring0 (using wrong models):
  scoreConjectureCorrectModels=0.6,  scoreConjectureWrongModels=0.85
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.85


***

EvaluateAllConjectures nPendulumElasticSpring1: model ID19 / 35 (random ID1 / 2); time to go=1973.49s


 - Evaluation for nPendulumElasticSpring1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulumElasticSpring1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulumElasticSpring1c2 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for nPendulumElasticSpring1c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for nPendulumElasticSpring1c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for nPendulumElasticSpring1c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for nPendulumElasticSpring1c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for nPendulumElasticSpring1c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.95


Evaluation summary for nPendulumElasticSpring1 (using wrong models):
  scoreConjectureCorrectModels=0.55,  scoreConjectureWrongModels=0.95
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.95


***

EvaluateAllConjectures elasticChain0: model ID20 / 35 (random ID0 / 2); time to go=1906.92s


 - Evaluation for elasticChain0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for elasticChain0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for elasticChain0c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain0c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain0c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for elasticChain0c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for elasticChain0c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for elasticChain0 (using wrong models):
  scoreConjectureCorrectModels=0.37857,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures elasticChain1: model ID20 / 35 (random ID1 / 2); time to go=1830.71s


 - Evaluation for elasticChain1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for elasticChain1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for elasticChain1c2 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for elasticChain1c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for elasticChain1c4 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for elasticChain1c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for elasticChain1c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for elasticChain1c7 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for elasticChain1 (using wrong models):
  scoreConjectureCorrectModels=0.8125,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumRigidBody0: model ID21 / 35 (random ID0 / 2); time to go=1765.52s


 - Evaluation for singlePendulumRigidBody0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumRigidBody0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumRigidBody0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumRigidBody0c3 (using wrong models): method=Evaluate static equilibrium for damped systems, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody0c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody0c5 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for singlePendulumRigidBody0c6 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody0c7 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for singlePendulumRigidBody0 (using wrong models):
  scoreConjectureCorrectModels=0.48125,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures singlePendulumRigidBody1: model ID21 / 35 (random ID1 / 2); time to go=1702.27s


 - Evaluation for singlePendulumRigidBody1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumRigidBody1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody1c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody1c4 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for singlePendulumRigidBody1c5 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for singlePendulumRigidBody1c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for singlePendulumRigidBody1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for singlePendulumRigidBody1 (using wrong models):
  scoreConjectureCorrectModels=0.6625,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringRigid0: model ID22 / 35 (random ID0 / 2); time to go=1637.53s


 - Evaluation for massPointOnStringRigid0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringRigid0c1 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringRigid0c2 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringRigid0c3 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringRigid0c4 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid0c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for massPointOnStringRigid0 (using wrong models):
  scoreConjectureCorrectModels=0.64286,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringRigid1: model ID22 / 35 (random ID1 / 2); time to go=1572.93s


 - Evaluation for massPointOnStringRigid1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringRigid1c2 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringRigid1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringRigid1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.4

 - Evaluation for massPointOnStringRigid1c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringRigid1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for massPointOnStringRigid1 (using wrong models):
  scoreConjectureCorrectModels=0.36875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures massPointOnStringElastic0: model ID23 / 35 (random ID0 / 2); time to go=1509.9s


 - Evaluation for massPointOnStringElastic0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.3

 - Evaluation for massPointOnStringElastic0c2 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringElastic0c3 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic0c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringElastic0c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for massPointOnStringElastic0c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.0


Evaluation summary for massPointOnStringElastic0 (using wrong models):
  scoreConjectureCorrectModels=0.63333,  scoreConjectureWrongModels=0.425
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures massPointOnStringElastic1: model ID23 / 35 (random ID1 / 2); time to go=1450.17s


 - Evaluation for massPointOnStringElastic1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.4

 - Evaluation for massPointOnStringElastic1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for massPointOnStringElastic1c2 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringElastic1c3 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic1c4 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for massPointOnStringElastic1c5 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic1c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for massPointOnStringElastic1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for massPointOnStringElastic1 (using wrong models):
  scoreConjectureCorrectModels=0.7125,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures linkOnTwoPrismaticJoints0: model ID24 / 35 (random ID0 / 2); time to go=1388.26s


 - Evaluation for linkOnTwoPrismaticJoints0c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for linkOnTwoPrismaticJoints0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for linkOnTwoPrismaticJoints0c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for linkOnTwoPrismaticJoints0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for linkOnTwoPrismaticJoints0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for linkOnTwoPrismaticJoints0c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.6


Evaluation summary for linkOnTwoPrismaticJoints0 (using wrong models):
  scoreConjectureCorrectModels=0.81667,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.80011,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures linkOnTwoPrismaticJoints1: model ID24 / 35 (random ID1 / 2); time to go=1319.75s


 - Evaluation for linkOnTwoPrismaticJoints1c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for linkOnTwoPrismaticJoints1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for linkOnTwoPrismaticJoints1c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for linkOnTwoPrismaticJoints1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for linkOnTwoPrismaticJoints1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.1

 - Evaluation for linkOnTwoPrismaticJoints1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for linkOnTwoPrismaticJoints1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for linkOnTwoPrismaticJoints1 (using wrong models):
  scoreConjectureCorrectModels=0.57143,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingRigidBody0: model ID25 / 35 (random ID0 / 2); time to go=1255.99s


 - Evaluation for flyingRigidBody0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for flyingRigidBody0c2 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody0c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody0c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.2


Evaluation summary for flyingRigidBody0 (using wrong models):
  scoreConjectureCorrectModels=0.05,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures flyingRigidBody1: model ID25 / 35 (random ID1 / 2); time to go=1194.31s


 - Evaluation for flyingRigidBody1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody1c2 (using wrong models): method=Check if parabolic motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for flyingRigidBody1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for flyingRigidBody1c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for flyingRigidBody1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for flyingRigidBody1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for flyingRigidBody1 (using wrong models):
  scoreConjectureCorrectModels=0.23125,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures suspendedRigidBody0: model ID26 / 35 (random ID0 / 2); time to go=1147.49s


 - Evaluation for suspendedRigidBody0c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for suspendedRigidBody0c2 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for suspendedRigidBody0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for suspendedRigidBody0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for suspendedRigidBody0c5 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for suspendedRigidBody0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody0c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for suspendedRigidBody0 (using wrong models):
  scoreConjectureCorrectModels=0.78571,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures suspendedRigidBody1: model ID26 / 35 (random ID1 / 2); time to go=1082.0s


 - Evaluation for suspendedRigidBody1c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for suspendedRigidBody1c2 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for suspendedRigidBody1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for suspendedRigidBody1c5 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for suspendedRigidBody1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for suspendedRigidBody1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for suspendedRigidBody1 (using wrong models):
  scoreConjectureCorrectModels=0.91,  scoreConjectureWrongModels=0.95
  multScoreConjectureCorrectModels=0.90866,  multScoreConjectureWrongModels=0.95


***

EvaluateAllConjectures gyroscopeOnSphericalJoint0: model ID27 / 35 (random ID0 / 2); time to go=1024.22s


 - Evaluation for gyroscopeOnSphericalJoint0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=False, scoreValue=0.95

 - Evaluation for gyroscopeOnSphericalJoint0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=False, scoreValue=0.9

 - Evaluation for gyroscopeOnSphericalJoint0c2 (using wrong models): method=Check if spherical motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for gyroscopeOnSphericalJoint0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for gyroscopeOnSphericalJoint0c4 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.85

 - Evaluation for gyroscopeOnSphericalJoint0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.2

 - Evaluation for gyroscopeOnSphericalJoint0c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for gyroscopeOnSphericalJoint0 (using wrong models):
  scoreConjectureCorrectModels=0.63333,  scoreConjectureWrongModels=0.725
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=0.61745


***

EvaluateAllConjectures gyroscopeOnSphericalJoint1: model ID27 / 35 (random ID1 / 2); time to go=958.84s


 - Evaluation for gyroscopeOnSphericalJoint1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for gyroscopeOnSphericalJoint1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for gyroscopeOnSphericalJoint1c2 (using wrong models): method=Check if spherical motion, modelIsCorrect=False, scoreValue=0.98

 - Evaluation for gyroscopeOnSphericalJoint1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for gyroscopeOnSphericalJoint1c4 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=False, scoreValue=0.0

 - Evaluation for gyroscopeOnSphericalJoint1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=False, scoreValue=0.4

 - Evaluation for gyroscopeOnSphericalJoint1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=False, scoreValue=0.85


Evaluation summary for gyroscopeOnSphericalJoint1 (using wrong models):
  scoreConjectureCorrectModels=0.88333,  scoreConjectureWrongModels=0.5575
  multScoreConjectureCorrectModels=0.88211,  multScoreConjectureWrongModels=0.0


***

EvaluateAllConjectures prismaticJointSystem0: model ID28 / 35 (random ID0 / 2); time to go=895.28s


 - Evaluation for prismaticJointSystem0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem0c2 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem0c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for prismaticJointSystem0 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures prismaticJointSystem1: model ID28 / 35 (random ID1 / 2); time to go=830.2s


 - Evaluation for prismaticJointSystem1c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem1c2 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for prismaticJointSystem1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for prismaticJointSystem1 (using wrong models):
  scoreConjectureCorrectModels=0.0,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithSprings0: model ID29 / 35 (random ID0 / 2); time to go=765.02s


 - Evaluation for twoMassPointsWithSprings0c0 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithSprings0c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for twoMassPointsWithSprings0c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithSprings0c3 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for twoMassPointsWithSprings0c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for twoMassPointsWithSprings0 (using wrong models):
  scoreConjectureCorrectModels=0.69,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithSprings1: model ID29 / 35 (random ID1 / 2); time to go=697.87s


 - Evaluation for twoMassPointsWithSprings1c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.5

 - Evaluation for twoMassPointsWithSprings1c1 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.6

 - Evaluation for twoMassPointsWithSprings1c4 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for twoMassPointsWithSprings1c6 (using wrong models): method=Check if circular motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithSprings1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for twoMassPointsWithSprings1 (using wrong models):
  scoreConjectureCorrectModels=0.8,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.77004,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithDistances0: model ID30 / 35 (random ID0 / 2); time to go=631.24s


 - Evaluation for twoMassPointsWithDistances0c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithDistances0c2 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithDistances0c3 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.4

 - Evaluation for twoMassPointsWithDistances0c5 (using wrong models): method=Check if straight-line motion, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithDistances0c6 (using wrong models): method=Evaluate analytical formulas, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for twoMassPointsWithDistances0c7 (using wrong models): method=Perform a rough calculation, modelIsCorrect=True, scoreValue=0.9


Evaluation summary for twoMassPointsWithDistances0 (using wrong models):
  scoreConjectureCorrectModels=0.69167,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures twoMassPointsWithDistances1: model ID30 / 35 (random ID1 / 2); time to go=566.11s


 - Evaluation for twoMassPointsWithDistances1c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for twoMassPointsWithDistances1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithDistances1c5 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for twoMassPointsWithDistances1c6 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for twoMassPointsWithDistances1 (using wrong models):
  scoreConjectureCorrectModels=0.925,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.92395,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorSimplySupported0: model ID31 / 35 (random ID0 / 2); time to go=499.5s


 - Evaluation for rigidRotorSimplySupported0c0 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorSimplySupported0c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorSimplySupported0c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.6


Evaluation summary for rigidRotorSimplySupported0 (using wrong models):
  scoreConjectureCorrectModels=0.83333,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.81508,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorSimplySupported1: model ID31 / 35 (random ID1 / 2); time to go=432.48s


 - Evaluation for rigidRotorSimplySupported1c1 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorSimplySupported1c2 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorSimplySupported1c4 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorSimplySupported1c5 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorSimplySupported1c7 (using wrong models): method=Evaluate symmetry, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for rigidRotorSimplySupported1 (using wrong models):
  scoreConjectureCorrectModels=0.93,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.9291,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorUnbalanced0: model ID32 / 35 (random ID0 / 2); time to go=368.78s


 - Evaluation for rigidRotorUnbalanced0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorUnbalanced0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorUnbalanced0c2 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced0c3 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced0c4 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorUnbalanced0c5 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.75

 - Evaluation for rigidRotorUnbalanced0c6 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.7

 - Evaluation for rigidRotorUnbalanced0c7 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for rigidRotorUnbalanced0 (using wrong models):
  scoreConjectureCorrectModels=0.86875,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.86345,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures rigidRotorUnbalanced1: model ID32 / 35 (random ID1 / 2); time to go=307.5s


 - Evaluation for rigidRotorUnbalanced1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorUnbalanced1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for rigidRotorUnbalanced1c2 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced1c3 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorUnbalanced1c4 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for rigidRotorUnbalanced1c5 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for rigidRotorUnbalanced1c6 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for rigidRotorUnbalanced1c7 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for rigidRotorUnbalanced1 (using wrong models):
  scoreConjectureCorrectModels=0.825,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.75531,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumRigidBodies0: model ID33 / 35 (random ID0 / 2); time to go=245.95s


 - Evaluation for doublePendulumRigidBodies0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.4

 - Evaluation for doublePendulumRigidBodies0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.9

 - Evaluation for doublePendulumRigidBodies0c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumRigidBodies0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doublePendulumRigidBodies0c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doublePendulumRigidBodies0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.0


Evaluation summary for doublePendulumRigidBodies0 (using wrong models):
  scoreConjectureCorrectModels=0.53333,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures doublePendulumRigidBodies1: model ID33 / 35 (random ID1 / 2); time to go=184.15s


 - Evaluation for doublePendulumRigidBodies1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.45

 - Evaluation for doublePendulumRigidBodies1c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.0

 - Evaluation for doublePendulumRigidBodies1c2 (using wrong models): method=Evaluate eigenfrequencies of undamped system, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doublePendulumRigidBodies1c3 (using wrong models): method=Evaluate complex eigenvalues, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for doublePendulumRigidBodies1c4 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for doublePendulumRigidBodies1c6 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for doublePendulumRigidBodies1c7 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.85


Evaluation summary for doublePendulumRigidBodies1 (using wrong models):
  scoreConjectureCorrectModels=0.62857,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.0,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankRigidBodies0: model ID34 / 35 (random ID0 / 2); time to go=122.54s


 - Evaluation for sliderCrankRigidBodies0c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for sliderCrankRigidBodies0c1 (using wrong models): method=Evaluate initial position, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for sliderCrankRigidBodies0c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=0.98

 - Evaluation for sliderCrankRigidBodies0c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.85

 - Evaluation for sliderCrankRigidBodies0c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for sliderCrankRigidBodies0c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for sliderCrankRigidBodies0c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for sliderCrankRigidBodies0c7 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for sliderCrankRigidBodies0 (using wrong models):
  scoreConjectureCorrectModels=0.94125,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.94053,  multScoreConjectureWrongModels=-1


***

EvaluateAllConjectures sliderCrankRigidBodies1: model ID34 / 35 (random ID1 / 2); time to go=61.26s


 - Evaluation for sliderCrankRigidBodies1c0 (using wrong models): method=Evaluate position trajectory, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for sliderCrankRigidBodies1c2 (using wrong models): method=Check if planar motion, modelIsCorrect=True, scoreValue=1.0

 - Evaluation for sliderCrankRigidBodies1c3 (using wrong models): method=Evaluate motion space, modelIsCorrect=True, scoreValue=0.2

 - Evaluation for sliderCrankRigidBodies1c4 (using wrong models): method=Evaluate velocity space, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for sliderCrankRigidBodies1c5 (using wrong models): method=Evaluate angular momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for sliderCrankRigidBodies1c6 (using wrong models): method=Evaluate linear momentum conservation, modelIsCorrect=True, scoreValue=0.95

 - Evaluation for sliderCrankRigidBodies1c7 (using wrong models): method=Evaluate damping effects, modelIsCorrect=True, scoreValue=0.95


Evaluation summary for sliderCrankRigidBodies1 (using wrong models):
  scoreConjectureCorrectModels=0.85,  scoreConjectureWrongModels=0.0
  multScoreConjectureCorrectModels=0.76601,  multScoreConjectureWrongModels=-1


***

A total of:
  1 errors and
  0 warnings
were logged!

***

Summary of EvaluateAllConjectures (using wrong models)
 - useSimEvaluationOnly = True
 - sumScoreTotalConjectures = 273.40999999999883
 - nTotalConjectures = 480
 - sumScoreTotalConjectureCorrectModels = 238.07999999999902
 - sumScoreTotalConjectureWrongModels = 35.33
 - nTotalConjectureCorrectModels = 414
 - nTotalConjectureWrongModels = 66
 - sumMultScoreTotalConjectureCorrectModels = 16.709430201040675
 - sumMultScoreTotalConjectureWrongModels = 5.21606283015758
 - nTotalMultConjectureCorrectModels = 65
 - nTotalMultConjectureWrongModels = 18
 - numberOfRemovedTokensGlobal = 1404
 - numberOfTokensGlobal = 273086
 - totalScoreConjectureCorrectModels = 0.5750724637681136
 - totalScoreConjectureWrongModels = 0.5353030303030303
 - totalMultScoreConjectureCorrectModels = 0.2570681569390873
 - totalMultScoreConjectureWrongModels = 0.2897812683420878
 - runTime = 4277.48828291893
 - loggerErrors = 1
 - loggerWarnings = 0


